#!/bin/bash

sudo apt autoremove ^kde


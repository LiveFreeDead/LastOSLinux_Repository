#!/bin/bash

x-terminal-emulator -e "flatpak install --user -y --noninteractive ./no.mifi.losslesscut.flatpakref"
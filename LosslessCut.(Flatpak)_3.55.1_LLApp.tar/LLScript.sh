#!/bin/bash

x-terminal-emulator -e "flatpak install -y --noninteractive ./no.mifi.losslesscut.flatpakref"
#!/bin/bash

x-terminal-emulator -e "flatpak install -system -y --noninteractive ./no.mifi.losslesscut.flatpakref"
#!/bin/bash

#Functions
inst () {
APT_CMD=$(which apt 2>/dev/null)
DNF_CMD=$(which dnf 2>/dev/null)
EMERGE_CMD=$(which emerge 2>/dev/null)
EOPKG_CMD=$(which eopkg 2>/dev/null)
APK_CMD=$(which apk 2>/dev/null)
PACMAN_CMD=$(which pacman 2>/dev/null)
ZYPPER_CMD=$(which zypper 2>/dev/null)
YUM_CMD=$(which yum 2>/dev/null)

if [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    #yes | sudo $PACMAN_CMD -S $*
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}


#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(which apt 2>/dev/null)
DNF_CMD=$(which dnf 2>/dev/null)
EMERGE_CMD=$(which emerge 2>/dev/null)
EOPKG_CMD=$(which eopkg 2>/dev/null)
APK_CMD=$(which apk 2>/dev/null)
PACMAN_CMD=$(which pacman 2>/dev/null)
ZYPPER_CMD=$(which zypper 2>/dev/null)
YUM_CMD=$(which yum 2>/dev/null)


#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"

    #Get i386 libs to make even more games work (like DOTT, Full Throttle, Gish etc)
    sudo dnf install -y mesa-libGLU mesa-libGLU.i686
    sudo dnf install -y SDL2-devel SDL2-devel.i686
    sudo dnf install -y fltk fltk.i686
    sudo dnf install -y fuse-libs fuse-libs.i686
    sudo dnf install -y SDL2_image SDL2_image.i686
    sudo dnf install -y SDL2_image-devel SDL2_image-devel.i686
    sudo dnf install -y SDL2_gfx SDL2_gfx.i686
    sudo dnf install -y SDL2_sound SDL2_sound.i686
    sudo dnf install -y SDL2_mixer SDL2_mixer.i686
    sudo dnf install -y SDL2_net SDL2_net.i686
    sudo dnf install -y SDL2_ttf SDL2_ttf.i686
    sudo dnf install -y libepoxy libepoxy.i686
    sudo dnf install -y libstdc++ libstdc++.i686
    sudo dnf install -y libGLEW libGLEW.i686
    sudo dnf install -y meson
    sudo dnf install -y pipewire-alsa pipewire-alsa.i686
    
elif [[ ! -z $APT_CMD ]]; then #apt
    echo "Package Manager: apt"
    PM=apt
    #sudo apt -qq update -y 
    #sudo apt upgrade -y


    #Get i386 libs to make even more games work (like DOTT, Full Throttle, Gish etc)
    sudo apt install -y libasound2:i386 libasound2-data libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386
    sudo apt install -y pipewire-alsa:i386 libopenal1:i386 libudev1:i386 lib32z1 libsdl1.2-compat libsdl1.2debian:i386

    sudo apt install -y libglu1-mesa:i386 meson libfreetype6-dev libfreetype6 libglew-dev libsdl2-image-dev libstdc++5 libfuse2:i386 libepoxy-dev nix-bin

elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
    #zypper refresh
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Package Manager: none configured"
fi


#Get OS ID and do things depending on which one
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    #sudo mkdir -pm755 /etc/apt/keyrings
    #sudo wget -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
    #sudo wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/ubuntu/dists/noble/winehq-noble.sources
    #sudo apt -qq update -y && sudo apt upgrade -y
    ;;

  debian|pop)
    #sudo wget -O /etc/apt/keyrings/winehq-archive.key https://dl.winehq.org/wine-builds/winehq.key
    #sudo wget -NP /etc/apt/sources.list.d/ https://dl.winehq.org/wine-builds/debian/dists/bookworm/winehq-bookworm.sources
    #sudo apt update
    ;;

  fedora)
    #yes | sudo dnf config-manager addrepo --from-repofile=https://dl.winehq.org/wine-builds/fedora/41/winehq.repo
    #yes | sudo dnf upgrade
    ;;

  opensuse-tumbleweed) 
    #zypper --non-interactive addrepo https://download.opensuse.org/repositories/Emulators:Wine/openSUSE_Tumbleweed/Emulators:Wine.repo
    #zypper refresh
    ;;

  arch|endeavouros)
    ;;

  solus)
    ;;

  *) 
    echo "This is an unknown distribution."
      ;;
esac

#Do tasks for each Desktop Environment
case $XDG_SESSION_DESKTOP in

  cinnamon)
    ;;

  gnome|ubuntu)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac


#Install Apps - using Inst function to work on many Distro's and if packages available on it's repositories.

#Tools LastOS and LLStore uses and commons
inst xclip
inst xdotool
inst wget
inst gpg
inst yad
inst 7zip
inst gnome-terminal
inst trash-cli
inst gparted
inst rar
inst unrar
inst uget
inst makeself
inst archivemount
inst dos2unix


inst webp
inst fuse-overlayfs
inst udftools
inst libguestfs-tools


inst ffmpeg
inst ffmpegthumbs
inst mint-meta-codecs
inst liboss4-salsa2
#inst SDL2-devel
inst sdl2*
inst libsdl2-net-2.0-0


#Fedora Specific, wont hurt if not found
inst mesa-libGLU.i686

#For DaVinici Resolve these are needed: (libasound2 <-Packaged removed from Mint 22, so need to use skip_package in divinci)
inst libapr1
inst libaprutil1
inst libglib2.0-0
inst libxcb-cursor0
inst libasound2

inst qemu-utils

#Network things

inst samba
inst wsdd
inst sassc
inst nbd-client

#Below line Crashes LLStore
#inst default-jre


#FlatPak System Wide, user should be done in non Sudo script
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --system -y --noninteractive flathub "
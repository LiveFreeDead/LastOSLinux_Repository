#!/bin/bash

#Quit Plasma and set my choice options for panels and icons then run it again

#Moved to LL Store
#kquitapp plasmashell

#update settings
#$HOME/.config/plasmashellrc
#panelLengthMode=1

sed -i -e 's/panelLengthMode=0/panelLengthMode=1/g' $HOME/.config/plasmashellrc

#$HOME/.config/plasma-org.kde.plasma.desktop-appletsrc
#[Containments][1][General]
#arrangement=1

#Sort Icons Top to Bottom
sed -i -e 's/\[Containments\]\[1\]\[General\]/\[Containments\]\[1\]\[General\]\narrangement=1/g' $HOME/.config/plasma-org.kde.plasma.desktop-appletsrc
#Remove Duplicated entry if any
sed -i -e 's/arrangement=1\narrangement=1/arrangement=1/g' $HOME/.config/plasma-org.kde.plasma.desktop-appletsrc

#Add Home and Trash
cat > $HOME/Desktop/000home.desktop << EOF
[Desktop Entry]
Encoding=UTF-8
Name=Home
GenericName=Personal Files
URL[$e]=$HOME
Icon=user-home
Type=Link
EOF

cat > $HOME/Desktop/000trash.desktop << EOF
[Desktop Entry]
Name=Trash
Comment=Contains removed files
Icon=user-trash-full
EmptyIcon=user-trash
Type=Link
URL=trash:/
OnlyShowIn=KDE;
EOF

#Don't remember tabs opened before
sed -i -e 's/\[General\]/\[General\]\nRememberOpenedTabs=false/g' $HOME/.config/dolphinrc
#Remove Duplicated entry if any
sed -i -e 's/RememberOpenedTabs=false\nRememberOpenedTabs=false/RememberOpenedTabs=false/g' $HOME/.config/dolphinrc

cp -rf ./kxmlgui5 $HOME/.local/share/

#Fix Gnome Terminal options so they work with Wayland, else they are spacy
profile=$(gsettings get org.gnome.Terminal.ProfilesList default)
profile=${profile:1:-1} # remove leading and trailing single quotes

gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ use-theme-colors 'false'

gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ foreground-color 'rgb(208,207,204)'

gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ background-color 'rgb(23,20,33)'



#Restart Plasma
# sleep 1s
#plasmashell & disown
#Done in LL Store now as it leave the script hanging.
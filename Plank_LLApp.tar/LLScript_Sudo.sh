#!/bin/bash

sudo apt install --yes plank
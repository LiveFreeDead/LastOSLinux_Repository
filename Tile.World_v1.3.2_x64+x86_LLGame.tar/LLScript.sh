#!/bin/bash

cp -rf ./share $HOME/.local
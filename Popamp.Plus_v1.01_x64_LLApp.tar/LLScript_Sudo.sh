#!/bin/bash

#LLStore Sudo Script v1.03
#Popamp Plus LLApp

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

# Set by the Package Manager section below
NATIVE_EXT=""      # deb or rpm when a native package suits this distro
NEED_FUSE2=false   # true when the AppImage will be used and needs FUSE 2

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        NEED_FUSE2=true
        ;;

    dnf)
        NATIVE_EXT="rpm"
        ;;

    apt)
        NATIVE_EXT="deb"
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        NEED_FUSE2=true
        ;;

    zypper)
        NATIVE_EXT="rpm"
        ;;

    yum)
        NATIVE_EXT="rpm"
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2


echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
# Popamp Plus - native package install (.deb on apt, .rpm on dnf/yum/zypper).
# Everything else (Arch, CachyOS, immutable OSes, or a failed native install)
# gets the AppImage from LLScript.sh, which runs after this script.

#---------- Popamp Fetch Functions (same block in LLScript.sh and LLScript_Sudo.sh) ----------
VARIANT="popamp-plus"
GH_HOST="github.com"
GH_REPO="popamp/popamp"
REPO_BASE="https://${GH_HOST}/${GH_REPO}"
# Timeouts so an offline or slow network never wedges LLStore
PA_CURL=(curl -fsSL --connect-timeout 15 --max-time 60 --retry 2)
PA_CURL_DL=(curl -fL --connect-timeout 15 --retry 2 --progress-bar)

[ "$(id -u)" -eq 0 ] && PA_SUDO="" || PA_SUDO="sudo"

case "$(uname -m)" in
    x86_64|amd64)  ARCH_PATTERNS="x86_64|amd64" ;;
    aarch64|arm64) ARCH_PATTERNS="aarch64|arm64" ;;
    *) ARCH_PATTERNS="" ;;
esac

# Folder holding the LLApp (and any local packages). LLStore expands %INIPath%,
# a manual run leaves it literal, so fall back to the folder we were started in.
PA_CACHE_DIR="%INIPath%"
case "$PA_CACHE_DIR" in
    %*|"") PA_CACHE_DIR="$PWD" ;;
esac
[ -d "$PA_CACHE_DIR" ] || PA_CACHE_DIR="$PWD"
PA_CACHE_DIR="${PA_CACHE_DIR%/}"

# Temp folder made here (not inside $(...)) so it survives until the install is done.
# The trap also stops the sudo keepalive from the template, as setting a new trap replaces its one.
PA_TMP_DIR=$(mktemp -d /tmp/popamp-llapp.XXXXXX)
pa_cleanup() {
    [ -n "$PA_TMP_DIR" ] && rm -rf "$PA_TMP_DIR"
    [ -n "${SUDO_KEEPALIVE_PID:-}" ] && kill "$SUDO_KEEPALIVE_PID" 2>/dev/null
}
trap 'pa_cleanup' EXIT INT TERM

pa_writable() {
    local test_file="$PA_CACHE_DIR/.llwrite_test.$$"
    if ( : > "$test_file" ) 2>/dev/null; then
        rm -f "$test_file"
        return 0
    fi
    return 1
}

# Sets LATEST_TAG and ASSETS_HTML. Returns 1 when GitHub can't be reached.
# Call it once in the main script first so the result is shared with $(pa_get_package ...) calls.
LATEST_TAG=""
ASSETS_HTML=""
PA_OFFLINE=false
pa_check_latest() {
    [ -n "$LATEST_TAG" ] && return 0
    [ "$PA_OFFLINE" = true ] && return 1
    local effective_url
    effective_url=$("${PA_CURL[@]}" -o /dev/null -w '%{url_effective}' "${REPO_BASE}/releases/latest" 2>/dev/null) || {
        PA_OFFLINE=true
        return 1
    }
    LATEST_TAG="${effective_url##*/}"
    if [ -z "$LATEST_TAG" ] || [ "$LATEST_TAG" = "latest" ]; then
        LATEST_TAG=""
        PA_OFFLINE=true
        return 1
    fi
    ASSETS_HTML=$("${PA_CURL[@]}" "${REPO_BASE}/releases/expanded_assets/${LATEST_TAG}" 2>/dev/null) || {
        LATEST_TAG=""
        PA_OFFLINE=true
        return 1
    }
    return 0
}

pa_asset_url() {
    local ext="$1"
    local path
    path=$(printf '%s' "$ASSETS_HTML" \
        | grep -oE "/${GH_REPO}/releases/download/[^\"]*${VARIANT}[^\"]*(${ARCH_PATTERNS})[^\"]*\.${ext}" \
        | head -n 1)
    [ -n "$path" ] && printf 'https://%s%s' "$GH_HOST" "$path"
}

# Newest local copy in the LLApp folder for this arch and extension
pa_local_file() {
    local ext="$1"
    find "$PA_CACHE_DIR" -maxdepth 1 -type f -iname "*${VARIANT}*.${ext}" 2>/dev/null \
        | grep -E "(${ARCH_PATTERNS})" \
        | sort -V | tail -n 1
}

# Download to a .part file first so a failed download never leaves a broken package behind
pa_download() {
    local url="$1" out="$2"
    echo "Downloading ${url##*/}..." >&2
    if "${PA_CURL_DL[@]}" "$url" -o "${out}.part" >&2; then
        mv -f "${out}.part" "$out"
        return 0
    fi
    rm -f "${out}.part"
    return 1
}

# Prints the path of the package to install for this extension, or nothing.
#   Writable folder + online: refresh the local copy to the latest release, use it
#   Read-only folder + online: use the local copy if it is the latest, else download to temp
#   Offline: use whatever local copy exists
pa_get_package() {
    local ext="$1"
    local local_file url file_name target old
    local_file=$(pa_local_file "$ext")

    if ! pa_check_latest; then
        if [ -n "$local_file" ]; then
            echo "GitHub not reachable, using local copy: ${local_file##*/}" >&2
            printf '%s' "$local_file"
        else
            echo "GitHub not reachable and no local .${ext} found in $PA_CACHE_DIR" >&2
        fi
        return 0
    fi

    url=$(pa_asset_url "$ext")
    if [ -z "$url" ]; then
        echo "No ${VARIANT} .${ext} for $(uname -m) in release $LATEST_TAG" >&2
        [ -n "$local_file" ] && printf '%s' "$local_file"
        return 0
    fi
    file_name="${url##*/}"

    if pa_writable; then
        target="$PA_CACHE_DIR/$file_name"
        if [ -f "$target" ]; then
            echo "Local copy is current: $file_name" >&2
        elif pa_download "$url" "$target"; then
            # Root downloads get the folder owner's ownership so the user can manage them
            [ "$(id -u)" -eq 0 ] && chown --reference="$PA_CACHE_DIR" "$target" 2>/dev/null
            # Remove older cached copies of the same format/arch
            find "$PA_CACHE_DIR" -maxdepth 1 -type f -iname "*${VARIANT}*.${ext}" 2>/dev/null \
                | grep -E "(${ARCH_PATTERNS})" | while IFS= read -r old; do
                    [ "$old" != "$target" ] && rm -f "$old"
                done
        else
            echo "Download failed." >&2
            [ -n "$local_file" ] && printf '%s' "$local_file"
            return 0
        fi
        printf '%s' "$target"
        return 0
    fi

    # Folder is read-only (DVD, locked USB, system folder)
    if [ -n "$local_file" ] && [ "${local_file##*/}" = "$file_name" ]; then
        echo "Local copy is current: $file_name" >&2
        printf '%s' "$local_file"
        return 0
    fi
    target="$PA_TMP_DIR/$file_name"
    if pa_download "$url" "$target"; then
        printf '%s' "$target"
    elif [ -n "$local_file" ]; then
        echo "Download failed, using older local copy: ${local_file##*/}" >&2
        printf '%s' "$local_file"
    fi
    return 0
}

pa_native_installed() {
    if command -v dpkg-query >/dev/null 2>&1 && dpkg-query -W -f='${Status}' "$VARIANT" 2>/dev/null | grep -q "install ok installed"; then
        return 0
    fi
    if command -v rpm >/dev/null 2>&1 && rpm -q "$VARIANT" >/dev/null 2>&1; then
        return 0
    fi
    return 1
}
#---------- End Popamp Fetch Functions ----------

pa_install_native() {
    local pkg="$1" ext="$2" pkg_ver="" installed_ver=""
    case "$ext" in
        deb)
            pkg_ver=$(dpkg-deb -f "$pkg" Version 2>/dev/null)
            dpkg-query -W -f='${Status}' "$VARIANT" 2>/dev/null | grep -q "install ok installed" \
                && installed_ver=$(dpkg-query -W -f='${Version}' "$VARIANT" 2>/dev/null)
            ;;
        rpm)
            pkg_ver=$(rpm -qp --qf '%{VERSION}' "$pkg" 2>/dev/null)
            rpm -q "$VARIANT" >/dev/null 2>&1 \
                && installed_ver=$(rpm -q --qf '%{VERSION}' "$VARIANT" 2>/dev/null)
            ;;
    esac

    if [ -n "$installed_ver" ] && [ "$installed_ver" = "$pkg_ver" ] && [ "$FORCE_REINSTALL" != true ]; then
        echo "$VARIANT ($installed_ver) is already up to date."
        return 0
    fi

    echo "Installing ${pkg##*/}..."
    case "$PM" in
        apt)
            $PA_SUDO apt-get update -qq || true
            $PA_SUDO apt-get install -y -qq --reinstall "$pkg" ;;
        dnf)
            $PA_SUDO dnf install -y -q "$pkg" ;;
        yum)
            $PA_SUDO yum install -y -q "$pkg" ;;
        zypper)
            $PA_SUDO zypper --non-interactive install --allow-unsigned-rpm "$pkg" ;;
    esac
    pa_native_installed
}

# AppImages need FUSE 2, install it when we are falling back to the AppImage
pa_install_fuse2() {
    case "$PM" in
        apt)    $PA_SUDO apt-get install -y -qq libfuse2t64 2>/dev/null || $PA_SUDO apt-get install -y -qq libfuse2 ;;
        dnf)    $PA_SUDO dnf install -y -q fuse-libs ;;
        yum)    $PA_SUDO yum install -y -q fuse-libs ;;
        zypper) $PA_SUDO zypper --non-interactive install libfuse2 ;;
        pacman) $PA_SUDO pacman -S --needed --noconfirm fuse2 ;;
        pamac)  pamac install --no-confirm fuse2 ;;
    esac
}

if [ -z "$ARCH_PATTERNS" ]; then
    echo "Unsupported architecture: $(uname -m)" >&2
    exit 1
fi

echo "Package folder: $PA_CACHE_DIR"
echo "Checking latest Popamp release..."
if pa_check_latest; then
    echo "Latest release: $LATEST_TAG"
else
    echo "GitHub not reachable, will use a local copy if one is found."
fi

if [ "$IMMUTABLE_OS" = true ]; then
    NATIVE_EXT=""
    echo "Immutable OS detected, the AppImage will be used instead of a native package."
fi

if [ -n "$NATIVE_EXT" ]; then
    PKG_FILE=$(pa_get_package "$NATIVE_EXT")
    if [ -n "$PKG_FILE" ] && pa_install_native "$PKG_FILE" "$NATIVE_EXT"; then
        echo "$VARIANT installed from ${PKG_FILE##*/}."
    else
        echo "Native .$NATIVE_EXT install unavailable or failed, falling back to the AppImage." >&2
        NEED_FUSE2=true
    fi
fi

if [ "$NEED_FUSE2" = true ]; then
    pa_install_fuse2 || echo "Could not install FUSE 2, the AppImage may need it to run." >&2
fi

exit 0
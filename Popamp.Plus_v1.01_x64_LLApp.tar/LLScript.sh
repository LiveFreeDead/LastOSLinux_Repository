#!/bin/bash

#LLStore Script v1.02
#Popamp Plus LLApp

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

# Set to true to reinstall the AppImage even if it's already up to date
FORCE_REINSTALL=false

# When the LLApp folder is writable, also download the latest .deb, .rpm and
# .AppImage for this arch into it, so the folder can install offline anywhere
CACHE_ALL_FORMATS=true

# Install the Popamp Steel skin (prebuilt copy in skins/steel, newer release from GitHub if there is one)
INSTALL_SKIN=true
# Make Steel the active skin, only when no skin has been picked yet
SET_DEFAULT_SKIN=true
# Set Steel even if the user already picked another skin
FORCE_SKIN=false
# Steel colour set: Navy, Emerald, Ruby or Graphite (empty = Navy, as drawn)
SKIN_COLOURS=""

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------
# Popamp Plus - AppImage install for distros without a native package
# (or when the native install in LLScript_Sudo.sh failed), plus local copy caching.

#---------- Popamp Fetch Functions (same block in LLScript.sh and LLScript_Sudo.sh) ----------
VARIANT="popamp-plus"
GH_HOST="github.com"
GH_REPO="popamp/popamp"
REPO_BASE="https://${GH_HOST}/${GH_REPO}"
# Timeouts so an offline or slow network never wedges LLStore
PA_CURL=(curl -fsSL --connect-timeout 15 --max-time 60 --retry 2)
PA_CURL_DL=(curl -fL --connect-timeout 15 --retry 2 --progress-bar)

[ "$(id -u)" -eq 0 ] && PA_SUDO="" || PA_SUDO="sudo"

case "$(uname -m)" in
    x86_64|amd64)  ARCH_PATTERNS="x86_64|amd64" ;;
    aarch64|arm64) ARCH_PATTERNS="aarch64|arm64" ;;
    *) ARCH_PATTERNS="" ;;
esac

# Folder holding the LLApp (and any local packages). LLStore expands %INIPath%,
# a manual run leaves it literal, so fall back to the folder we were started in.
PA_CACHE_DIR="%INIPath%"
case "$PA_CACHE_DIR" in
    %*|"") PA_CACHE_DIR="$PWD" ;;
esac
[ -d "$PA_CACHE_DIR" ] || PA_CACHE_DIR="$PWD"
PA_CACHE_DIR="${PA_CACHE_DIR%/}"

# Temp folder made here (not inside $(...)) so it survives until the install is done.
# The trap also stops the sudo keepalive from the template, as setting a new trap replaces its one.
PA_TMP_DIR=$(mktemp -d /tmp/popamp-llapp.XXXXXX)
pa_cleanup() {
    [ -n "$PA_TMP_DIR" ] && rm -rf "$PA_TMP_DIR"
    [ -n "${SUDO_KEEPALIVE_PID:-}" ] && kill "$SUDO_KEEPALIVE_PID" 2>/dev/null
}
trap 'pa_cleanup' EXIT INT TERM

pa_writable() {
    local test_file="$PA_CACHE_DIR/.llwrite_test.$$"
    if ( : > "$test_file" ) 2>/dev/null; then
        rm -f "$test_file"
        return 0
    fi
    return 1
}

# Sets LATEST_TAG and ASSETS_HTML. Returns 1 when GitHub can't be reached.
# Call it once in the main script first so the result is shared with $(pa_get_package ...) calls.
LATEST_TAG=""
ASSETS_HTML=""
PA_OFFLINE=false
pa_check_latest() {
    [ -n "$LATEST_TAG" ] && return 0
    [ "$PA_OFFLINE" = true ] && return 1
    local effective_url
    effective_url=$("${PA_CURL[@]}" -o /dev/null -w '%{url_effective}' "${REPO_BASE}/releases/latest" 2>/dev/null) || {
        PA_OFFLINE=true
        return 1
    }
    LATEST_TAG="${effective_url##*/}"
    if [ -z "$LATEST_TAG" ] || [ "$LATEST_TAG" = "latest" ]; then
        LATEST_TAG=""
        PA_OFFLINE=true
        return 1
    fi
    ASSETS_HTML=$("${PA_CURL[@]}" "${REPO_BASE}/releases/expanded_assets/${LATEST_TAG}" 2>/dev/null) || {
        LATEST_TAG=""
        PA_OFFLINE=true
        return 1
    }
    return 0
}

pa_asset_url() {
    local ext="$1"
    local path
    path=$(printf '%s' "$ASSETS_HTML" \
        | grep -oE "/${GH_REPO}/releases/download/[^\"]*${VARIANT}[^\"]*(${ARCH_PATTERNS})[^\"]*\.${ext}" \
        | head -n 1)
    [ -n "$path" ] && printf 'https://%s%s' "$GH_HOST" "$path"
}

# Newest local copy in the LLApp folder for this arch and extension
pa_local_file() {
    local ext="$1"
    find "$PA_CACHE_DIR" -maxdepth 1 -type f -iname "*${VARIANT}*.${ext}" 2>/dev/null \
        | grep -E "(${ARCH_PATTERNS})" \
        | sort -V | tail -n 1
}

# Download to a .part file first so a failed download never leaves a broken package behind
pa_download() {
    local url="$1" out="$2"
    echo "Downloading ${url##*/}..." >&2
    if "${PA_CURL_DL[@]}" "$url" -o "${out}.part" >&2; then
        mv -f "${out}.part" "$out"
        return 0
    fi
    rm -f "${out}.part"
    return 1
}

# Prints the path of the package to install for this extension, or nothing.
#   Writable folder + online: refresh the local copy to the latest release, use it
#   Read-only folder + online: use the local copy if it is the latest, else download to temp
#   Offline: use whatever local copy exists
pa_get_package() {
    local ext="$1"
    local local_file url file_name target old
    local_file=$(pa_local_file "$ext")

    if ! pa_check_latest; then
        if [ -n "$local_file" ]; then
            echo "GitHub not reachable, using local copy: ${local_file##*/}" >&2
            printf '%s' "$local_file"
        else
            echo "GitHub not reachable and no local .${ext} found in $PA_CACHE_DIR" >&2
        fi
        return 0
    fi

    url=$(pa_asset_url "$ext")
    if [ -z "$url" ]; then
        echo "No ${VARIANT} .${ext} for $(uname -m) in release $LATEST_TAG" >&2
        [ -n "$local_file" ] && printf '%s' "$local_file"
        return 0
    fi
    file_name="${url##*/}"

    if pa_writable; then
        target="$PA_CACHE_DIR/$file_name"
        if [ -f "$target" ]; then
            echo "Local copy is current: $file_name" >&2
        elif pa_download "$url" "$target"; then
            # Root downloads get the folder owner's ownership so the user can manage them
            [ "$(id -u)" -eq 0 ] && chown --reference="$PA_CACHE_DIR" "$target" 2>/dev/null
            # Remove older cached copies of the same format/arch
            find "$PA_CACHE_DIR" -maxdepth 1 -type f -iname "*${VARIANT}*.${ext}" 2>/dev/null \
                | grep -E "(${ARCH_PATTERNS})" | while IFS= read -r old; do
                    [ "$old" != "$target" ] && rm -f "$old"
                done
        else
            echo "Download failed." >&2
            [ -n "$local_file" ] && printf '%s' "$local_file"
            return 0
        fi
        printf '%s' "$target"
        return 0
    fi

    # Folder is read-only (DVD, locked USB, system folder)
    if [ -n "$local_file" ] && [ "${local_file##*/}" = "$file_name" ]; then
        echo "Local copy is current: $file_name" >&2
        printf '%s' "$local_file"
        return 0
    fi
    target="$PA_TMP_DIR/$file_name"
    if pa_download "$url" "$target"; then
        printf '%s' "$target"
    elif [ -n "$local_file" ]; then
        echo "Download failed, using older local copy: ${local_file##*/}" >&2
        printf '%s' "$local_file"
    fi
    return 0
}

pa_native_installed() {
    if command -v dpkg-query >/dev/null 2>&1 && dpkg-query -W -f='${Status}' "$VARIANT" 2>/dev/null | grep -q "install ok installed"; then
        return 0
    fi
    if command -v rpm >/dev/null 2>&1 && rpm -q "$VARIANT" >/dev/null 2>&1; then
        return 0
    fi
    return 1
}
#---------- End Popamp Fetch Functions ----------

PA_INSTALL_DIR="$HOME/.local/bin"
PA_APP_PATH="$PA_INSTALL_DIR/$VARIANT"
PA_VERSION_FILE="$HOME/.local/share/popamp/.installed_version"
PA_DESKTOP_FILE="$HOME/.local/share/applications/${VARIANT}.desktop"

if [ -z "$ARCH_PATTERNS" ]; then
    echo "Unsupported architecture: $(uname -m)" >&2
    exit 1
fi

echo "Package folder: $PA_CACHE_DIR"
pa_check_latest || echo "GitHub not reachable, will use a local copy if one is found."

if pa_native_installed; then
    echo "$VARIANT is installed as a native package, AppImage not needed."
    # Tidy up an AppImage this LLApp installed before, so there aren't two launchers
    if [ -f "$PA_VERSION_FILE" ]; then
        rm -f "$PA_APP_PATH" "$PA_DESKTOP_FILE" "$PA_VERSION_FILE"
        update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
        echo "Removed the older $VARIANT AppImage."
    fi
else
    mkdir -p "$PA_INSTALL_DIR" "$(dirname "$PA_VERSION_FILE")" "$(dirname "$PA_DESKTOP_FILE")"

    CURRENT_NAME=""
    [ -f "$PA_VERSION_FILE" ] && CURRENT_NAME=$(cat "$PA_VERSION_FILE")

    # What we'd install: the latest release when online, else the local copy
    WANT_NAME=""
    if [ "$PA_OFFLINE" != true ]; then
        WANT_URL=$(pa_asset_url "AppImage")
        WANT_NAME="${WANT_URL##*/}"
    else
        WANT_FILE=$(pa_local_file "AppImage")
        WANT_NAME="${WANT_FILE##*/}"
    fi

    if [ -x "$PA_APP_PATH" ] && [ -n "$WANT_NAME" ] && [ "$CURRENT_NAME" = "$WANT_NAME" ] && [ "$FORCE_REINSTALL" != true ]; then
        echo "$VARIANT ($CURRENT_NAME) is already up to date."
    else
        APPIMAGE_FILE=$(pa_get_package "AppImage")
        if [ -z "$APPIMAGE_FILE" ]; then
            echo "Could not find a $VARIANT AppImage for $(uname -m)." >&2
            if [ -n "$ASSETS_HTML" ]; then
                echo "Available assets in $LATEST_TAG:" >&2
                printf '%s\n' "$ASSETS_HTML" | grep -oE "/${GH_REPO}/releases/download/[^\"]+" >&2
            fi
            exit 1
        fi
        cp -f "$APPIMAGE_FILE" "${PA_APP_PATH}.tmp"
        chmod +x "${PA_APP_PATH}.tmp"
        mv -f "${PA_APP_PATH}.tmp" "$PA_APP_PATH"
        printf '%s' "${APPIMAGE_FILE##*/}" > "$PA_VERSION_FILE"
        echo "$VARIANT installed to $PA_APP_PATH from ${APPIMAGE_FILE##*/}."
    fi

    cat > "$PA_DESKTOP_FILE" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Popamp Plus
Comment=Winamp-style audio player with plug-ins
Exec=$PA_APP_PATH %U
Icon=audio-x-generic
Terminal=false
Categories=AudioVideo;Audio;Player;
MimeType=audio/mpeg;audio/flac;audio/ogg;audio/wav;audio/x-mpegurl;
DESKTOP
    update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
fi

#---------- Popamp Steel Skin ----------
# Uses the prebuilt copy in skins/steel next to this script. When GitHub has a
# newer skin release it downloads that instead (and refreshes the bundled copy
# when the folder is writable). Then it sets Steel as the skin, but only if no
# skin has been chosen yet, so a reinstall never overrides the user's pick.
SKIN_REPO="popamp/skin-steel"
SKIN_NAME="steel"
SKIN_LOCAL="$PA_CACHE_DIR/skins/$SKIN_NAME"
SKIN_DEST="$HOME/.local/share/popamp/skins/$SKIN_NAME"
POPAMP_INI="${XDG_CONFIG_HOME:-$HOME/.config}/popamp/popamp.ini"

# Copy a skin folder in, skipping the generator tools and repo files
pa_copy_skin() {
    local from="$1" to="$2" item
    rm -rf "${to}.tmp"
    mkdir -p "${to}.tmp" || return 1
    for item in "$from"/*; do
        case "${item##*/}" in
            tools|preview.png) continue ;;
        esac
        cp -r "$item" "${to}.tmp/" || return 1
    done
    [ -f "$from/.llapp_skin_version" ] && cp -f "$from/.llapp_skin_version" "${to}.tmp/"
    [ -f "${to}.tmp/skin.toml" ] || { rm -rf "${to}.tmp"; return 1; }
    rm -rf "$to"
    mv -f "${to}.tmp" "$to"
}

# Set key=value in the [Popamp] section of popamp.ini.
# $3 = true only sets it when the key is missing or empty.
pa_ini_set() {
    local key="$1" value="$2" only_if_empty="$3"
    mkdir -p "$(dirname "$POPAMP_INI")"
    [ -f "$POPAMP_INI" ] || printf '[Popamp]\n' > "$POPAMP_INI"
    awk -v key="$key" -v val="$value" -v soft="$only_if_empty" '
        function put() { print key "=" val; done = 1 }
        /^\[.*\][[:space:]]*$/ {
            if (insec && !done) put()
            insec = ($0 ~ /^\[Popamp\][[:space:]]*$/)
            if (insec) seen = 1
            print; next
        }
        insec && index($0, key "=") == 1 {
            if (done) next
            cur = substr($0, length(key) + 2)
            if (soft == "true" && cur != "") { print; done = 1 } else put()
            next
        }
        { print }
        END {
            if (insec && !done) put()
            if (!seen) { print "[Popamp]"; put() }
        }
    ' "$POPAMP_INI" > "${POPAMP_INI}.tmp" && mv -f "${POPAMP_INI}.tmp" "$POPAMP_INI"
}

if [ "$INSTALL_SKIN" = true ]; then
    echo
    echo "Installing the Popamp Steel skin..."
    SKIN_LOCAL_VER=""
    [ -f "$SKIN_LOCAL/.llapp_skin_version" ] && SKIN_LOCAL_VER=$(cat "$SKIN_LOCAL/.llapp_skin_version")
    SKIN_SOURCE=""
    [ -f "$SKIN_LOCAL/skin.toml" ] && SKIN_SOURCE="$SKIN_LOCAL"

    # Newer skin release on GitHub?
    SKIN_TAG=""
    if [ "$PA_OFFLINE" != true ]; then
        SKIN_URL=$("${PA_CURL[@]}" -o /dev/null -w '%{url_effective}' "https://${GH_HOST}/${SKIN_REPO}/releases/latest" 2>/dev/null) && SKIN_TAG="${SKIN_URL##*/}"
        [ "$SKIN_TAG" = "latest" ] && SKIN_TAG=""
    fi
    if [ -n "$SKIN_TAG" ] && [ "$SKIN_TAG" != "$SKIN_LOCAL_VER" ]; then
        SKIN_TAR="$PA_TMP_DIR/skin.tar.gz"
        if pa_download "https://${GH_HOST}/${SKIN_REPO}/archive/refs/tags/${SKIN_TAG}.tar.gz" "$SKIN_TAR" \
            && mkdir -p "$PA_TMP_DIR/skin" && tar -xzf "$SKIN_TAR" -C "$PA_TMP_DIR/skin" --strip-components=1 \
            && [ -f "$PA_TMP_DIR/skin/skin.toml" ]; then
            printf '%s' "$SKIN_TAG" > "$PA_TMP_DIR/skin/.llapp_skin_version"
            SKIN_SOURCE="$PA_TMP_DIR/skin"
            echo "Got Steel skin $SKIN_TAG from GitHub."
            if pa_writable && pa_copy_skin "$PA_TMP_DIR/skin" "$SKIN_LOCAL"; then
                echo "Updated the bundled skin copy in $SKIN_LOCAL."
            fi
        else
            echo "Skin download failed, using the bundled copy." >&2
        fi
    elif [ -n "$SKIN_SOURCE" ]; then
        echo "Using the bundled Steel skin ${SKIN_LOCAL_VER}."
    fi

    if [ -z "$SKIN_SOURCE" ]; then
        echo "No Steel skin found locally and GitHub not reachable, skin skipped." >&2
    elif pa_copy_skin "$SKIN_SOURCE" "$SKIN_DEST"; then
        echo "Steel skin installed to $SKIN_DEST."
        if [ "$SET_DEFAULT_SKIN" = true ]; then
            if pgrep -x "$VARIANT" >/dev/null 2>&1 || pgrep -x popamp >/dev/null 2>&1; then
                echo "Popamp is running; close it and reinstall to set the skin (it saves its settings on exit)." >&2
            else
                [ "$FORCE_SKIN" = true ] && PA_SOFT=false || PA_SOFT=true
                pa_ini_set "skin" "$SKIN_DEST" "$PA_SOFT"
                [ -n "$SKIN_COLOURS" ] && pa_ini_set "skin_colors" "$SKIN_COLOURS" "$PA_SOFT"
                echo "Skin setting: $(grep -m1 '^skin=' "$POPAMP_INI")"
            fi
        fi
    else
        echo "Could not copy the Steel skin to $SKIN_DEST." >&2
    fi
fi

# Keep the LLApp folder stocked with every format for this arch, so it can
# install offline on any distro next time (USB sticks, other PCs)
if [ "$CACHE_ALL_FORMATS" = true ] && [ "$PA_OFFLINE" != true ] && pa_writable; then
    echo
    echo "Updating local copies in $PA_CACHE_DIR..."
    for PA_EXT in deb rpm AppImage; do
        pa_get_package "$PA_EXT" >/dev/null
    done
fi

exit 0
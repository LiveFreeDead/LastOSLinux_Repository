#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#Tools LastOS and LLStore uses and commons
inst xclip
inst xdotool
inst wget
inst gpg
inst yad
inst 7zip
inst gnome-terminal
inst trash-cli
inst gparted
inst rar
inst unrar
inst uget
inst makeself
inst archivemount
inst dos2unix


inst webp
inst fuse-overlayfs
inst udftools
inst libguestfs-tools


inst ffmpeg
inst ffmpegthumbs
inst mint-meta-codecs
inst liboss4-salsa2

#inst SDL2-devel
#Many SDL2 Games require
inst libsdl2-mixer-2.0-0 libsdl2-image-2.0-0 libsdl2-gfx-1.0-0 libsdl2-2.0-0 libsdl2-net-2.0-0
inst libglfw3
inst libxft2

#Braid Required etc
inst libsdl2-2.0-0:i386 libsdl2-mixer-2.0-0:i386 libxft2:i386 libsdl2-image-2.0-0:i386 libsdl2-gfx-1.0-0:i386 libsdl2-net-2.0-0:i386
inst libasound2:i386 libasound2-data libasound2-plugins:i386
inst libfltk1.3
inst libfltk1.3:i386 

#Fedora Specific, wont hurt if not found
inst mesa-libGLU.i686

#For DaVinici Resolve these are needed: (libasound2 <-Packaged removed from Mint 22, so need to use skip_package in divinci)
inst libapr1
inst libaprutil1
inst libglib2.0-0
inst libxcb-cursor0
inst libasound2

inst qemu-utils

#Network things

inst samba
inst wsdd
inst sassc
inst nbd-client

#CachyOS - SDL2 and many other required ones
inst mesa-libGLU mesa-libGLU.i686 SDL2-devel SDL2-devel.i686 fltk fltk.i686 fuse-libs fuse-libs.i686 SDL2_image SDL2_image.i686 SDL2_image-devel SDL2_image-devel.i686 SDL2_gfx SDL2_gfx.i686 SDL2_sound SDL2_sound.i686 SDL2_mixer SDL2_mixer.i686 SDL2_net SDL2_net.i686 SDL2_ttf SDL2_ttf.i686 libepoxy libepoxy.i686 libstdc++ libstdc++.i686 libGLEW libGLEW.i686 meson pipewire-alsa pipewire-alsa.i686
inst libasound2:i386 libasound2-data libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386 pipewire-alsa:i386 libopenal1:i386 libudev1:i386 lib32z1 libsdl1.2-compat libsdl1.2debian:i386 libglu1-mesa:i386 meson libfreetype6-dev libfreetype6 libglew-dev libsdl2-image-dev libstdc++5 libfuse2:i386 libepoxy-dev nix-bin libsdl2-net-2.0-0
inst libasound2:i386 libasound2-data libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386
inst libasound2:i686 libasound2-plugins:i686 libsdl2-2.0-0:i686 libfltk1.3:i686
inst sdl2_mixer sdl2_image sdl2_ttf sdl2_net
inst lib32-sdl2 lib32-sdl2_image lib32-sdl2_mixer lib32-sdl2_ttf lib32-sdl2_net


#Below line Crashes LLStore due to fonts included
#inst default-jre

exit 0
#!/bin/bash

wine regedit /s ./LightWine.reg
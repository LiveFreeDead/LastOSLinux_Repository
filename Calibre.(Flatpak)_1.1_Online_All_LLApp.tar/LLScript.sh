#!/bin/bash

x-terminal-emulator -e "flatpak install --user -y --noninteractive flathub com.calibre_ebook.calibre"
#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------

#Get Best Terminal For LLStore (in order)
TERMS=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${TERMS[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#-------------------------------

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $PAMAC_CMD ]]; then #pamac
    PM=pamac
    echo "Package Manager: pamac"
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
    #Get i386 libs to make even more games work (like DOTT, Full Throttle, Gish etc)
    sudo dnf install -y mesa-libGLU mesa-libGLU.i686
    sudo dnf install -y SDL2-devel SDL2-devel.i686
    sudo dnf install -y fltk fltk.i686
    sudo dnf install -y fuse-libs fuse-libs.i686
    sudo dnf install -y SDL2_image SDL2_image.i686
    sudo dnf install -y SDL2_image-devel SDL2_image-devel.i686
    sudo dnf install -y SDL2_gfx SDL2_gfx.i686
    sudo dnf install -y SDL2_sound SDL2_sound.i686
    sudo dnf install -y SDL2_mixer SDL2_mixer.i686
    sudo dnf install -y SDL2_net SDL2_net.i686
    sudo dnf install -y SDL2_ttf SDL2_ttf.i686
    sudo dnf install -y libepoxy libepoxy.i686
    sudo dnf install -y libstdc++ libstdc++.i686
    sudo dnf install -y libGLEW libGLEW.i686
    sudo dnf install -y meson
    sudo dnf install -y pipewire-alsa pipewire-alsa.i686
elif [[ ! -z $APT_CMD ]]; then #apt
    PM=apt
    echo "Package Manager: apt"
    
    # 1. Ensure i386 architecture is actually enabled before trying to install libs
    sudo dpkg --add-architecture i386
    sudo apt update

    # 2. Optimized library list - removed nix-bin and simplified naming to avoid conflicts
    # We use 'install' but add --no-remove to prevent apt from uninstalling Wine
    sudo apt install -y --no-remove \
        libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386 \
        pipewire-alsa:i386 libopenal1:i386 libudev1:i386 lib32z1 \
        libsdl1.2-compat libglu1-mesa:i386 meson libfreetype6-dev \
        libfreetype6 libglew-dev libsdl2-image-dev libfuse2t64:i386 \
        libepoxy-dev
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then #eopkg
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Unknown Package Manager. Script section skipped"
fi


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;


  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    #SUSE
    ;;

  zorin)
    ;;

  *)
    #All Others
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#Install Apps - using Inst function to work on many Distro's if the package(s) are available on its repositories.
#inst appname1 appname2 etc


#FlatPak Install Package System Wide (User mode should be done in non Sudo LLScript)
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --system -y --noninteractive flathub "


#----- Add Your Code Here ------

#Install Apps - using Inst function to work on many Distro's and if packages available on it's repositories.

#Tools LastOS and LLStore uses and commons
inst xclip
inst xdotool
inst wget
inst gpg
inst yad
inst 7zip
inst gnome-terminal
inst trash-cli
inst gparted
inst rar
inst unrar
inst uget
inst makeself
inst archivemount
inst dos2unix


inst webp
inst fuse-overlayfs
inst udftools
inst libguestfs-tools


inst ffmpeg
inst ffmpegthumbs
inst mint-meta-codecs
inst liboss4-salsa2

#inst SDL2-devel
#Many SDL2 Games require
#Disable the wildcard one as I think it's beaking things
##### NO!!! inst sdl2*
inst libsdl2-mixer-2.0-0 libsdl2-image-2.0-0 libsdl2-gfx-1.0-0 libsdl2-2.0-0 libsdl2-net-2.0-0
inst libglfw3
inst libxft2

#Braid Required etc
inst libsdl2-2.0-0:i386 libsdl2-mixer-2.0-0:i386 libxft2:i386 libsdl2-image-2.0-0:i386 libsdl2-gfx-1.0-0:i386 libsdl2-net-2.0-0:i386
inst libasound2:i386 libasound2-data libasound2-plugins:i386
inst libfltk1.3
inst libfltk1.3:i386 

#Fedora Specific, wont hurt if not found
inst mesa-libGLU.i686

#For DaVinici Resolve these are needed: (libasound2 <-Packaged removed from Mint 22, so need to use skip_package in divinci)
inst libapr1
inst libaprutil1
inst libglib2.0-0
inst libxcb-cursor0
inst libasound2

inst qemu-utils

#Network things

inst samba
inst wsdd
inst sassc
inst nbd-client

#Below line Crashes LLStore due to fints included
#inst default-jre

#!/bin/bash

sudo cp ./nvidia-sleep.sh /usr/bin
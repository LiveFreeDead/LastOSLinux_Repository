#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
    inst google-chrome
        ;;

    dnf)
    sudo dnf -y install wget
    if ! [ -f "google-chrome-stable_current_x86_64.rpm" ] ; then
        wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
    fi
    sudo dnf -y install google-chrome-stable_current_x86_64.rpm

    inst google-chrome
        ;;

    apt)
    sudo apt install -y wget
    #Google Chrome (This self updates and is better than the flatpak stuff from the repository)
    if [ -f "/tmp/google-chrome-stable_current_amd64.deb" ] ; then
        cp /tmp/google-chrome-stable_current_amd64.deb ./
    else
        if ! [ -f "google-chrome-stable_current_amd64.deb" ] ; then
	        wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
        fi
    fi
    sudo apt install -y ./google-chrome-stable_current_amd64.deb
    inst google-chrome
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
    inst google-chrome
        ;;

    zypper)
    inst google-chrome
        ;;

    yum)
    inst google-chrome
        ;;

    emerge)
    inst google-chrome
        ;;

    eopkg)
    sudo eopkg bi -y --ignore-safety https://raw.githubusercontent.com/getsolus/3rd-party/master/network/web/browser/google-chrome-stable/pspec.xml
    sudo eopkg -y install google-chrome-*.eopkg;sudo rm google-chrome-*.eopkg
        ;;

    apk)
    inst google-chrome
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.

        #Just install the flatpak for these
        flatinst com.google.Chrome
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

exit 0
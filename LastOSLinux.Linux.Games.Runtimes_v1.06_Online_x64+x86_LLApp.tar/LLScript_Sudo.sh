#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#Make sure games can run in most distro's
sudo cp ./libFLAC.so.12 /lib/x86_64-linux-gnu/
sudo cp ./libjpeg.so.8.2.2 /lib/x86_64-linux-gnu/
sudo ln -sf /lib/x86_64-linux-gnu/libjpeg.so.8.2.2 /lib/x86_64-linux-gnu/libjpeg.so.8

inst libxft2
inst libxft2:i386

inst libfuse2
inst libfuse2:i386

inst libmpeg2-4

#Fedora and some Arch based extras
inst mesa-libGLU
inst mesa-libGLU.i686
inst SDL2-devel
inst SDL2-devel.i686
inst fltk
inst fltk.i686
inst fuse-libs
inst fuse-libs.i686
inst SDL2_image
inst SDL2_image.i686
inst SDL2_image-devel
inst SDL2_image-devel.i686
inst SDL2_gfx
inst SDL2_gfx.i686
inst SDL2_sound
inst SDL2_sound.i686
inst SDL2_mixer
inst SDL2_mixer.i686
inst SDL2_net
inst SDL2_net.i686
inst SDL2_ttf
inst SDL2_ttf.i686
inst libepoxy
inst libepoxy.i686
inst libstdc++
inst libstdc++.i686
inst libGLEW
inst libGLEW.i686
inst meson
inst pipewire-alsa
inst pipewire-alsa.i686

#Debian
inst libasound2
inst libasound2:i386
inst libasound2-plugins
inst libasound2-plugins:i386
inst libasound2-data
inst libfltk1.3
inst libfltk1.3:i386
inst pipewire-alsa
inst pipewire-alsa:i386
inst libudev1
inst libudev1:i386
inst lib32z1
inst libsdl1.2-compat
inst libsdl1.2debian:i386
inst libglu1-mesa
inst libglu1-mesa:i386
inst libglew-dev
inst libglew-dev:i386
inst libfreetype6-dev
inst libfreetype6
inst libsdl2-image-dev
inst libstdc++5
inst libfuse2:i386
inst libepoxy-dev
inst meson
inst nix-bin

inst libasound2:i686
inst libasound2-plugins:i686
inst libsdl2-2.0-0:i686
inst libfltk1.3:i686

inst libasound2.i686
inst libasound2-plugins.i686
inst libsdl2-2.0-0.i686
inst libfltk1.3.i686

inst lib32z1
inst libsdl1.2-compat

inst libopenal1
inst libopenal1:i386

inst libsdl2-2.0-0
inst libsdl2-2.0-0:i386

inst libsdl2-image-2.0-0
inst libsdl2-image-2.0-0:i386

inst libsdl2-mixer-2.0-0
inst libsdl2-mixer-2.0-0:i386

inst libsdl2-net-2.0-0
inst libsdl2-net-2.0-0:i386

exit 0
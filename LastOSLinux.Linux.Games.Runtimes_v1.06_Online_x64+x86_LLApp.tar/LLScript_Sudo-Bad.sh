#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
                pacman -Si "$PKG" &>/dev/null && AVAILABLE=true
                pacman -Q "$PKG" &>/dev/null && INSTALLED=true
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" reinstall --no-confirm "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" install --no-confirm "$PKG" &>/dev/null && OK=true
                fi
        if [[ $(find /var/lib/pacman/sync -name "*.db" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo pacman -Sy --noconfirm &>/dev/null
        fi
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
                dnf repoquery --quiet "$PKG" 2>/dev/null | grep -q . && AVAILABLE=true
                rpm -q "$PKG" &>/dev/null && INSTALLED=true
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
        if [[ $(find /var/cache/dnf -name "*.solv" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo dnf makecache --quiet &>/dev/null
        fi
        ;;

    apt)
                apt-cache show "$PKG" &>/dev/null && AVAILABLE=true
                dpkg-query -W -f='${Status}' "$PKG" 2>/dev/null | grep -q "install ok installed" && INSTALLED=true
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y install --reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
                sudo apt-mark manual "$PKG" &>/dev/null
        if [[ $(find /var/lib/apt/lists -name "*_Packages" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo apt-get update -qq &>/dev/null
        fi
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
                pacman -Si "$PKG" &>/dev/null && AVAILABLE=true
                pacman -Q "$PKG" &>/dev/null && INSTALLED=true
                # pacman -S --needed skips if current; drop --needed when reinstalling
                if $FORCE_REINSTALL && $INSTALLED; then
                    yes | sudo "$PM_CMD" -S --noconfirm "$PKG" &>/dev/null && OK=true
                else
                    yes | sudo "$PM_CMD" -S --needed --noconfirm "$PKG" &>/dev/null && OK=true
                fi
        if [[ $(find /var/lib/pacman/sync -name "*.db" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo pacman -Sy --noconfirm &>/dev/null
        fi
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
                zypper info "$PKG" &>/dev/null && AVAILABLE=true
                rpm -q "$PKG" &>/dev/null && INSTALLED=true
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" --non-interactive install --force "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" --non-interactive install "$PKG" &>/dev/null && OK=true
                fi
        if [[ $(find /var/cache/zypp/solv -name "*.solv" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo zypper --quiet refresh &>/dev/null
        fi
        ;;

    yum)
                dnf repoquery --quiet "$PKG" 2>/dev/null | grep -q . && AVAILABLE=true
                rpm -q "$PKG" &>/dev/null && INSTALLED=true
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
        if [[ $(find /var/cache/yum -name "repomd.xml" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo yum makecache --quiet &>/dev/null
        fi
        ;;

    emerge)
                emerge --search "$PKG" &>/dev/null && AVAILABLE=true
                sudo "$PM_CMD" "$PKG" &>/dev/null && OK=true
        if [[ $(find /var/cache/eix -name "portage.eix" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo emerge --sync &>/dev/null
        fi
        ;;

    eopkg)
                eopkg info "$PKG" &>/dev/null && AVAILABLE=true
                eopkg info --installed "$PKG" &>/dev/null && INSTALLED=true
                sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
        if [[ $(find /var/lib/eopkg/index -name "*.xml.bz2" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo eopkg update-repo &>/dev/null
        fi
        ;;

    apk)
                apk info "$PKG" &>/dev/null && AVAILABLE=true
                apk info -e "$PKG" &>/dev/null && INSTALLED=true
                sudo "$PM_CMD" add "$PKG" &>/dev/null && OK=true
        if [[ $(find /var/cache/apk -name "APKINDEX*" -mmin -1440 2>/dev/null | wc -l) -eq 0 ]]; then
            echo "Updating package cache..."
            sudo apk update &>/dev/null
        fi
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# Copy universal compatibility libraries (distro-agnostic)
sudo cp ./libFLAC.so.12 /lib/x86_64-linux-gnu/
sudo cp ./libjpeg.so.8.2.2 /lib/x86_64-linux-gnu/
sudo ln -sf /lib/x86_64-linux-gnu/libjpeg.so.8.2.2 /lib/x86_64-linux-gnu/libjpeg.so.8

exit 0
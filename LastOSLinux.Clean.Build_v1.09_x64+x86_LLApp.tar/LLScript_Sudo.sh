#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
    sudo pamac clean -v --no-confirm
    sudo pamac clean -b -v --no-confirm
        ;;

    dnf)
        ;;

    apt)
    bash remove-old-kernels.sh exec
    #Remove old Kernel Tools, they aren't needed about 19MB each
    sudo apt -y remove linux-tools-6.8.0-52 linux-tools-6.8.0-52-generic
    #Remove Excessive Wallpapers
    sudo apt -y remove mint-backgrounds-wilma mint-backgrounds-wallpapers
    sudo apt --fix-broken install -y
    #The line below will mark all current packages as part of the final image, that way autoremove will not think they are orphans and delete them, no need to run autoremove anymore as everything is marked manual now.
    sudo apt-mark manual $(apt-mark showauto)
    #sudo apt autoremove --yes
    #Clear the Cache of downloaded .deb files, safe
    sudo apt-get clean
    sudo apt-get autoclean
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#Cleanup previous build
sudo rm -f -r /home/eggs

#Clear the trash
#trash-empty
gio trash --empty

#Run eggs cleaner before I do the skel copy, may fix the apt issue? Will cause issues with apt (but fix now added below)
sudo eggs tools clean -n

#Cleanup extras

#Clean LastOS No Cache Repo Builder so end users get to use their cached items (icons in store etc).
rm -f /LastOS/LastOSLinux_Store/RepoBuilderNoCache

#Recent Files
rm $HOME/.local/share/recently-used.xbel
touch $HOME/.local/share/recently-used.xbel

#Bash
history -cw

##Temp - Gets ignored anyway
#sudo rm -rf /tmp/*

#Skipped as I don't keep /var in the install image'
##logs, cat will empty the active files, then delete them shouldn't hurt as it's kb of data'
#cat /dev/null > /var/log/syslog
#cat /dev/null > /var/log/kern.log
#sudo rm -rf /var/log/*

#Rotate Logs (Remove old logs)
sudo logrotate --force /etc/logrotate.conf 2>/dev/null

#Delete Firefox profile and cache
rm -rf $HOME/.mozilla
rm -rf $HOME/.cache/mozilla

#Others
rm -f $HOME/.xsession-errors
touch $HOME/.xsession-errors
rm -f $HOME/.xsession-errors.old
rm -f $HOME/.sudo_as_admin_successful

#Clean Up Cache repair (Hopefully I remembered to not be in capture mode)
sudo rm -f /etc/skel/.config/autostart/lastos-failsafe.desktop

exit 0
#!/bin/bash

sudo cp -rf ./Overlay/. $HOME/

#Set Dark Theme
sudo gsettings set org.x.apps.portal color-scheme "prefer-dark"
sudo gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
sudo gsettings set org.mate.desktop.interface color-scheme "prefer-dark"
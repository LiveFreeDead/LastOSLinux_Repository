#!/bin/bash

wine regedit /s ./Wine.reg

cp -rf ./Overlay/. $HOME/

#Set Dark Theme
gsettings set org.x.apps.portal color-scheme "prefer-dark"
gsettings set org.gnome.desktop.interface color-scheme "prefer-dark"
gsettings set org.mate.desktop.interface color-scheme "prefer-dark"
#!/bin/bash

x-terminal-emulator -e "flatpak install --system -y --noninteractive flathub org.kde.calligra"
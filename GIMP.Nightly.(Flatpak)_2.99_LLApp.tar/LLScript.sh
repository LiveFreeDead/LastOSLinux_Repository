#!/bin/bash

x-terminal-emulator -e "flatpak install -y --noninteractive ./org.gimp.GIMP.flatpakref"
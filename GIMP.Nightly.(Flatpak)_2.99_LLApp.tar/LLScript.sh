#!/bin/bash

x-terminal-emulator -e "flatpak install -system -y --noninteractive ./org.gimp.GIMP.flatpakref"
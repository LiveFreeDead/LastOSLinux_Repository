#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
    #Set No effects (Feels faster)
    gsettings set org.cinnamon desktop-effects false
    sudo gsettings set org.cinnamon desktop-effects false

    #Set Clock to 12H not 24H
    gsettings set org.cinnamon.desktop.interface clock-use-24h false
    sudo gsettings set org.cinnamon.desktop.interface clock-use-24h false

    ##Desktop Icon Grid Size
    gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002

    #Desktop Icons
    gsettings set org.nemo.desktop computer-icon-visible true
    gsettings set org.nemo.desktop trash-icon-visible true
    sudo gsettings set org.nemo.desktop computer-icon-visible true
    sudo gsettings set org.nemo.desktop trash-icon-visible true

    #Disable USB and Mounts from Desktop
    gsettings set org.nemo.desktop volumes-visible false
    sudo gsettings set org.nemo.desktop volumes-visible false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Lock when Screensaver
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    sudo gsettings set org.cinnamon.desktop.screensaver lock-enabled false

    #Enable Trackpad Gestures
    gsettings set org.cinnamon.gestures enabled true
    sudo gsettings set org.cinnamon.gestures enabled true

    #Show icons in Menus
    dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"
    sudo dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"

    #Configure Xed to be better
    gsettings set org.x.editor.preferences.editor display-line-numbers true
    gsettings set org.x.editor.preferences.editor bracket-matching false
    sudo gsettings set org.x.editor.preferences.editor display-line-numbers true
    sudo gsettings set org.x.editor.preferences.editor bracket-matching false
    #gsettings set org.x.editor.preferences.editor scheme 'classic' (Classic Theme has White Line Number bar, looks bad)
    gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"
    sudo gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"

    #Configure Nemo to have better Windowsy defaults
    gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    sudo gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    sudo gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    #gsettings set org.nemo.preferences inherit-folder-viewer true #Not Needed when default view is set
    gsettings set org.nemo.preferences show-full-path-titles true
    sudo gsettings set org.nemo.preferences show-full-path-titles true

    #Get thumbnails for images up to 4gb, should cover most movies etc too.
    gsettings set org.nemo.preferences thumbnail-limit 4294967295
    sudo gsettings set org.nemo.preferences thumbnail-limit 4294967295

    #Nemo Toolbar Icons
    gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    gsettings set org.nemo.preferences show-computer-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    sudo gsettings set org.nemo.preferences show-computer-icon-toolbar true

    #Show Hidden Files By Default in Sudo windows
    sudo gsettings set org.nemo.preferences show-hidden-files true

    #Sound FX
    gsettings set org.cinnamon.sounds login-enabled false
    gsettings set org.cinnamon.sounds logout-enabled false
    gsettings set org.cinnamon.sounds notification-enabled false
    #gsettings set org.cinnamon.desktop.sound volume-sound-enabled true
    #gsettings set org.cinnamon.desktop.sound volume-sound-file "/usr/share/sounds/freedesktop/stereo/audio-volume-change.oga"

    #Close Network on Nemo Sidebar (Opened by default)
    gsettings set org.nemo.window-state network-expanded false
    sudo gsettings set org.nemo.window-state network-expanded false

    #Change default Time on lock screen to have date
    #Lock Screen Formatting
    gsettings set org.cinnamon.desktop.screensaver use-custom-format true
    gsettings set org.cinnamon.desktop.screensaver time-format "%l:%M %p"
    gsettings set org.cinnamon.desktop.screensaver date-format "            %A, %b %d"

    #Disable Screen Lock and Resume With Lock
    gsettings set org.cinnamon.settings-daemon.plugins.power lock-on-suspend false
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    gsettings set org.cinnamon.desktop.screensaver lock-delay 0

    #Screen Sleep after 15 Minutes
    gsettings set org.cinnamon.desktop.session idle-delay 900

    #Show hover tooltips on files/folders (Not everyone will want this, I should make a Settings choices app)
    gsettings set org.nemo.preferences tooltips-show-file-type true
    gsettings set org.nemo.preferences tooltips-show-path true
    gsettings set org.nemo.preferences tooltips-in-icon-view true
    gsettings set org.nemo.preferences tooltips-on-desktop true
    sudo gsettings set org.nemo.preferences tooltips-show-file-type true
    sudo gsettings set org.nemo.preferences tooltips-show-path true
    sudo gsettings set org.nemo.preferences tooltips-in-icon-view true
    sudo gsettings set org.nemo.preferences tooltips-on-desktop true
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    #Desktop Icons
    gsettings set org.mate.caja.desktop computer-icon-visible true
    gsettings set org.mate.caja.desktop trash-icon-visible true

    #Sleep timers
    #gsettings set org.mate.power-manager sleep-computer-ac 1800
    gsettings set org.mate.power-manager sleep-display-ac 1200

    #gsettings set org.mate.power-manager sleep-computer-battery 180
    gsettings set org.mate.power-manager sleep-display-battery 120

    #Screensaver
    gsettings set org.mate.session idle-delay 20
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

exit 0
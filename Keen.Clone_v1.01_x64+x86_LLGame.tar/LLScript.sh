#!/bin/bash

rm $HOME/LLApps/GIMP3/GIMP-3.0.2-x86_64.AppImage
rm $HOME/LLApps/GIMP3/GIMP-3.0.4-x86_64.AppImage
#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------

#Get Best Terminal For LLStore (in order)
TERMS=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${TERMS[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#-------------------------------

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $PAMAC_CMD ]]; then #pamac
    PM=pamac
    echo "Package Manager: pamac"
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
    #Get i386 libs to make even more games work (like DOTT, Full Throttle, Gish etc)
    sudo dnf install -y mesa-libGLU mesa-libGLU.i686 SDL2-devel SDL2-devel.i686 fltk fltk.i686 fuse-libs fuse-libs.i686 SDL2_image SDL2_image.i686 SDL2_image-devel SDL2_image-devel.i686 SDL2_gfx SDL2_gfx.i686 SDL2_sound SDL2_sound.i686 SDL2_mixer SDL2_mixer.i686 SDL2_net SDL2_net.i686 SDL2_ttf SDL2_ttf.i686 libepoxy libepoxy.i686 libstdc++ libstdc++.i686 libGLEW libGLEW.i686 meson pipewire-alsa pipewire-alsa.i686
elif [[ ! -z $APT_CMD ]]; then #apt
    PM=apt
    echo "Package Manager: apt"
    #Get i386 libs to make even more games work (like DOTT, Full Throttle, Gish etc)
    sudo apt install -y libasound2:i386 libasound2-data libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386 pipewire-alsa:i386 libopenal1:i386 libudev1:i386 lib32z1 libsdl1.2-compat libsdl1.2debian:i386 libglu1-mesa:i386 meson libfreetype6-dev libfreetype6 libglew-dev libsdl2-image-dev libstdc++5 libfuse2:i386 libepoxy-dev nix-bin libsdl2-net-2.0-0
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then #eopkg
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Unknown Package Manager. Script section skipped"
fi


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  arch|endeavouros)
    ;;

  solus)
    ;;

  almalinux)
    ;;

  argent)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    #SUSE
    ;;

  zorin)
    ;;

  *)
    #All Others
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#Install Apps - using Inst function to work on many Distro's if the package(s) are available on its repositories.
#inst appname1 appname2 etc


#FlatPak Install Package System Wide (User mode should be done in non Sudo LLScript)
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --system -y --noninteractive flathub "


#----- Add Your Code Here ------

#This fixes the game in Mint, not sure if it'll work for other distro's or not, but should do some
inst libasound2:i386 libasound2-data libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386
inst libasound2:i686 libasound2-plugins:i686 libsdl2-2.0-0:i686 libfltk1.3:i686
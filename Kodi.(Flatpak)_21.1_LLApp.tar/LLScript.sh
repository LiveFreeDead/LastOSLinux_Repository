#!/bin/bash

x-terminal-emulator -e "flatpak install -system -y --noninteractive tv.kodi.Kodi"
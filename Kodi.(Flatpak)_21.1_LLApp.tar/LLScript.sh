#!/bin/bash

x-terminal-emulator -e "flatpak install -y tv.kodi.Kodi"
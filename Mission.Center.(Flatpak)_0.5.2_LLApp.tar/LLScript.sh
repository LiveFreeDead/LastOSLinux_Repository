#!/bin/bash

x-terminal-emulator -e "flatpak install -system -y --noninteractive io.missioncenter.MissionCenter"
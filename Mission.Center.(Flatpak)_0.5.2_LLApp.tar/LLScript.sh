#!/bin/bash

x-terminal-emulator -e "flatpak install -y io.missioncenter.MissionCenter"
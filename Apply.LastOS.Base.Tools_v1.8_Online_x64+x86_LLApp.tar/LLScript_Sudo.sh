#!/bin/bash

#Functions
inst () {
APT_CMD=$(which apt 2>/dev/null)
DNF_CMD=$(which dnf 2>/dev/null)
EMERGE_CMD=$(which emerge 2>/dev/null)
EOPKG_CMD=$(which eopkg 2>/dev/null)
APK_CMD=$(which apk 2>/dev/null)
PACMAN_CMD=$(which pacman 2>/dev/null)
ZYPPER_CMD=$(which zypper 2>/dev/null)
YUM_CMD=$(which yum 2>/dev/null)

if [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    yes | sudo $PACMAN_CMD -S $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}


#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(which apt 2>/dev/null)
DNF_CMD=$(which dnf 2>/dev/null)
EMERGE_CMD=$(which emerge 2>/dev/null)
EOPKG_CMD=$(which eopkg 2>/dev/null)
APK_CMD=$(which apk 2>/dev/null)
PACMAN_CMD=$(which pacman 2>/dev/null)
ZYPPER_CMD=$(which zypper 2>/dev/null)
YUM_CMD=$(which yum 2>/dev/null)


#Get Desktop Environmentto do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
    sudo dnf -y install https://mirrors.rpmfusion.org/free/fedora/rpmfusion-free-release-$(rpm -E %fedora).noarch.rpm https://mirrors.rpmfusion.org/nonfree/fedora/rpmfusion-nonfree-release-$(rpm -E %fedora).noarch.rpm

    sudo dnf -y install fedora-workstation-repositories

    sudo dnf config-manager setopt fedora-cisco-openh264.enabled=1

    sudo dnf -y update @core

    sudo dnf -y install fuse-libs.i686

elif [[ ! -z $APT_CMD ]]; then #apt
    echo "Package Manager: apt"
    PM=apt
    #Update repo's
    sudo apt -qq update -y 
    sudo apt upgrade -y
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Package Manager: none configured"
fi


#Get OS ID and do things depending on which one
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora) 
    ;;
  opensuse-tumbleweed) 
    ;;

 arch|endeavouros)
    ;;

  solus)
    ;;

  *) 
    echo "This is an unknown distribution."
      ;;
esac

#Do tasks for each Desktop Environment
case $XDG_SESSION_DESKTOP in

  cinnamon)
    ;;

  gnome|ubuntu)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac


#Install essentials if available on distro repos.
inst numlockx
inst xclip
inst xdotool
inst wget
inst gpg
inst yad
inst 7zip
#inst SDL2-devel
inst sdl2*
inst gnome-terminal


#FlatPak System Wide, user should be done in non Sudo script
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "

#Add /bin/run-1080p so you can run some games that draw the wrong size on High DPI screens (Requires xrandr, so doesn't work in wayland)
sudo cp ./run-1080p /bin
sudo chmod 755 /bin/run-1080p
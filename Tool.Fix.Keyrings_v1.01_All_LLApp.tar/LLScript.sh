#!/bin/bash

rm ~/.local/share/keyrings/*.keyring
rm ~/.local/share/keyrings/default
rm ~/.local/share/keyrings/user.keystore
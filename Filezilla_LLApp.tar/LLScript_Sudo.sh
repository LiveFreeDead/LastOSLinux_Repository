#!/bin/bash

sudo apt install --yes filezilla
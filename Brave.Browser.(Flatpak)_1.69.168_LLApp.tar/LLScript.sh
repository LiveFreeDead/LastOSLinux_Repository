#!/bin/bash

x-terminal-emulator -e "flatpak install -y com.brave.Browser"
#!/bin/bash

sudo cp -rf ./firmware-TAS2781-Linux-6.6/. /lib/firmware/
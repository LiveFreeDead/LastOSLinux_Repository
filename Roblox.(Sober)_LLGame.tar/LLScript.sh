#!/bin/bash 

x-terminal-emulator -e "flatpak install -y --user https://sober.vinegarhq.org/sober.flatpakref"
#!/bin/bash

#Add "org.name.thing" below and unremark to install a Flatpak
x-terminal-emulator -e "flatpak install --user -y --noninteractive flathub org.qbittorrent.qBittorrent"

mkdir -p $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/

cp -rf ./nova3 $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/
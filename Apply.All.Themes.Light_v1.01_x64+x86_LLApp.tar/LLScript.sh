#!/bin/bash

wine regedit /s ./Wine.reg

cp -rf ./Overlay/. $HOME/

#Set Theme
gsettings set org.x.apps.portal color-scheme "prefer-light"
gsettings set org.gnome.desktop.interface color-scheme "prefer-light"
gsettings set org.mate.desktop.interface color-scheme "prefer-light"
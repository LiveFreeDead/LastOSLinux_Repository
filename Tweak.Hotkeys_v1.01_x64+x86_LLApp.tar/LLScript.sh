#!/bin/bash

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done


#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    #hotkeys to system monitor
    # system monitor keybinding for (ctrl + shift + escape) and (ctrl + alt + delete)
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/command "'gnome-system-monitor'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/name "'System Monitor'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/binding "['<Primary><Shift>Escape', '<Primary><Alt>Delete']"
    dconf write /org/cinnamon/desktop/keybindings/media-keys/logout "['<Primary><Alt>o']"

    #ctrl break to close all wine stuff, wineserver -k
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/command "'quitwine.sh'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/name "'Kill WINE'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/binding "['<Primary>Break']"

    #Alt break to Fix display
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/command "'xrandr -s 0'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/name "'Fix Screen Res'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/binding "['<Alt>Break']"

    #ctrl shift f4 to close all wine stuff, wineserver -k
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/command "'quitwine.sh'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/name "'Kill WINE 2'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/binding "['<Primary><Shift>F4']"

    #Alt + = For Brightness Up
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3', 'custom4']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/command "'xdotool key --clearmodifiers XF86MonBrightnessUp'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/name "'Brightness Up'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/binding "['<Alt>equal']"

    #Alt + - For Brightness Down
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3', 'custom4', 'custom5']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/command "'xdotool key --clearmodifiers XF86MonBrightnessDown'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/name "'Brightness Down'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/binding "['<Alt>minus']"
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    ;;

  zorin)
    ;;

  *)
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#FlatPak Install Package for User
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "


#----- Add Your Code Here ------
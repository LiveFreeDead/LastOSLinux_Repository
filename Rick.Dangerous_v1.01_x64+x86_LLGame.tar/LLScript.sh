#!/bin/bash

cp -rf ./persepolis_download_manager $HOME/.config
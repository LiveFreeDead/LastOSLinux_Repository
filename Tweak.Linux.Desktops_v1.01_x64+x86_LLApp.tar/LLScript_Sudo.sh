#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------

#Get Best Terminal For LLStore (in order)
TERMS=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${TERMS[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#-------------------------------

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $PAMAC_CMD ]]; then #pamac
    PM=pamac
    echo "Package Manager: pamac"
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
elif [[ ! -z $APT_CMD ]]; then #apt
    PM=apt
    echo "Package Manager: apt"
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then #eopkg
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Unknown Package Manager. Script section skipped"
fi


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    #Set No effects (Feels faster)
    gsettings set org.cinnamon desktop-effects false
    sudo gsettings set org.cinnamon desktop-effects false

    #Set Clock to 12H not 24H
    gsettings set org.cinnamon.desktop.interface clock-use-24h false
    sudo gsettings set org.cinnamon.desktop.interface clock-use-24h false

    ##Desktop Icon Grid Size
    gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002


    #Desktop Icons
    gsettings set org.nemo.desktop computer-icon-visible true
    gsettings set org.nemo.desktop trash-icon-visible true
    sudo gsettings set org.nemo.desktop computer-icon-visible true
    sudo gsettings set org.nemo.desktop trash-icon-visible true


    #Disable USB and Mounts from Desktop
    gsettings set org.nemo.desktop volumes-visible false
    sudo gsettings set org.nemo.desktop volumes-visible false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Lock when Screensaver
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    sudo gsettings set org.cinnamon.desktop.screensaver lock-enabled false

    #Enable Trackpad Gestures
    gsettings set org.cinnamon.gestures enabled true
    sudo gsettings set org.cinnamon.gestures enabled true

    #Show icons in Menus
    dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"
    sudo dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"

    #Configure Xed to be better
    gsettings set org.x.editor.preferences.editor display-line-numbers true
    gsettings set org.x.editor.preferences.editor bracket-matching false
    sudo gsettings set org.x.editor.preferences.editor display-line-numbers true
    sudo gsettings set org.x.editor.preferences.editor bracket-matching false
    #gsettings set org.x.editor.preferences.editor scheme 'classic' (Classic Theme has White Line Number bar, looks bad)
    gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"
    sudo gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"

    #Configure Nemo to have better Windowsy defaults
    gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    sudo gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    sudo gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    #gsettings set org.nemo.preferences inherit-folder-viewer true #Not Needed when default view is set
    gsettings set org.nemo.preferences show-full-path-titles true
    sudo gsettings set org.nemo.preferences show-full-path-titles true

    #Get thumbnails for images up to 4gb, should cover most movies etc too.
    gsettings set org.nemo.preferences thumbnail-limit 4294967295
    sudo gsettings set org.nemo.preferences thumbnail-limit 4294967295

    #Nemo Toolbar Icons
    gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    gsettings set org.nemo.preferences show-computer-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    sudo gsettings set org.nemo.preferences show-computer-icon-toolbar true

    #Show Hidden Files By Default in Sudo windows
    sudo gsettings set org.nemo.preferences show-hidden-files true

    #Sound FX
    gsettings set org.cinnamon.sounds login-enabled false
    gsettings set org.cinnamon.sounds logout-enabled false
    gsettings set org.cinnamon.sounds notification-enabled false
    #gsettings set org.cinnamon.desktop.sound volume-sound-enabled true
    #gsettings set org.cinnamon.desktop.sound volume-sound-file "/usr/share/sounds/freedesktop/stereo/audio-volume-change.oga"

    #Close Network on Nemo Sidebar (Opened by default)
    gsettings set org.nemo.window-state network-expanded false
    sudo gsettings set org.nemo.window-state network-expanded false

    #Change default Time on lock screen to have date
    #Lock Screen Formatting
    gsettings set org.cinnamon.desktop.screensaver use-custom-format true
    gsettings set org.cinnamon.desktop.screensaver time-format "%l:%M %p"
    gsettings set org.cinnamon.desktop.screensaver date-format "            %A, %b %d"

    #Disable Screen Lock and Resume With Lock
    gsettings set org.cinnamon.settings-daemon.plugins.power lock-on-suspend false
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    gsettings set org.cinnamon.desktop.screensaver lock-delay 0

    #Screen Sleep after 15 Minutes
    gsettings set org.cinnamon.desktop.session idle-delay 900



    #Show hover tooltips on files/folders (Not everyone will want this, I should make a Settings choices app)
    gsettings set org.nemo.preferences tooltips-show-file-type true
    gsettings set org.nemo.preferences tooltips-show-path true
    gsettings set org.nemo.preferences tooltips-in-icon-view true
    gsettings set org.nemo.preferences tooltips-on-desktop true
    sudo gsettings set org.nemo.preferences tooltips-show-file-type true
    sudo gsettings set org.nemo.preferences tooltips-show-path true
    sudo gsettings set org.nemo.preferences tooltips-in-icon-view true
    sudo gsettings set org.nemo.preferences tooltips-on-desktop true
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    #Desktop Icons
    gsettings set org.mate.caja.desktop computer-icon-visible true
    gsettings set org.mate.caja.desktop trash-icon-visible true

    #Sleep timers
    #gsettings set org.mate.power-manager sleep-computer-ac 1800
    gsettings set org.mate.power-manager sleep-display-ac 1200

    #gsettings set org.mate.power-manager sleep-computer-battery 180
    gsettings set org.mate.power-manager sleep-display-battery 120

    #Screensaver
    gsettings set org.mate.session idle-delay 20
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    #SUSE
    ;;

  zorin)
    ;;

  *)
    #All Others
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#Install Apps - using Inst function to work on many Distro's if the package(s) are available on its repositories.
#inst appname1 appname2 etc


#FlatPak Install Package System Wide (User mode should be done in non Sudo LLScript)
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --system -y --noninteractive flathub "


#----- Add Your Code Here ------
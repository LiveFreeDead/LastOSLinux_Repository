#!/bin/bash

sudo apt install --yes audacity
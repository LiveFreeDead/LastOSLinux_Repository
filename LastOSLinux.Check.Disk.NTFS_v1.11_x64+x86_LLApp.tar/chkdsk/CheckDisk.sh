#!/bin/bash
# CheckDisk.sh
# GUI tool to run chkufsd on unmounted NTFS partitions.
#
# Shows a three-column list of all unmounted NTFS partitions:
#   Label  |  Partition  |  Size
# Only unmounted partitions are listed (safe to check without data corruption).
# Requires: lsblk, zenity, chkufsd (in the same directory as this script),
#           and a terminal emulator.

# ---------------------------------------------------------------------------
# Build the partition list using lsblk's key=value (-P) output format.
# This safely handles partition labels that contain spaces or special chars.
# ---------------------------------------------------------------------------

ROWS=()   # Flat array fed to zenity: Label1 Name1 Size1  Label2 Name2 Size2 ...

while IFS= read -r line; do

    # Parse key=value pairs from lsblk -P output:
    #   FSTYPE="ntfs" MOUNTPOINT="" NAME="sda1" LABEL="My Drive" SIZE="232.9G"
    eval "$line"   # safe here — lsblk controls the format, no user input

    # Only process unmounted NTFS partitions
    [ "$FSTYPE" = "ntfs" ] || continue
    [ -z "$MOUNTPOINT" ]   || continue

    # Use "(no label)" if the partition has no label set
    DISPLAY_LABEL="${LABEL:-"(no label)"}"

    ROWS+=( "$DISPLAY_LABEL" "$NAME" "$SIZE" )

done < <(lsblk -Pn -o FSTYPE,MOUNTPOINT,NAME,LABEL,SIZE)

# ---------------------------------------------------------------------------
# Nothing found
# ---------------------------------------------------------------------------
if [ "${#ROWS[@]}" -eq 0 ]; then
    zenity --info \
        --title="Check Disk NTFS" \
        --text="No unmounted NTFS partitions were found." \
        --width=380
    exit 0
fi

# ---------------------------------------------------------------------------
# Show the selection dialog.
# --print-column=2 returns only the Partition (NAME) column value on confirm,
# so $drive will be e.g. "sda1" regardless of which column the user clicked.
# ---------------------------------------------------------------------------
drive=$(zenity \
    --list \
    --width=620 --height=400 \
    --title="Check Disk NTFS" \
    --text="Select an unmounted NTFS partition to check:" \
    --column="Label" \
    --column="Partition" \
    --column="Size" \
    --print-column=2 \
    "${ROWS[@]}")

# ---------------------------------------------------------------------------
# Cancelled / nothing selected
# ---------------------------------------------------------------------------
if [ -z "$drive" ]; then
    echo "Skipped — no partition selected."
    exit 0
fi

# ---------------------------------------------------------------------------
# Launch chkufsd in a terminal. chkufsd lives in the same folder as this
# script so we resolve its path explicitly rather than relying on CWD.
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CHKUFSD="$SCRIPT_DIR/chkufsd"

if [ ! -f "$CHKUFSD" ]; then
    zenity --error \
        --title="Check Disk NTFS" \
        --text="chkufsd not found at:\n$CHKUFSD\n\nPlease place chkufsd in the same folder as this script." \
        --width=420
    exit 1
fi

CMD="sudo \"$CHKUFSD\" -fs:ntfs /dev/$drive -f; echo; echo 'Done — press Enter to close.'; read"

# Try terminals in order of preference
for term in gnome-terminal konsole xfce4-terminal mate-terminal lxterminal \
            x-terminal-emulator xterm; do
    if command -v "$term" &>/dev/null; then
        case "$term" in
            gnome-terminal) "$term" -- bash -c "$CMD" ;;
            *)              "$term" -e "bash -c \"$CMD\"" ;;
        esac
        exit 0
    fi
done

# No GUI terminal found — run directly (sudo will prompt in the same shell)
eval "$CMD"

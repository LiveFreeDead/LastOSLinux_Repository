#!/bin/bash
# FixDirtyBit.sh
# GUI tool to repair FAT32 and exFAT partitions with dirty bit / filesystem
# errors — the main cause of USB drives going read-only after an improper
# removal.
#
# Shows ALL FAT32 and exFAT partitions (mounted or not), including their
# current mount status so you can see which ones need attention.
#
# What it does:
#   FAT32/vFAT  →  sudo fsck.fat  -w -r -l -a -v -t  /dev/<partition>
#   exFAT       →  sudo fsck.exfat -p                 /dev/<partition>
#
# If the selected partition is currently MOUNTED (even read-only), the script
# will unmount it automatically before running the check, then offer to
# remount it afterwards.
#
# Required packages:
#   FAT32:  dosfstools        (sudo apt install dosfstools)
#   exFAT:  exfatprogs        (sudo apt install exfatprogs)
#           OR  exfat-fuse + exfat-utils  (older Ubuntu/Mint)
#
# Note: The drive must not be in use by any application when the check runs.
# Close any file manager windows showing the drive before starting.

# ---------------------------------------------------------------------------
# Check required tools are installed — auto-install if missing
# ---------------------------------------------------------------------------
MISSING_PKGS=""
command -v fsck.fat   &>/dev/null || MISSING_PKGS+=" dosfstools"
command -v fsck.exfat &>/dev/null || MISSING_PKGS+=" exfatprogs"

if [ -n "$MISSING_PKGS" ]; then
    zenity --question \
        --title="Fix Dirty Bit — Missing Tools" \
        --width=480 \
        --text="The following required packages are not installed:$(echo "$MISSING_PKGS" | tr ' ' '\n' | grep -v '^$' | sed 's/^/\n  • /')\n\nInstall them now? (requires sudo)\nRe-run this tool afterwards." \
        || exit 0

    CMD="sudo apt install -y $MISSING_PKGS; echo; echo 'Done — press Enter to close.'; read"
    for TERM in gnome-terminal konsole xfce4-terminal mate-terminal lxterminal \
                x-terminal-emulator xterm; do
        if command -v "$TERM" &>/dev/null; then
            case "$TERM" in
                gnome-terminal) "$TERM" -- bash -c "$CMD" ;;
                *)              "$TERM" -e "bash -c \"$CMD\"" ;;
            esac
            exit 0
        fi
    done
    eval "$CMD"
    exit 0
fi

# ---------------------------------------------------------------------------
# Build partition list from lsblk
# lsblk -Pn outputs safe KEY="value" pairs; RO=1 means mounted read-only
# ---------------------------------------------------------------------------
ROWS=()     # flat array for zenity: Label Partition Size Type Status
NAME_ARR=() # parallel: device name
TYPE_ARR=() # parallel: fstype for choosing the right fsck
MNT_ARR=()  # parallel: mountpoint (empty if unmounted)

while IFS= read -r line; do

    eval "$line"   # safe — lsblk controls the format

    case "$FSTYPE" in
        vfat)   DISPLAY_TYPE="FAT32"  ;;
        exfat)  DISPLAY_TYPE="exFAT"  ;;
        *)      continue ;;
    esac

    # Status column
    if [ -z "$MOUNTPOINT" ]; then
        STATUS="Unmounted"
    elif [ "$RO" = "1" ]; then
        STATUS="⚠ Mounted Read-Only"
    else
        STATUS="Mounted Read-Write"
    fi

    DISPLAY_LABEL="${LABEL:-"(no label)"}"

    ROWS+=( "$DISPLAY_LABEL" "$NAME" "$SIZE" "$DISPLAY_TYPE" "$STATUS" )
    NAME_ARR+=( "$NAME" )
    TYPE_ARR+=( "$FSTYPE" )
    MNT_ARR+=( "$MOUNTPOINT" )

done < <(lsblk -Pn -o FSTYPE,MOUNTPOINT,NAME,LABEL,SIZE,RO)

# ---------------------------------------------------------------------------
# Nothing found
# ---------------------------------------------------------------------------
if [ "${#ROWS[@]}" -eq 0 ]; then
    zenity --info \
        --title="Fix Dirty Bit" \
        --text="No FAT32 or exFAT partitions were found." \
        --width=380
    exit 0
fi

# ---------------------------------------------------------------------------
# Selection dialog
# --print-column=2 returns the Partition (NAME) column
# ---------------------------------------------------------------------------
SELECTED=$(zenity \
    --list \
    --width=680 --height=420 \
    --title="Fix Dirty Bit — FAT32 / exFAT Repair" \
    --text="Select a partition to check and repair dirty bit / filesystem errors.\nRead-Only partitions are the ones typically needing repair." \
    --column="Label" \
    --column="Partition" \
    --column="Size" \
    --column="Type" \
    --column="Status" \
    --print-column=2 \
    "${ROWS[@]}")

[ -z "$SELECTED" ] && { echo "Cancelled."; exit 0; }

# ---------------------------------------------------------------------------
# Find matching row in our parallel arrays
# ---------------------------------------------------------------------------
IDX=-1
for i in "${!NAME_ARR[@]}"; do
    if [ "${NAME_ARR[$i]}" = "$SELECTED" ]; then
        IDX=$i
        break
    fi
done

if [ "$IDX" -eq -1 ]; then
    zenity --error --text="Could not find partition data for: $SELECTED" --width=380
    exit 1
fi

PART_NAME="${NAME_ARR[$IDX]}"
PART_TYPE="${TYPE_ARR[$IDX]}"
PART_MNT="${MNT_ARR[$IDX]}"
DEVICE="/dev/$PART_NAME"

# ---------------------------------------------------------------------------
# Choose fsck command
# ---------------------------------------------------------------------------
case "$PART_TYPE" in
    vfat)
        if ! command -v fsck.fat &>/dev/null; then
            zenity --error --text="fsck.fat not found.\nInstall dosfstools first:\nsudo apt install dosfstools" --width=400
            exit 1
        fi
        FSCK_CMD="sudo fsck.fat -w -r -l -a -v -t $DEVICE"
        ;;
    exfat)
        if ! command -v fsck.exfat &>/dev/null; then
            zenity --error --text="fsck.exfat not found.\nInstall exfatprogs first:\nsudo apt install exfatprogs" --width=400
            exit 1
        fi
        FSCK_CMD="sudo fsck.exfat -p $DEVICE"
        ;;
    *)
        zenity --error --text="Unsupported filesystem type: $PART_TYPE" --width=380
        exit 1
        ;;
esac

# ---------------------------------------------------------------------------
# Confirm before proceeding — extra warning if mounted
# ---------------------------------------------------------------------------
WARN_EXTRA=""
if [ -n "$PART_MNT" ]; then
    WARN_EXTRA="\n\n⚠ This partition is currently mounted at:\n  $PART_MNT\n\nIt will be UNMOUNTED automatically before the repair runs.\nClose any applications using this drive first."
fi

zenity --question \
    --title="Fix Dirty Bit — Confirm" \
    --width=460 \
    --text="About to check and repair:\n\n  Device: $DEVICE\n  Type:   $PART_TYPE\n  Label:  ${LABEL:-"(no label)"}${WARN_EXTRA}\n\nProceed?" \
    || { echo "Cancelled."; exit 0; }

# ---------------------------------------------------------------------------
# Unmount if mounted
# ---------------------------------------------------------------------------
REMOUNT_AFTER=false
if [ -n "$PART_MNT" ]; then
    zenity --info \
        --title="Fix Dirty Bit" \
        --text="Unmounting $DEVICE from $PART_MNT ..." \
        --timeout=3 \
        --width=380 2>/dev/null &
    if ! sudo umount "$DEVICE" 2>/tmp/fixdirty_umount_err; then
        ERR=$(cat /tmp/fixdirty_umount_err)
        zenity --error \
            --title="Fix Dirty Bit — Unmount Failed" \
            --width=480 \
            --text="Could not unmount $DEVICE:\n\n$ERR\n\nClose any applications using the drive and try again."
        exit 1
    fi
    REMOUNT_AFTER=true
fi

# ---------------------------------------------------------------------------
# Build the terminal command
# Ends with "read" so the window stays open for you to read the output
# ---------------------------------------------------------------------------
CMD="echo 'Running: $FSCK_CMD'
echo '-------------------------------------------'
$FSCK_CMD
STATUS=\$?
echo ''
echo '-------------------------------------------'
if [ \$STATUS -eq 0 ]; then
    echo '✓ Check complete — no errors found (or all errors repaired).'
else
    echo \"⚠ fsck exited with status \$STATUS — some errors may remain.\"
    echo '  If the dirty bit persists, try running the check a second time.'
fi
echo ''
echo 'Press Enter to close...'
read"

# If we unmounted, add a remount option
if $REMOUNT_AFTER; then
    CMD="$CMD
# Offer remount after press Enter returns
# (This runs after the terminal user presses Enter)"
fi

# ---------------------------------------------------------------------------
# Launch in a terminal
# ---------------------------------------------------------------------------
for TERM in gnome-terminal konsole xfce4-terminal mate-terminal lxterminal \
            x-terminal-emulator xterm; do
    if command -v "$TERM" &>/dev/null; then
        case "$TERM" in
            gnome-terminal) "$TERM" -- bash -c "$CMD" ;;
            *)              "$TERM" -e "bash -c \"$CMD\"" ;;
        esac
        break
    fi
done

# ---------------------------------------------------------------------------
# Wait a moment for fsck to finish, then offer remount
# (Small sleep so the terminal has time to complete before dialog pops up)
# ---------------------------------------------------------------------------
if $REMOUNT_AFTER; then
    sleep 3
    zenity --question \
        --title="Fix Dirty Bit — Remount?" \
        --width=420 \
        --text="Repair complete.\n\nWould you like to remount $DEVICE?\n(Your file manager may have already done this automatically)" \
        && udisksctl mount -b "$DEVICE" 2>/dev/null \
        || mount "$DEVICE" "$PART_MNT" 2>/dev/null \
        || echo "Could not remount automatically — plug the drive out and back in."
fi

#!/bin/bash

x-terminal-emulator -e "flatpak install -y flathub fr.handbrake.ghb"
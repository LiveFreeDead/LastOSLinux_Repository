#!/bin/bash
# High-Safety Kernel & Tools Cleanup for Custom Distro Building

# 1. Identify the current kernel
IN_USE=$(uname -r)
# Extract the version number only (e.g., 6.8.0-52) for tools matching
VER_ONLY=$(echo "$IN_USE" | cut -d'-' -f1,2)

echo "Keep-list: Kernel and Tools for $IN_USE"

# 2. Identify OLD kernels, headers, modules, AND tools
# We exclude the current version and the generic meta-packages
OLD_PACKAGES=$(dpkg-query -W -f='${Package}\n' \
    'linux-image-*' \
    'linux-headers-*' \
    'linux-modules-*' \
    'linux-tools-*' \
    'linux-cloud-tools-*' | \
    grep -v "$IN_USE" | \
    grep -v "$VER_ONLY" | \
    grep -vE "linux-image-generic|linux-headers-generic|linux-image-amd64|linux-image-arm64|linux-libc-dev" | \
    grep -vE "linux-tools-common|linux-tools-generic")

if [ -z "$OLD_PACKAGES" ]; then
    echo "No old kernels or tools found to remove."
else
    echo "The following will be purged:"
    echo "$OLD_PACKAGES"
    
    if [ "$1" == "exec" ]; then
        # --- THE SHIELD ---
        # Mark everything currently installed as 'manual' so APT 
        # cannot drag Wine/GStreamer down during the kernel purge.
        echo "Protecting currently installed packages (Wine/Codecs/etc)..."
        apt-mark manual $(apt-mark showauto) 2>/dev/null
        
        echo "Purging old kernels and tools..."
        # Purge removes the config files too, keeping the /etc folder clean
        apt-get purge -y $OLD_PACKAGES
        
        # Safe to run now because we manually marked everything else
        apt-get autoremove --purge -y
        
        # 3. Clean up orphaned module directories in /lib/modules
        echo "Cleaning up /lib/modules..."
        find /lib/modules -mindepth 1 -maxdepth 1 -type d ! -name "$IN_USE" -exec rm -rf {} +
        
        # 4. Final APT cache cleanup
        apt-get clean
    else
        echo -e "\nDRY RUN: Run with 'exec' to apply changes: sudo $0 exec"
    fi
fi

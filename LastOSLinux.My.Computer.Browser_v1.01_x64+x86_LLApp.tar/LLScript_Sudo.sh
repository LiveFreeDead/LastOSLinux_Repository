#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2


echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# =============================================================================
# add_mycomputer_icon.sh
# Installs the Computer drive picker and adds a desktop icon for it.
# =============================================================================

# -----------------------------------------------------------------------------
# 0. Relaunch inside a terminal if not already in one
# -----------------------------------------------------------------------------
if [ ! -t 0 ]; then
    SCRIPT_PATH="$(realpath "$0")"
    for TERM_EMU in konsole xterm xfce4-terminal gnome-terminal mate-terminal; do
        if command -v "$TERM_EMU" &>/dev/null; then
            case "$TERM_EMU" in
                konsole)        exec konsole -e bash "$SCRIPT_PATH" ;;
                xterm)          exec xterm -e bash "$SCRIPT_PATH" ;;
                xfce4-terminal) exec xfce4-terminal -e "bash \"$SCRIPT_PATH\"" ;;
                gnome-terminal) exec gnome-terminal -- bash "$SCRIPT_PATH" ;;
                mate-terminal)  exec mate-terminal -- bash "$SCRIPT_PATH" ;;
            esac
        fi
    done
    if command -v kdialog &>/dev/null; then
        kdialog --error "No terminal emulator found. Please install Konsole and re-run."
    fi
    exit 1
fi

set -euo pipefail

BROWSE_SCRIPT="$HOME/.local/bin/computer-browse.py"
DESKTOP_DIR="$HOME/Desktop"
LAUNCHER="$DESKTOP_DIR/Computer.desktop"
PLASMA_CONFIG="$HOME/.config/plasma-org.kde.plasma.desktop-appletsrc"

# -----------------------------------------------------------------------------
# 1. Check Python3 + PyQt6 are available, install PyQt6 if missing
# -----------------------------------------------------------------------------
echo "▶  Checking Python3…"
if ! command -v python3 &>/dev/null; then
    echo "✘  python3 not found. Please install it and re-run."
    exit 1
fi
echo "✔  Python3 found: $(python3 --version)"

echo "▶  Checking PyQt6…"
if ! python3 -c "import PyQt6" &>/dev/null; then
    echo "▶  PyQt6 not found — installing via pacman…"
    sudo pacman -S --noconfirm python-pyqt6
fi
echo "✔  PyQt6 available"

# -----------------------------------------------------------------------------
# 2. Enable NTFS support (ntfs3 kernel module + ntfs-3g userspace fallback)
# -----------------------------------------------------------------------------

# Check each condition independently — only run sudo for what's actually missing
NTFS_OK=true

ntfs3g_present=false
ntfs3_mod_conf=false
ntfs3_mod_loaded=false
udev_rule_present=false

pacman -Q ntfs-3g &>/dev/null           && ntfs3g_present=true
[[ -f /etc/modules-load.d/ntfs3.conf ]] && ntfs3_mod_conf=true
lsmod | grep -q ntfs3                   && ntfs3_mod_loaded=true
[[ -f /etc/udev/rules.d/99-ntfs3.rules ]] && udev_rule_present=true

if $ntfs3g_present && $ntfs3_mod_conf && $udev_rule_present; then
    echo "✔  NTFS support already configured — skipping"
else
    echo "▶  Setting up NTFS support…"
    NTFS_OK=false

    if ! $ntfs3g_present; then
        echo "▶  Installing ntfs-3g…"
        sudo pacman -S --noconfirm ntfs-3g
    fi

    if ! $ntfs3_mod_loaded; then
        sudo modprobe ntfs3 2>/dev/null \
            && echo "✔  ntfs3 kernel module loaded" \
            || echo "⚠  ntfs3 unavailable, ntfs-3g will handle NTFS instead"
    fi

    if ! $ntfs3_mod_conf; then
        echo ntfs3 | sudo tee /etc/modules-load.d/ntfs3.conf > /dev/null
        echo "✔  ntfs3 set to load on boot"
    fi

    if ! $udev_rule_present; then
        echo 'ENV{ID_FS_TYPE}=="ntfs", ENV{ID_FS_TYPE}="ntfs3"' \
            | sudo tee /etc/udev/rules.d/99-ntfs3.rules > /dev/null
        sudo udevadm control --reload-rules
        echo "✔  udev rule added: NTFS partitions will use ntfs3 driver"
    fi

    echo "✔  NTFS support configured"
fi

# -----------------------------------------------------------------------------
# 3. Install the browse script
# -----------------------------------------------------------------------------
mkdir -p "$HOME/.local/bin"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy computer-browse.py from same directory as this script
if [[ -f "$SCRIPT_DIR/computer-browse.py" ]]; then
    cp "$SCRIPT_DIR/computer-browse.py" "$BROWSE_SCRIPT"
else
    echo "✘  computer-browse.py not found next to this script."
    echo "   Make sure both files are in the same folder."
    #exit 1
fi

chmod +x "$BROWSE_SCRIPT"
echo "✔  Installed browse script to $BROWSE_SCRIPT"

# -----------------------------------------------------------------------------
# 4. Create the .desktop launcher
# -----------------------------------------------------------------------------
mkdir -p "$DESKTOP_DIR"

cat > "$LAUNCHER" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Computer
Comment=Browse drives and storage devices
Exec=python3 $BROWSE_SCRIPT
Icon=computer
Terminal=false
Categories=System;FileManager;
EOF

chmod +x "$LAUNCHER"

# Trust the .desktop file
if command -v gio &>/dev/null; then
    gio set "$LAUNCHER" metadata::trusted true 2>/dev/null || true
fi
echo "✔  Created desktop icon: $LAUNCHER"

# -----------------------------------------------------------------------------
# 5. Set top-left grid position
# -----------------------------------------------------------------------------
KWRITECONFIG=""
command -v kwriteconfig5 &>/dev/null && KWRITECONFIG="kwriteconfig5"
command -v kwriteconfig6 &>/dev/null && KWRITECONFIG="kwriteconfig6"

if [[ -n "$KWRITECONFIG" ]]; then
    $KWRITECONFIG \
        --file "$PLASMA_CONFIG" \
        --group "DesktopIcons" \
        --key "${LAUNCHER}" \
        "1,1"
    echo "✔  Requested top-left grid position"
fi

echo ""
echo "All done! 🖥️"
echo "A 'Computer' icon has been added to your desktop."

exit 0
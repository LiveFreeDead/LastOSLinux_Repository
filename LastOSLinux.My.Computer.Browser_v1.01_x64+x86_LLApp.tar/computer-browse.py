#!/usr/bin/env python3
# =============================================================================
# mycomputer-browse.py
# A "Computer" style drive picker using PyQt6.
# Shows mounted and unmounted drives. Unmounted drives are mounted via
# udisksctl (no sudo needed) then opened in Dolphin.
# Cards reflow to window width with vertical scroll only.
# =============================================================================

import sys
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
from urllib.parse import urlparse, unquote
from pathlib import Path

CONFIG_FILE = Path.home() / ".config" / "computer-browse.json"


def load_config():
    try:
        return json.loads(CONFIG_FILE.read_text())
    except Exception:
        return {}


def save_config(data):
    try:
        CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
        CONFIG_FILE.write_text(json.dumps(data))
    except Exception:
        pass
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel,
    QProgressBar, QFrame, QScrollArea, QSizePolicy
)
from PyQt6.QtGui import QIcon, QFont
from PyQt6.QtCore import Qt, QSize, QTimer


CARD_WIDTH  = 160
CARD_HEIGHT = 175
CARD_GAP    = 12


def get_drives():
    """Return mounted and unmounted real block partitions/disks."""
    result = subprocess.run(
        ["lsblk", "--json", "--output",
         "NAME,SIZE,FSTYPE,MOUNTPOINT,LABEL,TYPE,RM,HOTPLUG,PATH"],
        capture_output=True, text=True
    )
    data = json.loads(result.stdout)
    drives = []

    skip_fs = {"tmpfs", "devtmpfs", "devpts", "sysfs", "proc",
               "cgroup", "cgroup2", "hugetlbfs", "mqueue", "debugfs",
               "securityfs", "pstore", "bpf", "tracefs", "fusectl",
               "configfs", "ramfs", "efivarfs", "squashfs", ""}
    skip_mounts = {"/boot", "/boot/efi", "/efi", "/proc",
                   "/sys", "/dev", "/run", "/tmp"}

    def walk(devices):
        for dev in devices:
            mountpoint = dev.get("mountpoint") or ""
            fstype     = dev.get("fstype") or ""
            dtype      = dev.get("type") or ""
            label      = dev.get("label") or ""
            name       = dev.get("name") or ""
            devpath    = dev.get("path") or f"/dev/{name}"
            removable  = dev.get("hotplug") == "1" or dev.get("rm") == "1"
            size_str   = dev.get("size") or ""

            # We want partitions (and whole disks with a fs) but not
            # raw disks that have children, loops, or swap
            is_usable = (dtype in ("part", "disk") and
                         fstype not in skip_fs and
                         fstype != "swap")

            if not is_usable:
                if "children" in dev:
                    walk(dev["children"])
                continue

            # Skip pseudo/system mounts
            if (mountpoint.startswith("[") or
                    mountpoint in skip_mounts or
                    mountpoint.startswith("/boot") or
                    mountpoint.startswith("/snap")):
                mountpoint = ""

            mounted = bool(mountpoint) and Path(mountpoint).is_dir()

            if mounted:
                try:
                    usage = shutil.disk_usage(mountpoint)
                    total, used, free = usage.total, usage.used, usage.free
                except Exception:
                    total = used = free = 0
            else:
                total = used = free = 0

            # Friendly display name
            if label:
                display = label
            elif mountpoint == "/":
                display = "System Drive"
            elif mountpoint == "/home":
                display = "Home"
            elif mountpoint:
                display = Path(mountpoint).name or name
            else:
                display = name

            # Icon
            if removable:
                icon = "drive-removable-media"
            elif mountpoint == "/":
                icon = "drive-harddisk-system"
            else:
                icon = "drive-harddisk"

            drives.append({
                "display":    display,
                "mountpoint": mountpoint,
                "devpath":    devpath,
                "total":      total,
                "used":       used,
                "free":       free,
                "icon":       icon,
                "fstype":     fstype,
                "size_str":   size_str,
                "mounted":    mounted,
                "is_place":   False,
            })

            if "children" in dev:
                walk(dev["children"])

    walk(data.get("blockdevices", []))
    drives.sort(key=lambda d: (d["display"].lower()))
    return drives


def get_places():
    """Read KDE Places from user-places.xbel, return list of dicts."""
    xbel = Path.home() / ".local/share/user-places.xbel"
    if not xbel.exists():
        return []

    places = []
    try:
        tree = ET.parse(xbel)
        root = tree.getroot()

        # Namespaces used in the file
        ns = {
            "bm":   "http://www.freedesktop.org/standards/desktop-bookmarks",
            "kdebi": "http://www.kde.org/kdeconnect",
        }

        for bm in root.iter("bookmark"):
            href = bm.get("href", "")
            if not href.startswith("file://"):
                continue  # skip trash://, remote://, etc.

            # Decode path
            path = unquote(urlparse(href).path)
            if not Path(path).is_dir():
                continue  # skip missing dirs

            # Title from <title> child
            title_el = bm.find("title")
            title = title_el.text.strip() if title_el is not None and title_el.text else Path(path).name

            # Icon from <info><metadata><bookmark:icon name="..."/>
            icon_name = "folder"
            info = bm.find("info")
            if info is not None:
                for meta in info.findall("metadata"):
                    icon_el = meta.find(
                        "{http://www.freedesktop.org/standards/desktop-bookmarks}icon"
                    )
                    if icon_el is not None:
                        icon_name = icon_el.get("name", "folder")
                        break

            # Skip if it's a mount point already shown in drives
            places.append({
                "display":    title,
                "mountpoint": path,
                "devpath":    "",
                "total":      0,
                "used":       0,
                "free":       0,
                "icon":       icon_name,
                "fstype":     "",
                "size_str":   "",
                "mounted":    True,
                "is_place":   True,
            })
    except Exception:
        pass

    places.sort(key=lambda p: p["display"].lower())
    return places


def fmt_size(b):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if b < 1024:
            return f"{b:.1f} {unit}"
        b /= 1024
    return f"{b:.1f} PB"


class DriveCard(QFrame):
    def __init__(self, drive, on_click, parent=None, card_w=None):
        super().__init__(parent)
        self.drive    = drive
        self.on_click = on_click

        cw = card_w if card_w is not None else CARD_WIDTH
        self.setFixedSize(cw, CARD_HEIGHT)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setObjectName("driveCard")

        mounted = drive["mounted"]
        self.setStyleSheet("""
            #driveCard {
                border: 1px solid palette(mid);
                border-radius: 8px;
                background: palette(base);
            }
            #driveCard:hover {
                border: 1px solid palette(highlight);
                background: palette(alternateBase);
            }
        """ + ("" if mounted else """
            #driveCard { opacity: 0.7; }
        """))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 8)
        layout.setSpacing(3)

        # Icon
        icon_label = QLabel()
        icon_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon = QIcon.fromTheme(drive["icon"], QIcon.fromTheme("drive-harddisk"))
        pix = icon.pixmap(QSize(64, 64))
        icon_label.setPixmap(pix)
        if not mounted:
            from PyQt6.QtWidgets import QGraphicsOpacityEffect
            fade = QGraphicsOpacityEffect()
            fade.setOpacity(0.35)
            icon_label.setGraphicsEffect(fade)
        layout.addWidget(icon_label)

        # Drive name
        name_label = QLabel(drive["display"])
        name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name_label.setWordWrap(True)
        f = QFont()
        f.setBold(True)
        name_label.setFont(f)
        layout.addWidget(name_label)

        # Mount point or "Not mounted"
        if mounted:
            sub_text = drive["mountpoint"]
        else:
            sub_text = f"Not mounted · {drive['size_str']}"
        sub_label = QLabel(sub_text)
        sub_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub_label.setStyleSheet("color: palette(mid); font-size: 10px;")
        sub_label.setWordWrap(True)
        layout.addWidget(sub_label)

        if mounted and drive["total"] > 0:
            pct = int(drive["used"] / drive["total"] * 100)
            size_label = QLabel(
                f"{fmt_size(drive['free'])} free of {fmt_size(drive['total'])}"
            )
            size_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            size_label.setStyleSheet("font-size: 10px;")
            size_label.setWordWrap(True)
            layout.addWidget(size_label)

            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(pct)
            bar.setTextVisible(False)
            bar.setFixedHeight(8)
            color = "#e74c3c" if pct > 85 else "#3daee9"
            bar.setStyleSheet(f"""
                QProgressBar {{
                    border: none; border-radius: 4px;
                    background: palette(mid);
                }}
                QProgressBar::chunk {{
                    border-radius: 4px; background: {color};
                }}
            """)
            layout.addWidget(bar)
        elif not mounted:
            mount_hint = QLabel("Click to mount & open")
            mount_hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
            mount_hint.setStyleSheet("color: palette(mid); font-size: 10px; font-style: italic;")
            layout.addWidget(mount_hint)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.on_click(self.drive)


SECTION_LABEL_H = 28  # height of the "Places" divider label


class FlowContainer(QWidget):
    """Reflows DriveCards with optional section dividers."""
    def __init__(self, drives, places, on_click, parent=None):
        super().__init__(parent)
        self.drives   = drives
        self.places   = places
        self.on_click = on_click
        self.cards    = []   # (widget, is_label)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self._build_cards()

    def _build_cards(self):
        for widget, _ in self.cards:
            widget.setParent(None)
        self.cards = []

        for d in self.drives:
            self.cards.append((DriveCard(d, self.on_click, self), False))

        if self.places:
            lbl = QLabel("Places", self)
            lbl.setFixedHeight(SECTION_LABEL_H)
            f = QFont(); f.setBold(True); f.setPointSize(10)
            lbl.setFont(f)
            lbl.setStyleSheet("color: palette(mid);")
            self.cards.append((lbl, True))

            for p in self.places:
                self.cards.append((DriveCard(p, self.on_click, self), False))

        self._reflow(self.width() or 600)

    def _reflow(self, w):
        MARGIN = 16  # matches the left margin on the outer layout
        aw     = w - MARGIN  # available width after right margin
        cols   = max(1, (aw + CARD_GAP) // (CARD_WIDTH + CARD_GAP))
        # Stretch cards to fill available width evenly
        card_w = (aw - CARD_GAP * (cols - 1)) // cols
        y   = 0
        col = 0
        row_h = 0

        for widget, is_label in self.cards:
            if is_label:
                if col > 0:
                    y += row_h + CARD_GAP
                widget.setFixedWidth(w)
                widget.move(0, y)
                widget.show()
                y += SECTION_LABEL_H + 4
                col = 0
                row_h = 0
            else:
                widget.setFixedWidth(card_w)
                x = col * (card_w + CARD_GAP)
                widget.move(x, y)
                widget.show()
                row_h = CARD_HEIGHT
                col += 1
                if col >= cols:
                    y += row_h + CARD_GAP
                    col = 0
                    row_h = 0

        if col > 0:
            y += row_h + CARD_GAP

        self.setFixedHeight(max(y, CARD_HEIGHT + CARD_GAP))

    def resizeEvent(self, event):
        self._reflow(event.size().width())

    def refresh(self):
        self.drives = get_drives()
        self.places = get_places()
        self._build_cards()


class MyComputerWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Computer")
        self.setWindowIcon(QIcon.fromTheme("computer"))

        # Restore saved size, or default to a size that fits the screen
        cfg = load_config()
        screen = QApplication.primaryScreen().availableGeometry()

        # Calculate a sensible default height from actual card count
        drives = get_drives()
        places = get_places()
        total_cards = len(drives) + len(places)
        default_cols = max(2, min(4, total_cards))
        drive_rows   = (len(drives) + default_cols - 1) // default_cols
        place_rows   = (len(places) + default_cols - 1) // default_cols if places else 0
        section_h    = (SECTION_LABEL_H + 4) if places else 0
        cards_h      = (drive_rows + place_rows) * (CARD_HEIGHT + CARD_GAP)
        chrome_h     = 120  # title bar, subtitle, status bar, margins
        default_h    = min(screen.height() - 80, cards_h + section_h + chrome_h)
        default_w    = min(screen.width()  - 80, max(
                           (CARD_WIDTH + CARD_GAP) * default_cols + CARD_GAP + 56,
                           480))

        # Use saved size if present, but only if it looks sane (not too short)
        min_w = (CARD_WIDTH + CARD_GAP) * 2 + CARD_GAP + 56
        min_h = CARD_HEIGHT + chrome_h
        w = max(min_w, min(cfg.get("width",  default_w), screen.width()  - 80))
        h = max(min_h, min(cfg.get("height", default_h), screen.height() - 80))

        self.resize(w, h)
        self.setMinimumWidth(min_w)
        self.setMinimumHeight(min_h)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(16, 16, 0, 0)
        outer.setSpacing(8)

        # Scroll area — vertical only
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        self.flow = FlowContainer(drives, places, self.open_drive)
        self.scroll.setWidget(self.flow)
        outer.addWidget(self.scroll)

        self.status = QLabel("")
        self.status.setStyleSheet("color: palette(mid); font-style: italic;")
        outer.addWidget(self.status)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        save_config({"width": self.width(), "height": self.height()})

    def open_drive(self, drive):
        if drive["mounted"] or drive.get("is_place"):
            subprocess.Popen(["dolphin", "--new-window", drive["mountpoint"]],
                             start_new_session=True)
            self.close()
        else:
            self.status.setText(f"Mounting {drive['devpath']}…")
            QApplication.processEvents()
            try:
                result = subprocess.run(
                    ["udisksctl", "mount", "-b", drive["devpath"]],
                    capture_output=True, text=True, timeout=15
                )
                if result.returncode == 0:
                    # Parse mountpoint from udisksctl output
                    # e.g. "Mounted /dev/sdb1 at /run/media/user/LABEL"
                    line = result.stdout.strip()
                    mountpoint = line.split(" at ")[-1].rstrip(".")
                    self.status.setText("")
                    subprocess.Popen(["dolphin", "--new-window", mountpoint],
                                     start_new_session=True)
                    self.close()
                else:
                    err = result.stderr.strip() or result.stdout.strip()
                    self.status.setText(f"Mount failed: {err}")
            except subprocess.TimeoutExpired:
                self.status.setText("Mount timed out.")
            except FileNotFoundError:
                self.status.setText("udisksctl not found — cannot auto-mount.")


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Computer")
    win = MyComputerWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

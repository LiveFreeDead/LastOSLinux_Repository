#!/usr/bin/env bash
# =============================================================================
# add_mycomputer_icon.sh
# Installs the Computer drive picker and adds a desktop icon for it.
# =============================================================================

# -----------------------------------------------------------------------------
# 0. Relaunch inside a terminal if not already in one
# -----------------------------------------------------------------------------
if [ ! -t 0 ]; then
    SCRIPT_PATH="$(realpath "$0")"
    for TERM_EMU in konsole xterm xfce4-terminal gnome-terminal mate-terminal; do
        if command -v "$TERM_EMU" &>/dev/null; then
            case "$TERM_EMU" in
                konsole)        exec konsole -e bash "$SCRIPT_PATH" ;;
                xterm)          exec xterm -e bash "$SCRIPT_PATH" ;;
                xfce4-terminal) exec xfce4-terminal -e "bash \"$SCRIPT_PATH\"" ;;
                gnome-terminal) exec gnome-terminal -- bash "$SCRIPT_PATH" ;;
                mate-terminal)  exec mate-terminal -- bash "$SCRIPT_PATH" ;;
            esac
        fi
    done
    if command -v kdialog &>/dev/null; then
        kdialog --error "No terminal emulator found. Please install Konsole and re-run."
    fi
    exit 1
fi

set -euo pipefail

BROWSE_SCRIPT="$HOME/.local/bin/computer-browse.py"
DESKTOP_DIR="$HOME/Desktop"
LAUNCHER="$DESKTOP_DIR/Computer.desktop"
PLASMA_CONFIG="$HOME/.config/plasma-org.kde.plasma.desktop-appletsrc"

# -----------------------------------------------------------------------------
# 1. Check Python3 + PyQt6 are available, install PyQt6 if missing
# -----------------------------------------------------------------------------
echo "▶  Checking Python3…"
if ! command -v python3 &>/dev/null; then
    echo "✘  python3 not found. Please install it and re-run."
    exit 1
fi
echo "✔  Python3 found: $(python3 --version)"

echo "▶  Checking PyQt6…"
if ! python3 -c "import PyQt6" &>/dev/null; then
    echo "▶  PyQt6 not found — installing via pacman…"
    sudo pacman -S --noconfirm python-pyqt6
fi
echo "✔  PyQt6 available"

# -----------------------------------------------------------------------------
# 2. Enable NTFS support (ntfs3 kernel module + ntfs-3g userspace fallback)
# -----------------------------------------------------------------------------

# Check each condition independently — only run sudo for what's actually missing
NTFS_OK=true

ntfs3g_present=false
ntfs3_mod_conf=false
ntfs3_mod_loaded=false
udev_rule_present=false

pacman -Q ntfs-3g &>/dev/null           && ntfs3g_present=true
[[ -f /etc/modules-load.d/ntfs3.conf ]] && ntfs3_mod_conf=true
lsmod | grep -q ntfs3                   && ntfs3_mod_loaded=true
[[ -f /etc/udev/rules.d/99-ntfs3.rules ]] && udev_rule_present=true

if $ntfs3g_present && $ntfs3_mod_conf && $udev_rule_present; then
    echo "✔  NTFS support already configured — skipping"
else
    echo "▶  Setting up NTFS support…"
    NTFS_OK=false

    if ! $ntfs3g_present; then
        echo "▶  Installing ntfs-3g…"
        sudo pacman -S --noconfirm ntfs-3g
    fi

    if ! $ntfs3_mod_loaded; then
        sudo modprobe ntfs3 2>/dev/null \
            && echo "✔  ntfs3 kernel module loaded" \
            || echo "⚠  ntfs3 unavailable, ntfs-3g will handle NTFS instead"
    fi

    if ! $ntfs3_mod_conf; then
        echo ntfs3 | sudo tee /etc/modules-load.d/ntfs3.conf > /dev/null
        echo "✔  ntfs3 set to load on boot"
    fi

    if ! $udev_rule_present; then
        echo 'ENV{ID_FS_TYPE}=="ntfs", ENV{ID_FS_TYPE}="ntfs3"' \
            | sudo tee /etc/udev/rules.d/99-ntfs3.rules > /dev/null
        sudo udevadm control --reload-rules
        echo "✔  udev rule added: NTFS partitions will use ntfs3 driver"
    fi

    echo "✔  NTFS support configured"
fi

# -----------------------------------------------------------------------------
# 3. Install the browse script
# -----------------------------------------------------------------------------
mkdir -p "$HOME/.local/bin"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy computer-browse.py from same directory as this script
if [[ -f "$SCRIPT_DIR/computer-browse.py" ]]; then
    cp "$SCRIPT_DIR/computer-browse.py" "$BROWSE_SCRIPT"
else
    echo "✘  computer-browse.py not found next to this script."
    echo "   Make sure both files are in the same folder."
    exit 1
fi

chmod +x "$BROWSE_SCRIPT"
echo "✔  Installed browse script to $BROWSE_SCRIPT"

# -----------------------------------------------------------------------------
# 4. Create the .desktop launcher
# -----------------------------------------------------------------------------
mkdir -p "$DESKTOP_DIR"

cat > "$LAUNCHER" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Computer
Comment=Browse drives and storage devices
Exec=python3 $BROWSE_SCRIPT
Icon=computer
Terminal=false
Categories=System;FileManager;
EOF

chmod +x "$LAUNCHER"

# Trust the .desktop file
if command -v gio &>/dev/null; then
    gio set "$LAUNCHER" metadata::trusted true 2>/dev/null || true
fi
echo "✔  Created desktop icon: $LAUNCHER"

# -----------------------------------------------------------------------------
# 5. Set top-left grid position
# -----------------------------------------------------------------------------
KWRITECONFIG=""
command -v kwriteconfig5 &>/dev/null && KWRITECONFIG="kwriteconfig5"
command -v kwriteconfig6 &>/dev/null && KWRITECONFIG="kwriteconfig6"

if [[ -n "$KWRITECONFIG" ]]; then
    $KWRITECONFIG \
        --file "$PLASMA_CONFIG" \
        --group "DesktopIcons" \
        --key "${LAUNCHER}" \
        "1,1"
    echo "✔  Requested top-left grid position"
fi

echo ""
echo "All done! 🖥️"
echo "A 'Computer' icon has been added to your desktop."

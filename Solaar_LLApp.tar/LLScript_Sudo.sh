#!/bin/bash

sudo apt install --yes solaar
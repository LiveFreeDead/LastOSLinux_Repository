#!/bin/bash

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done


#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  arch|endeavouros)
    ;;

  biglinux)
    ;;

  solus)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon)
    ;;

  gnome|ubuntu)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#FlatPak Install Package for User
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "


#----- Add Your Code Here ------

#Install Rust from online script - Latest version:
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y

#Setup Environment Variable
. "$HOME/.cargo/env"


##Example project, remmarked out:

## Define the target directory path
#TARGET_DIR="$HOME/rust-projects/hello_rust"
## Define the target file path
#TARGET_FILE="$TARGET_DIR/main.rs"
#
## Create the directory path, including any necessary parent directories (-p flag)
#mkdir -p "$TARGET_DIR" || { echo "Failed to create directory $TARGET_DIR"; exit 1; }
#
## Output the Rust code into the file, overwriting if it already exists (>)
#cat <<EOF > "$TARGET_FILE"
#fn main() {
#    println!("Hello, world!");
#}
#EOF
#
#echo "Changing directory to: " $TARGET_DIR
#cd $TARGET_DIR
#echo "Compiling main.rs"
#rustc main.rs
#echo "Running main"
#./main





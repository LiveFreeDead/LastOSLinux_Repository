#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # AUR package name for VS Code on Arch/Manjaro
        inst visual-studio-code-bin
        ;;

    dnf)
        sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
        echo -e "[code]
    name=Visual Studio Code
    baseurl=https://packages.microsoft.com/yumrepos/vscode
    enabled=1
    gpgcheck=1
    gpgkey=https://packages.microsoft.com/keys/microsoft.asc" | sudo tee /etc/yum.repos.d/vscode.repo > /dev/null
        dnf check-update
        inst code
        ;;

    apt)
        echo "code code/add-microsoft-repo boolean true" | sudo debconf-set-selections
        wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg
        sudo install -D -o root -g root -m 644 packages.microsoft.gpg /etc/apt/keyrings/packages.microsoft.gpg
        echo "deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] https://packages.microsoft.com/repos/code stable main" |sudo tee /etc/apt/sources.list.d/vscode.list > /dev/null
        rm -f packages.microsoft.gpg
        sudo apt -qq update -y
        inst code
        ;;

    zypper)
        sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
        sudo zypper addrepo https://packages.microsoft.com/yumrepos/vscode VSCode 2>/dev/null || sudo zypper modifyrepo --enable VSCode
        sudo zypper --gpg-auto-import-keys refresh
        inst code
        ;;

    pacman)
        if command -v yay &>/dev/null; then
            yay -S --noconfirm visual-studio-code-bin
        elif command -v paru &>/dev/null; then
            paru -S --noconfirm visual-studio-code-bin
        else
            inst code
        fi
        ;;

    yum)
        sudo rpm --import https://packages.microsoft.com/keys/microsoft.asc
        echo -e "[code]
name=Visual Studio Code
baseurl=https://packages.microsoft.com/yumrepos/vscode
enabled=1
type=rpm-md
gpgcheck=1
gpgkey=https://packages.microsoft.com/keys/microsoft.asc" | sudo tee /etc/yum.repos.d/vscode.repo > /dev/null
        sudo yum makecache
        inst code
        ;;

    emerge)
        # Gentoo: VS Code available via the "waebbl" overlay
        sudo eselect repository enable waebbl 2>/dev/null || sudo layman -a waebbl 2>/dev/null
        sudo emerge --sync waebbl 2>/dev/null
        inst visual-studio-code
        ;;

    eopkg)
        # Solus: VS Code is in the official repo
        inst vscode
        ;;

    apk)
        # Alpine: VS Code not in main repos — enable community repo if not already present
        if ! grep -q "community" /etc/apk/repositories 2>/dev/null; then
            ALPINE_VER=$(cat /etc/alpine-release 2>/dev/null | cut -d. -f1,2)
            echo "https://dl-cdn.alpinelinux.org/alpine/v${ALPINE_VER}/community" | sudo tee -a /etc/apk/repositories
        fi
        sudo apk update
        inst code-oss
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2


echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------


exit 0
#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

sudo -v
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac) ;; dnf) ;; apt) ;; pacman) ;; zypper) ;; yum) ;; emerge) ;; eopkg) ;; apk) ;; *) ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro) ;; linuxmint|ubuntu) ;; debian|pop) ;; fedora|nobara) ;;
    opensuse-tumbleweed|opensuse-leap) ;; almalinux) ;; arch|endeavouros) ;;
    argent) ;; biglinux) ;; cachyos) ;; deepin) ;; garuda) ;; regataos) ;;
    solus) ;; zorin) ;; bazzite|silverblue|kinoite|sericea|aurora|bluefin) ;;
    *) echo "Unknown Distribution ($ID). Script section skipped" ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    gnome|ubuntu|ubuntu-xorg) ;; kde|KDE|plasma) ;; lxde) ;;
    *[Cc]innamon*) ;; mate|lightdm-xsession) ;; unity) ;; xfce) ;;
    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop) ;; budgie-desktop) ;; LXQt) ;;
    anduinos|anduinos-xorg) ;; deepin) ;; default) ;; zorin) ;;
    *) echo "Unknown Desktop Environment ($DE). Script section skipped" ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# ── Create /opt/Sanitize and install binary ───────────────────────────────────
# Must happen before ./install.sh runs, since install.sh creates the symlink
# ~/.local/bin/sanitize → /opt/Sanitize/sanitize and that target must exist.
# Directory: root:lastos-users 775 so lastos-users group members can write.
# Binary:    root:lastos-users 755 so all users can execute it.
SCRIPT_DIR=$PWD
sudo mkdir -p /opt/Sanitize
sudo cp -f "./sanitize" /opt/Sanitize/sanitize
sudo cp -f "./Removes.ini" /opt/Sanitize/Removes.ini
sudo cp -f "./LLApp.png" /opt/Sanitize/sanitize.png
sudo chown -R root:lastos-users /opt/Sanitize
sudo chmod -R 775 /opt/Sanitize
echo "Installed binary → /opt/Sanitize/sanitize"

./install.sh

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# ─────────────────────────────────────────────────────────────────────────────
# Populate /etc/skel and /root so every new user created after this point
# automatically receives all context menu integrations on first login.
# The sanitize binary lives at /opt/Sanitize/sanitize (system-wide).
# ~/.local/bin/sanitize is a symlink to that path — works for all users
# because the target is an absolute system path, not a home-relative one.
#
# What gets written to /etc/skel (and mirrored to /root):
#   ~/.local/bin/sanitize  → symlink → /opt/Sanitize/sanitize
#   ~/.config/sanitizer/Removes.ini                        ← config
#   ~/.local/share/icons/hicolor/256x256/apps/sanitize.png ← icon
#   ~/.local/share/applications/sanitize.desktop           ← hidden .desktop
#   ~/.local/share/nemo/actions/sanitize.nemo_action       ← Nemo (Cinnamon)
#   ~/.local/share/kio/servicemenus/sanitize.desktop       ← Dolphin KDE6
#   ~/.local/share/kservices5/ServiceMenus/sanitize.desktop← Dolphin KDE5
#   ~/.local/share/nautilus/scripts/Sanitize (Clean)       ← Nautilus (GNOME)
#   ~/.config/caja/scripts/Sanitize (Clean)                ← Caja (MATE)
#   ~/.local/share/contractor/sanitize.contract            ← Pantheon Files
#   ~/.config/Thunar/uca.xml                               ← Thunar (XFCE)
# ─────────────────────────────────────────────────────────────────────────────

SKEL="/etc/skel"
ICON_SRC="./LLApp.png"
INI_SRC="./Removes.ini"
ICON_NAME="sanitize"
BIN_DEST="${SKEL}/.local/bin"
ICON_DEST="${SKEL}/.local/share/icons/hicolor/256x256/apps"
APPS_DEST="${SKEL}/.local/share/applications"
NEMO_DEST="${SKEL}/.local/share/nemo/actions"
KDE6_DEST="${SKEL}/.local/share/kio/servicemenus"
KDE5_DEST="${SKEL}/.local/share/kservices5/ServiceMenus"
NAUT_DEST="${SKEL}/.local/share/nautilus/scripts"
CAJA_DEST="${SKEL}/.config/caja/scripts"
PANTH_DEST="${SKEL}/.local/share/contractor"
THUNAR_DEST="${SKEL}/.config/Thunar"
CFG_DEST="${SKEL}/.config/sanitizer"

for d in "$BIN_DEST" "$ICON_DEST" "$APPS_DEST" \
          "$NEMO_DEST" "$KDE6_DEST" "$KDE5_DEST" \
          "$NAUT_DEST" "$CAJA_DEST" "$PANTH_DEST" \
          "$THUNAR_DEST" "$CFG_DEST"; do
    sudo mkdir -p "$d"
done

# ── Symlink ───────────────────────────────────────────────────────────────────
sudo ln -sf /opt/Sanitize/sanitize "${BIN_DEST}/sanitize"
echo "skel: symlink   → ${BIN_DEST}/sanitize → /opt/Sanitize/sanitize"

# ── Config ────────────────────────────────────────────────────────────────────
sudo cp "$INI_SRC" "${CFG_DEST}/Removes.ini"
echo "skel: config    → ${CFG_DEST}/Removes.ini"

# ── Icon ──────────────────────────────────────────────────────────────────────
if [[ -f "$ICON_SRC" ]]; then
    sudo cp "$ICON_SRC" "${ICON_DEST}/${ICON_NAME}.png"
    echo "skel: icon      → ${ICON_DEST}/${ICON_NAME}.png"
fi

# ── Desktop entry (NoDisplay=true — hidden from all launchers) ────────────────
sudo bash -c "cat > '${APPS_DEST}/sanitize.desktop'" << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=Sanitize
GenericName=Filename Cleaner
Comment=Clean up media filenames - remove codec tags, fix separators, capitalise
Exec=/opt/Sanitize/sanitize %F
Icon=sanitize
Terminal=false
NoDisplay=true
Categories=Utility;FileTools;
MimeType=all/all;inode/directory;
StartupNotify=false
EOF
echo "skel: .desktop  → ${APPS_DEST}/sanitize.desktop (NoDisplay=true)"

# ── Nemo action ───────────────────────────────────────────────────────────────
sudo bash -c "cat > '${NEMO_DEST}/sanitize.nemo_action'" << 'EOF'
[Nemo Action]
Active=true
Name=Sanitize (Clean)
Comment=Clean up media filenames - remove codec tags, fix separators, capitalise
Exec=/opt/Sanitize/sanitize %F
Icon-Name=sanitize
Selection=any
Extensions=any;
Quote=double
EOF
echo "skel: nemo      → ${NEMO_DEST}/sanitize.nemo_action"

# ── Dolphin KDE6 service menu ─────────────────────────────────────────────────
sudo bash -c "cat > '${KDE6_DEST}/sanitize.desktop'" << 'EOF'
[Desktop Entry]
Type=Service
ServiceTypes=KonqPopupMenu/Plugin
MimeType=all/all;inode/directory;
Actions=SanitizeClean;
Icon=sanitize

[Desktop Action SanitizeClean]
Name=Sanitize (Clean)
Icon=sanitize
Exec=/opt/Sanitize/sanitize %F
EOF
echo "skel: dolphin6  → ${KDE6_DEST}/sanitize.desktop"

# ── Dolphin KDE5 service menu ─────────────────────────────────────────────────
sudo cp "${KDE6_DEST}/sanitize.desktop" "${KDE5_DEST}/sanitize.desktop"
echo "skel: dolphin5  → ${KDE5_DEST}/sanitize.desktop"

# ── Nautilus script ───────────────────────────────────────────────────────────
sudo bash -c "cat > '${NAUT_DEST}/Sanitize (Clean)'" << 'EOF'
#!/usr/bin/env bash
IFS=$'\n'
for f in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS; do
    [[ -n "$f" ]] && /opt/Sanitize/sanitize "$f"
done
EOF
sudo chmod +x "${NAUT_DEST}/Sanitize (Clean)"
echo "skel: nautilus  → ${NAUT_DEST}/Sanitize (Clean)"

# ── Caja script ───────────────────────────────────────────────────────────────
sudo bash -c "cat > '${CAJA_DEST}/Sanitize (Clean)'" << 'EOF'
#!/usr/bin/env bash
IFS=$'\n'
for f in $CAJA_SCRIPT_SELECTED_FILE_PATHS; do
    [[ -n "$f" ]] && /opt/Sanitize/sanitize "$f"
done
EOF
sudo chmod +x "${CAJA_DEST}/Sanitize (Clean)"
echo "skel: caja      → ${CAJA_DEST}/Sanitize (Clean)"

# ── Pantheon contract ─────────────────────────────────────────────────────────
sudo bash -c "cat > '${PANTH_DEST}/sanitize.contract'" << 'EOF'
[Contractor Entry]
Name=Sanitize (Clean)
Description=Clean up media filenames - remove codec tags, fix separators, capitalise
Icon=sanitize
MimeType=all
Exec=/opt/Sanitize/sanitize %U
EOF
echo "skel: pantheon  → ${PANTH_DEST}/sanitize.contract"

# ── Thunar UCA ────────────────────────────────────────────────────────────────
THUNAR_UCA="${THUNAR_DEST}/uca.xml"
if ! sudo test -f "$THUNAR_UCA"; then
    sudo bash -c "cat > '$THUNAR_UCA'" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<actions>
<action>
  <icon>sanitize</icon>
  <n>Sanitize (Clean)</n>
  <unique-id>sanitize-clean-001</unique-id>
  <command>/opt/Sanitize/sanitize %F</command>
  <description>Clean up media filenames</description>
  <range>*</range>
  <patterns>*</patterns>
  <startup-notify/>
  <directories/>
  <audio-files/>
  <image-files/>
  <other-files/>
  <text-files/>
  <video-files/>
</action>
</actions>
EOF
    echo "skel: thunar    → ${THUNAR_UCA} (created)"
else
    if ! sudo grep -qF "sanitize-clean-001" "$THUNAR_UCA" 2>/dev/null; then
        INJECT='<action>\n  <icon>sanitize</icon>\n  <n>Sanitize (Clean)</n>\n  <unique-id>sanitize-clean-001</unique-id>\n  <command>\/opt\/Sanitize\/sanitize %F</command>\n  <description>Clean up media filenames</description>\n  <range>*</range>\n  <patterns>*</patterns>\n  <startup-notify\/>\n  <directories\/>\n  <audio-files\/>\n  <image-files\/>\n  <other-files\/>\n  <text-files\/>\n  <video-files\/>\n<\/action>'
        sudo awk -v blk="$INJECT" '/<\/actions>/ { printf "%s\n", blk } { print }' \
            "$THUNAR_UCA" > "${THUNAR_UCA}.new" && sudo mv "${THUNAR_UCA}.new" "$THUNAR_UCA"
        echo "skel: thunar    → ${THUNAR_UCA} (merged)"
    else
        echo "skel: thunar    → ${THUNAR_UCA} (already present)"
    fi
fi

# ── Mirror everything to /root ─────────────────────────────────────────────────
echo ""
echo "Applying same context menu entries to /root..."
for d in "/root/.local/bin" \
          "/root/.local/share/icons/hicolor/256x256/apps" \
          "/root/.local/share/applications" \
          "/root/.local/share/nemo/actions" \
          "/root/.local/share/kio/servicemenus" \
          "/root/.local/share/kservices5/ServiceMenus" \
          "/root/.local/share/nautilus/scripts" \
          "/root/.config/caja/scripts" \
          "/root/.local/share/contractor" \
          "/root/.config/Thunar" \
          "/root/.config/sanitizer"; do
    sudo mkdir -p "$d"
done

sudo ln -sf /opt/Sanitize/sanitize "/root/.local/bin/sanitize"
sudo cp "${CFG_DEST}/Removes.ini"                          "/root/.config/sanitizer/Removes.ini"
[[ -f "$ICON_SRC" ]] && sudo cp "$ICON_SRC" "/root/.local/share/icons/hicolor/256x256/apps/${ICON_NAME}.png"
sudo cp "${APPS_DEST}/sanitize.desktop"                    "/root/.local/share/applications/sanitize.desktop"
sudo cp "${NEMO_DEST}/sanitize.nemo_action"                "/root/.local/share/nemo/actions/sanitize.nemo_action"
sudo cp "${KDE6_DEST}/sanitize.desktop"                    "/root/.local/share/kio/servicemenus/sanitize.desktop"
sudo cp "${KDE5_DEST}/sanitize.desktop"                    "/root/.local/share/kservices5/ServiceMenus/sanitize.desktop"
sudo cp "${NAUT_DEST}/Sanitize (Clean)"                    "/root/.local/share/nautilus/scripts/Sanitize (Clean)"
sudo chmod +x "/root/.local/share/nautilus/scripts/Sanitize (Clean)"
sudo cp "${CAJA_DEST}/Sanitize (Clean)"                    "/root/.config/caja/scripts/Sanitize (Clean)"
sudo chmod +x "/root/.config/caja/scripts/Sanitize (Clean)"
sudo cp "${PANTH_DEST}/sanitize.contract"                  "/root/.local/share/contractor/sanitize.contract"
sudo cp "${THUNAR_UCA}"                                    "/root/.config/Thunar/uca.xml"
echo "Applied to /root"

exit 0
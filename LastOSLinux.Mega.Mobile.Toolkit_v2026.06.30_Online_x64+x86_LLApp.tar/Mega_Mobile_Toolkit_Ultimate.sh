#!/usr/bin/env bash

################################################################################
# MEGA MOBILE TOOLKIT - ULTIMATE EDITION
# Combined best features from both versions with improvements
################################################################################

# 1. CAPTURE PATHS & UNIQUE PID
SCRIPT_PATH="$(readlink -f "$0")"
MY_PID="$$"

###############################
# REAL USER DETECTION (root-safe HOME)
###############################
# If this script ends up running as root (e.g. launched through a root-owned
# installer/listener), $HOME would be /root and every path below would be
# wrong. Detect the actual logged-in desktop user in that case and use
# their home instead. When NOT running as root, this is a no-op — $HOME,
# $USER, $LOGNAME are left exactly as they already are.
RUNNING_AS_ROOT=false
REAL_USER=""
REAL_HOME=""
if [[ $EUID -eq 0 ]]; then
    RUNNING_AS_ROOT=true

    REAL_USER="${SUDO_USER:-}"
    [ -z "$REAL_USER" ] && command -v logname &>/dev/null && REAL_USER="$(logname 2>/dev/null)"
    [ -z "$REAL_USER" ] && REAL_USER="$(who am i 2>/dev/null | awk '{print $1}')"
    [ -z "$REAL_USER" ] && command -v loginctl &>/dev/null && \
        REAL_USER="$(loginctl list-sessions --no-legend 2>/dev/null | awk '$3!="root"{print $3; exit}')"

    if [ -n "$REAL_USER" ] && [ "$REAL_USER" != "root" ]; then
        REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"
    fi

    if [ -n "$REAL_HOME" ] && [ -d "$REAL_HOME" ]; then
        export HOME="$REAL_HOME"
        export USER="$REAL_USER"
        export LOGNAME="$REAL_USER"
        echo "Running as root — installing for logged-in user: $REAL_USER ($HOME)"
    else
        echo "Warning: running as root and could not determine the logged-in user."
        echo "Falling back to /root — files may end up in the wrong place."
        RUNNING_AS_ROOT=false  # nothing to chown back to, so skip the fixup later
    fi
fi

BIN_NAME="Mega Mobile Toolkit"
INTERNAL_BIN="$HOME/.local/bin/$BIN_NAME"

###############################
# CONFIG / PATHS
###############################
# APK_BASE and IPA_BASE are now dynamic (last-used folder → XDG Downloads → HOME).
# See get_apk_base() and get_ipa_base() below.

ICON_DIR="$HOME/.local/share/icons"
ICON_HICOLOR_SVG="$ICON_DIR/hicolor/scalable/apps/MegaMobile.svg"
ICON_HICOLOR_PNG="$ICON_DIR/hicolor/256x256/apps/MegaMobile.png"
ICON_URL="https://cdn-icons-png.flaticon.com/512/2586/2586488.png"

# Fixed WM_CLASS used for every yad window (via --class) so that it always
# matches the StartupWMClass in the installed .desktop file. This is what
# Cinnamon's window-list/panel applet actually keys off when deciding which
# icon to show — relying on yad's default "Yad" WM_CLASS is what caused the
# blank/generic panel icon, independent of whether --window-icon worked.
WM_CLASS="MegaMobileToolkit"

# Prefer PNG (better YAD/notify-send compat at small sizes), fall back to SVG.
# Re-evaluated after the installer writes the files.
_pick_icon_path() {
    if   [[ -f "$ICON_HICOLOR_PNG" ]]; then echo "$ICON_HICOLOR_PNG"
    elif [[ -f "$ICON_HICOLOR_SVG" ]]; then echo "$ICON_HICOLOR_SVG"
    else echo ""
    fi
}
ICON_PATH=$(_pick_icon_path)

# Database for device management
DB_FILE="$HOME/.cache/mobile_toolkit_devices.db"
LAST_USED_FILE="$HOME/.cache/mobile_toolkit_last_used"
INSTALL_FLAG="$HOME/.cache/mobile_toolkit_installed"
LAST_APK_DIR_FILE="$HOME/.cache/mobile_toolkit_last_apk_dir"
LAST_IPA_DIR_FILE="$HOME/.cache/mobile_toolkit_last_ipa_dir"

# Log files
FAILED_APK="$HOME/Desktop/Failed_APK_${MY_PID}.txt"
FAILED_IPA="$HOME/Desktop/Failed_IPA_${MY_PID}.txt"

# SSH Configuration
SSH_KEY="$HOME/.ssh/ipa_installer_key"
##SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedKeyTypes=+ssh-rsa -o ConnectTimeout=10"

# Added IdentitiesOnly=yes to prevent "Too many authentication failures"
# Added KexAlgorithms for better compatibility with iOS 8/9 legacy dropbear/openssh
SSH_OPTS="-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o HostKeyAlgorithms=+ssh-rsa -o PubkeyAcceptedKeyTypes=+ssh-rsa -o IdentitiesOnly=yes -o KexAlgorithms=+diffie-hellman-group1-sha1 -o ConnectTimeout=10"

###############################
# FORCE_REINSTALL FLAG
###############################
# Set to true before running to force reinstallation of already-installed packages.
FORCE_REINSTALL=${FORCE_REINSTALL:-false}

###############################
# SYSTEM DETECTION
###############################

# Detect Terminal Emulator
TERMS=(ptyxis gnome-terminal konsole xfce4-terminal mate-terminal lxterminal qterminal tilix terminator alacritty kitty foot x-terminal-emulator xterm)
OSTERM=""
for _t in "${TERMS[@]}"; do
    if command -v "$_t" &>/dev/null; then
        OSTERM="$_t"
        break
    fi
done
unset _t

# Detect Package Manager
PM=""
PM_CMD=""
if   PM_CMD=$(command -v pamac     2>/dev/null); then PM="pamac"
elif PM_CMD=$(command -v rpm-ostree 2>/dev/null); then PM="rpm-ostree"
elif PM_CMD=$(command -v dnf       2>/dev/null); then PM="dnf"
elif PM_CMD=$(command -v apt       2>/dev/null); then PM="apt"
elif PM_CMD=$(command -v pacman    2>/dev/null); then PM="pacman"
elif PM_CMD=$(command -v zypper    2>/dev/null); then PM="zypper"
elif PM_CMD=$(command -v yum       2>/dev/null); then PM="yum"
elif PM_CMD=$(command -v emerge    2>/dev/null); then PM="emerge"
elif PM_CMD=$(command -v eopkg     2>/dev/null); then PM="eopkg"
elif PM_CMD=$(command -v apk       2>/dev/null); then PM="apk"
fi

# Detect Immutable / Atomic OS (read-only root — package layering only)
IMMUTABLE_OS=false
_OSID=""
[ -f /etc/os-release ] && _OSID=$(. /etc/os-release 2>/dev/null && echo "${ID:-}" | tr '[:upper:]' '[:lower:]')
case "$_OSID" in
    bazzite|silverblue|kinoite|sericea|onyx|aurora|bluefin|nixos|endless|vanillaos)
        IMMUTABLE_OS=true ;;
    *)
        command -v rpm-ostree &>/dev/null && IMMUTABLE_OS=true ;;
esac
unset _OSID

# Load OS identity for package name mapping
. /etc/os-release

###############################
# PACKAGE INSTALLER (inst)
###############################

# Install native packages using whatever package manager is detected.
# Usage: inst package1 package2 ...
# Cache is checked first (fast local lookup) to skip unavailable packages.
# Each valid package is installed individually so one failure never blocks the rest.
inst () {
    if [[ -z "$PM_CMD" ]]; then
        echo "Error: No supported package manager found. Cannot install: $*"
        return 1
    fi

    for PKG in "$@"; do
        local AVAILABLE=false
        case "$PM" in
            apt)
                apt-cache show "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            dnf|yum)
                dnf repoquery --quiet "$PKG" 2>/dev/null | grep -q . && AVAILABLE=true
                ;;
            pacman|pamac)
                pacman -Si "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            zypper)
                zypper info "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            emerge)
                emerge --search "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            eopkg)
                eopkg info "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            apk)
                apk info "$PKG" &>/dev/null && AVAILABLE=true
                ;;
            rpm-ostree)
                # rpm-ostree search (added in v2023.6) can check availability
                # without a slow failed-install attempt. Parse version once per
                # package: "Version: '2023.8'" → year=2023 rel=8.
                # Older builds fall back to assuming available (previous behaviour).
                local _ro_ver _ro_year _ro_rel
                _ro_ver=$(rpm-ostree --version 2>/dev/null \
                    | awk '/Version:/ { gsub(/[^0-9.]/,"",$2); print $2 }')
                _ro_year=${_ro_ver%%.*}
                _ro_rel=${_ro_ver##*.}
                if [[ "${_ro_year:-0}" -gt 2023 ]] || \
                   { [[ "${_ro_year:-0}" -eq 2023 ]] && [[ "${_ro_rel:-0}" -ge 6 ]]; }; then
                    # Output format: "pkgname : short description"
                    # Grep for exact name match at start of line.
                    rpm-ostree search "$PKG" 2>/dev/null \
                        | grep -qE "^${PKG} :" && AVAILABLE=true
                else
                    AVAILABLE=true  # Older rpm-ostree: let install fail naturally
                fi
                ;;
            *)
                AVAILABLE=true
                ;;
        esac

        $AVAILABLE || continue

        local INSTALLED=false
        case "$PM" in
            apt)
                dpkg-query -W -f='${Status}' "$PKG" 2>/dev/null | grep -q "install ok installed" && INSTALLED=true
                ;;
            dnf|yum)
                rpm -q "$PKG" &>/dev/null && INSTALLED=true
                ;;
            pacman|pamac)
                pacman -Q "$PKG" &>/dev/null && INSTALLED=true
                ;;
            zypper)
                rpm -q "$PKG" &>/dev/null && INSTALLED=true
                ;;
            eopkg)
                eopkg info --installed "$PKG" &>/dev/null && INSTALLED=true
                ;;
            apk)
                apk info -e "$PKG" &>/dev/null && INSTALLED=true
                ;;
            emerge)
                equery list "$PKG" &>/dev/null && INSTALLED=true
                ;;
            rpm-ostree)
                rpm-ostree status --json 2>/dev/null | grep -q "\"$PKG\"" && INSTALLED=true
                ;;
        esac

        if $INSTALLED; then
            $FORCE_REINSTALL || { echo "Already installed: $PKG"; continue; }
            echo "Reinstalling: $PKG"
        else
            echo "Installing: $PKG"
        fi

        local OK=false
        case "$PM" in
            pamac)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" reinstall --no-confirm "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" install --no-confirm "$PKG" &>/dev/null && OK=true
                fi
                ;;
            dnf|yum)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
                ;;
            apt)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y install --reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
                sudo apt-mark manual "$PKG" &>/dev/null
                ;;
            pacman)
                if $FORCE_REINSTALL && $INSTALLED; then
                    yes | sudo "$PM_CMD" -S --noconfirm "$PKG" &>/dev/null && OK=true
                else
                    yes | sudo "$PM_CMD" -S --needed --noconfirm "$PKG" &>/dev/null && OK=true
                fi
                ;;
            zypper)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" --non-interactive install --force "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" --non-interactive install "$PKG" &>/dev/null && OK=true
                fi
                ;;
            emerge)
                sudo "$PM_CMD" "$PKG" &>/dev/null && OK=true
                ;;
            eopkg)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" -y reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" -y install "$PKG" &>/dev/null && OK=true
                fi
                ;;
            apk)
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" fix --reinstall "$PKG" &>/dev/null && OK=true
                else
                    sudo "$PM_CMD" add "$PKG" &>/dev/null && OK=true
                fi
                ;;
            rpm-ostree)
                # rpm-ostree layers packages; reinstall = uninstall then install
                if $FORCE_REINSTALL && $INSTALLED; then
                    sudo "$PM_CMD" uninstall -y "$PKG" &>/dev/null || true
                fi
                sudo "$PM_CMD" install -y "$PKG" &>/dev/null && OK=true
                ;;
            *)
                sudo "$PM_CMD" install "$PKG" &>/dev/null && OK=true
                ;;
        esac
        $OK && echo "OK: $PKG" || echo "Failed: $PKG"
    done
}

###############################
# PACKAGE CACHE REFRESH
###############################
# Refresh only when cache is older than 24 hours.
# Immutable/Atomic systems (rpm-ostree) do not have a traditional cache to refresh.
refresh_package_cache () {
    if $IMMUTABLE_OS; then
        echo "Skipping package cache update (immutable OS — packages layered via rpm-ostree)."
        return
    fi
    case "$PM" in
        pamac|pacman)
            if ! find /var/lib/pacman/sync -name "*.db" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo pacman -Sy --noconfirm &>/dev/null
            fi
            ;;
        dnf)
            if ! find /var/cache/dnf -name "*.solv" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo dnf makecache --quiet &>/dev/null
            fi
            ;;
        apt)
            if ! find /var/lib/apt/lists -name "*_Packages" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo apt-get update -qq &>/dev/null
            fi
            ;;
        zypper)
            if ! find /var/cache/zypp/solv -name "*.solv" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo zypper --quiet refresh &>/dev/null
            fi
            ;;
        yum)
            if ! find /var/cache/yum -name "repomd.xml" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo yum makecache --quiet &>/dev/null
            fi
            ;;
        emerge)
            if ! find /var/cache/eix -name "portage.eix" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo emerge --sync &>/dev/null
            fi
            ;;
        eopkg)
            if ! find /var/lib/eopkg/index -name "*.xml.bz2" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo eopkg update-repo &>/dev/null
            fi
            ;;
        apk)
            if ! find /var/cache/apk -name "APKINDEX*" -mmin -1440 -print -quit 2>/dev/null | grep -q .; then
                echo "Updating package cache..."
                sudo apk update &>/dev/null
            fi
            ;;
    esac
}

###############################
# DYNAMIC BASE PATHS
###############################
# Returns the last-used APK folder, XDG Downloads, or HOME (in order of preference).
get_apk_base () {
    if [[ -f "$LAST_APK_DIR_FILE" ]] && [[ -d "$(cat "$LAST_APK_DIR_FILE")" ]]; then
        cat "$LAST_APK_DIR_FILE"
    elif [[ -d "${XDG_DOWNLOAD_DIR:-$HOME/Downloads}" ]]; then
        echo "${XDG_DOWNLOAD_DIR:-$HOME/Downloads}"
    else
        echo "$HOME"
    fi
}

# Returns the last-used IPA folder, XDG Downloads, or HOME (in order of preference).
get_ipa_base () {
    if [[ -f "$LAST_IPA_DIR_FILE" ]] && [[ -d "$(cat "$LAST_IPA_DIR_FILE")" ]]; then
        cat "$LAST_IPA_DIR_FILE"
    elif [[ -d "${XDG_DOWNLOAD_DIR:-$HOME/Downloads}" ]]; then
        echo "${XDG_DOWNLOAD_DIR:-$HOME/Downloads}"
    else
        echo "$HOME"
    fi
}

# Persist the directory of the last picked file for future sessions.
save_last_apk_dir () { dirname "$1" > "$LAST_APK_DIR_FILE"; }
save_last_ipa_dir () { dirname "$1" > "$LAST_IPA_DIR_FILE"; }

###############################
# AAPT WRAPPER (aapt2 fallback)
###############################
# Transparent wrapper: uses aapt if available, falls back to aapt2.
# Both tools share the same "dump badging" interface for our purposes.
run_aapt () {
    if command -v aapt >/dev/null 2>&1; then
        aapt "$@"
    elif command -v aapt2 >/dev/null 2>&1; then
        aapt2 "$@"
    else
        echo "Error: neither aapt nor aapt2 found" >&2
        return 1
    fi
}

###############################
# IPA BUNDLE ID EXTRACTION
###############################
# Extract CFBundleIdentifier from an IPA file.
# Tries XML plist grep first, then python3 plistlib as a fallback for binary plists.
get_bundle_id_from_ipa () {
    local ipa="$1"
    local bid=""

    # XML plist: two-level path Payload/*.app/Info.plist
    bid=$(unzip -p "$ipa" '*/Info.plist' 2>/dev/null \
        | grep -A1 'CFBundleIdentifier' \
        | grep -oP '(?<=<string>)[^<]+' \
        | head -1)

    # Binary plist fallback via python3 plistlib (available on all target distros)
    if [[ -z "$bid" ]] && command -v python3 >/dev/null 2>&1; then
        bid=$(python3 - "$ipa" 2>/dev/null <<'PYEOF'
import sys, zipfile, plistlib
try:
    with zipfile.ZipFile(sys.argv[1]) as z:
        for n in z.namelist():
            if n.endswith('/Info.plist') and n.count('/') == 2:
                print(plistlib.loads(z.read(n)).get('CFBundleIdentifier', ''))
                break
except Exception:
    pass
PYEOF
)
    fi
    echo "$bid"
}

###############################
# OPEN FILE (portable)
###############################
# Open a file with the best available handler.
# Order: xdg-open → gio open → kioclient → gnome-open
open_file () {
    local f="$1"
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$f" &
    elif command -v gio >/dev/null 2>&1; then
        gio open "$f" &
    elif command -v kioclient >/dev/null 2>&1; then
        kioclient exec "$f" &
    elif command -v gnome-open >/dev/null 2>&1; then
        gnome-open "$f" &
    fi
}

###############################
# UNIVERSAL DIALOG SYSTEM
###############################

# Detect available dialog backend
detect_dialog_backend() {
    if command -v yad >/dev/null 2>&1; then
        echo "yad"
    elif command -v zenity >/dev/null 2>&1; then
        echo "zenity"
    else
        echo "terminal"
    fi
}

DIALOG_BACKEND=$(detect_dialog_backend)

# Universal Info Dialog
show_info() {
    local title="$1"
    local message="$2"
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --info \
                --title="$title" \
                --text="$message" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=450 \
                --height=150 \
                --center \
                --borders=15 \
                --button="OK:0"
            ;;
        zenity)
            zenity --info \
                --title="$title" \
                --text="$message" \
                --width=450 \
                --height=150
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$message" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "Press Enter to continue..."
            ;;
    esac
}

# Universal Error Dialog
show_error() {
    local title="$1"
    local message="$2"
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --error \
                --title="$title" \
                --text="$message" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=450 \
                --height=150 \
                --center \
                --borders=15 \
                --button="OK:0"
            ;;
        zenity)
            zenity --error \
                --title="$title" \
                --text="$message" \
                --width=450 \
                --height=150
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  ❌ ERROR: $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$message" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "Press Enter to continue..."
            ;;
    esac
}

# Universal Warning Dialog
show_warning() {
    local title="$1"
    local message="$2"
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --warning \
                --title="$title" \
                --text="$message" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --image="dialog-warning" \
                --width=450 \
                --height=150 \
                --center \
                --borders=15 \
                --button="OK:0"
            ;;
        zenity)
            zenity --warning \
                --title="$title" \
                --text="$message" \
                --width=450 \
                --height=150
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  ⚠️  WARNING: $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$message" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "Press Enter to continue..."
            ;;
    esac
}

# Universal Question Dialog (returns 0 for Yes, 1 for No)
ask_question() {
    local title="$1"
    local message="$2"
    local yes_label="${3:-Yes}"
    local no_label="${4:-No}"
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --question \
                --title="$title" \
                --text="$message" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=450 \
                --height=150 \
                --center \
                --borders=15 \
                --button="$no_label:1" \
                --button="$yes_label:0"
            ;;
        zenity)
            zenity --question \
                --title="$title" \
                --text="$(echo -e "$message" | sed 's/<[^>]*>//g')" \
                --width=450 \
                --height=150
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  ❓ $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$message" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "$yes_label/$no_label? (y/n): " -n 1 -r
            echo
            [[ $REPLY =~ ^[Yy]$ ]]
            ;;
    esac
}

# Universal Form Dialog
show_form() {
    local title="$1"
    local text="$2"
    shift 2
    local fields=("$@")
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --form \
                --title="$title" \
                --text="$text" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=500 \
                --height=250 \
                --center \
                --borders=15 \
                --separator="|" \
                "${fields[@]}" \
                --button="Cancel:1" \
                --button="OK:0"
            ;;
        zenity)
            zenity --forms \
                --title="$title" \
                --text="$text" \
                --separator="|" \
                "${fields[@]}" \
                --width=500 \
                --height=250
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$text" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            local result=""
            for field in "${fields[@]}"; do
                local label=$(echo "$field" | sed 's/--add-entry=//' | sed 's/--field=//' | tr -d '"' | cut -d':' -f1)
                read -p "$label: " value
                result+="$value|"
            done
            echo "${result%|}"
            ;;
    esac
}

# Universal File Picker
show_file_picker() {
    local title="$1"
    local filter="$2"
    local start_path="$3"
    local multiple="${4:-false}"
    
    case "$DIALOG_BACKEND" in
        yad)
            local multi_flag=""
            [ "$multiple" = "true" ] && multi_flag="--multiple"
            yad --file \
                --title="$title" \
                --file-filter="$filter" \
                --filename="$start_path" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=800 \
                --height=600 \
                --center \
                --separator="|" \
                $multi_flag
            ;;
        zenity)
            local multi_flag=""
            [ "$multiple" = "true" ] && multi_flag="--multiple --separator=|"
            zenity --file-selection \
                --title="$title" \
                --file-filter="$filter" \
                --filename="$start_path" \
                $multi_flag
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "Enter file path(s) separated by | : " files
            echo "$files"
            ;;
    esac
}

# Universal List Selection
show_list() {
    local title="$1"
    shift
    local columns=("$@")
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --list \
                --title="$title" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=700 \
                --height=450 \
                --center \
                --borders=10 \
                "${columns[@]}"
            ;;
        zenity)
            zenity --list \
                --title="$title" \
                --width=700 \
                --height=450 \
                "${columns[@]}"
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  $title"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            local i=1
            while [ $# -gt 0 ]; do
                if [[ "$1" == "--column="* ]]; then
                    shift
                    continue
                fi
                echo "$i) $1"
                i=$((i+1))
                shift
            done
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            read -p "Select number: " selection
            ;;
    esac
}

###############################
# 1. HELPER FUNCTIONS
###############################
get_default_prefix() {
    local local_ip
    local_ip=$(hostname -I | awk '{print $1}')
    if [[ $local_ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        echo "${local_ip%.*}."
    else
        echo "192.168.1."
    fi
}

###############################
# 2. DEPENDENCY CHECKER
###############################
check_dependencies() {
    local MISSING=()
    local OPTIONAL_MISSING=()
    
    # Critical dependencies
    command -v adb >/dev/null || MISSING+=("adb (android-tools)")
    # aapt or aapt2 is acceptable
    if ! command -v aapt >/dev/null 2>&1 && ! command -v aapt2 >/dev/null 2>&1; then
        MISSING+=("aapt or aapt2 (android-sdk-build-tools / aapt)")
    fi
    
    # Optional but recommended
    command -v sshpass >/dev/null || OPTIONAL_MISSING+=("sshpass")
    command -v notify-send >/dev/null || OPTIONAL_MISSING+=("libnotify-bin or notify-osd")
    
    if [ ${#MISSING[@]} -gt 0 ]; then
        local msg="<b>Missing required dependencies:</b>\n\n"
        for dep in "${MISSING[@]}"; do
            msg+="  • $dep\n"
        done
        msg+="\nRun the script with <b>-install</b> to install dependencies automatically.\n"
        msg+="Alternatively install manually for your distro:\n\n"
        msg+="<b>Debian/Ubuntu:</b>  sudo apt install android-tools-adb aapt sshpass libnotify-bin\n"
        msg+="<b>Arch/Manjaro:</b>   sudo pacman -S android-tools android-sdk-build-tools sshpass libnotify\n"
        msg+="<b>Fedora:</b>         sudo dnf install android-tools aapt sshpass libnotify\n"
        msg+="<b>openSUSE:</b>       sudo zypper install android-tools aapt sshpass libnotify-tools"
        
        show_error "Missing Dependencies" "$msg"
        return 1
    fi
    
    if [ ${#OPTIONAL_MISSING[@]} -gt 0 ]; then
        local msg="<b>Optional dependencies missing (reduced functionality):</b>\n\n"
        for dep in "${OPTIONAL_MISSING[@]}"; do
            msg+="  • $dep\n"
        done
        show_warning "Optional Dependencies" "$msg"
    fi
    
    return 0
}

###############################
# 3. ICON HELPERS
###############################

# Base64-encoded 256x256 PNG, embedded directly in the script. This is the
# ONLY source of truth for the icon now — no network download, no SVG
# rasteriser (rsvg-convert/inkscape/convert), and no dependency on the
# gdk-pixbuf SVG loader being installed. All three of those were possible
# (and very plausible) points of failure for the old SVG/download pipeline,
# and are why the panel icon kept coming up blank even after --window-icon
# looked correct. A real, valid PNG written straight to disk from a literal
# byte string cannot fail in any of those ways.
_ICON_PNG_B64='iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAI9ElEQVR4nO3dPZIb1RoGYI2LiNzO7xq8AKYKVkFu7prAOauAqmEBXgO5nRNR5Rv4NsgaadQ/5+873/OEYEunJb3v+brdo3k4BfH63dPn3muAtT69f3zovYY1hlyksDOjEUthiAUJPBmNUAhdFyD40LcImj+x0MNtrcug2ZMJPqzXqgiqP4ngw361i+BVzQcXfjimdoaqtIvgQ3k1poHiE4DwQx01slW0AIQf6iqdsSIjheBDeyVOCQ5PAMIPfZTI3qECEH7o62gGdxeA8MMYjmRxVwEIP4xlbyY3F4Dww5j2ZHNTAQg/jG1rRqveCgyMbXUB2P0hhi1ZXVUAwg+xrM3s3TuJZgr/x1++672EEN789EfvJVDIvbsFv2m1kF6Efrvz10wZzO3Fdoi8+wt+WYogrpemgJv/I2r4Bb8uRRDTrRKY6p8Bhb8+r/FcrrZCtN3fh7IP00As16aA8BOA8PfjtY/vWQFE2v19APvzHsRxLdvhJwBgv7AFYOcZh/cirq8KIMr47wM3Hu9JDJcZDzsBAMf9UwB2f47y3sRwnnUTACQWqgDsMOPzHsUSqgCAsl6dTnHO/4EylsyHmQCMlnF4r+IIUwBAeQoAElMAkNg3LgCeTt//+lfvJXTx+4/f9l4CHb1+9/R5+i8FfUnW4C+W41cEeaU9Bcge/nNei7xSFoAP/HNek5zSFYAP+m1em3xSFYAP+H1eo1xSFQDwtTQFYGdbz2uVR5oCAJ5TAJCYAoDEFAAkpgAgMQUAiSkASEwBQGIKABJTAJCYAoDEFAAkpgAgMQUAiaX+UlA46uPbx9V/9s2Hp2rr2EsBwAZbAn/v745QCAoA7jgS+rWP26sMFADcUCv4Lz1X6yJQAHChZfBvPXerIvCvAHCmZ/jPtVqHCQBO4wT/XItpwARAeiOG/1zN9SkAUhs9/Ita61QApBUl/Isa61UApBQt/IvS61YApBM1/IuS61cApBI9/ItSx6EASGOW8C9KHI8CgMQUACnMtvsvjh6XOwGZXu3wr7lTr+YaPr593H23oAKAnbaEbvmzo00iTgGYWo3AvfnwtHvHPfJ3X7L3OE0AsFLJ4I4yEZgAmFbJcNX6ibySj7vneBUA3FH7yzl6fjegAoAXtApnrxJQAEyp97l1L1uPWwHADa135R5TgAKAxBQAXNHrnLz18yoAppP1/H+x5fgVAFzo/Su7Wj6/AoDEFAAkpgAgMQUAiSkASEwBQGIKABJTAJCYAoALve8kbPn8CoDp9L6Tr7ctx68A4IpeU0Dr51UAkJgCgBta78Y9pg4FwJSyXgfYetwKAF7Qalfudc1BAcAdtcPZ858dFQDT6v1LN1o/7p7j9avBYKUlrCWKpffNRgsTAFOr9Ys49wb4yN99iV8PDo1tmQhG2fEvKQCm9+bDU9UA9g73kSnHKQApzHpfwNHjUgCQmAIgjdmmgBLHowBIZZYSKHUcCoB0opdAyfUrAFKKWgKl160ASCtaCdRYrwIgtSglUGudCoDQStyEM3oJ1FyfAiCsJfylSmC0ImixJgVASJehL3U77igl0GodCoBwboW9ZAn0KoLWz60ACOVeyEt/wUarMPYqHT8NSBhrw/3x7WPRMJ0/Vu9v8ClNARDC1uCVLoHF5WNuWdcIgb+kABjekW/fqR26EUO9hWsADO3oyN37yzpGpwAYVqnwKoHbFABDKh1aJXCdAmA4Eb6DfxYKgKHUDGn0C3Y1KACGIfztKQCGIPx9KAC6E/5+FABdCX9fCoBuhL8/BUAXwj8GBUBzwj8OBUBTwj8WBUAzwj8eBUATwj8mBUB1wj8uBUBVwj82BUA1wj8+BUAVwh+DAqC8nx+qPbTwl6UAKEv4Q1EAlCP84SgAyhD+kBQAxwl/WGkK4Pcfv+29hDA2vVbCH1qaAqAC4Q8vVQGYAu5b/RoJ/xRSFcDppAReIvz5pCuA00kJXCP8OaUsgNNJCZwT/rxS/3rw5YP//a9/dV5JH672k7oAFqaBO4R/WmlPAVhJ+KemALhN+KenALhO+FNQADwn/GkoAL4m/KkoAP4l/OkoAL4Q/pQUAMKfmBuBOvjtz7+v/vcf/tPh7RD+1BRAQ7eCf/n/mxWB8KfnFKCB3/78+274j/z5XSqG//Tfz/Uem6IUQGVHglytBISf/1MAFZUIcPESEH7OKIBMhJ8LCqCSkjt3sceqFVLhD0sBZFM6rMIfmgKooMbFu6KPWSq0wh+eAsjqaHiFfwoKILO9IRb+aSiA7LaGWfinogBYH2rhn44C4It74Rb+KSkA/nUr5MI/LQVQQY2f5mv2E4KXYRf+qYUpgDc//dF7CXksod8Zfu9VHGEKIJqSO3aXLwqx86egACCxUAUQbbQssXN32f0PiPYeZReqACI6EuBo4Seeh9fvnsKd7H385bveS9hl7Q/0RA2+3T+emJ+0oJZgD/WtwKQWcgI4neJOAbOy+8cU9hqAD9w4vBdxhS0A4LjQBWDn6c97EFvoAjidfAB78trHF/Yi4DUuDLYh+PMIPwGc88Gsz2s8l6kmgHOmgbIEf07TFsBCERwj+HObvgDOKYN1hD6PVAUAfG2qi4DANgoAElMAkJgCgMQUACSmACAxBQCJKQBITAFAYgoAEnv16f3jQ+9FAO19ev/4YAKAxBQAJKYAIDEFAIm9Op2+XAzovRCgnSXzJgBITAFAYgoAEvunAFwHgBzOs24CgMS+KgBTAMztMuMmAEhMAUBizwrAaQDM6Vq2TQCQ2NUCMAXAXG5l2gQAid0sAFMAzOGlLL84ASgBiO1ehp0CQGJ3C8AUADGtye6qCUAJQCxrM7v6FEAJQAxbsuoaACS2qQBMATC2rRndPAEoARjTnmzuOgVQAjCWvZncfQ1ACcAYjmTx0EVAJQB9Hc3g4X8FUALQR4nsFQ3v63dPn0s+HvBcyU236H0ApgGoq3TGit8IpASgjhrZqhpWpwRwXM1NteqtwKYBOKZ2hpoF1DQA67XaPJvv0IoAbms9NXcd0ZUB9D1VHuIcXRGQ0QjXyLov4BqFwIxGCPyl4RZ0i1IgkhHDfs3/AN5NH/fltlCvAAAAAElFTkSuQmCC'

# Decode the embedded base64 PNG straight to disk. No network, no rasteriser,
# no SVG loader needed — just base64, which is always available (coreutils).
_write_icon_png() {
    mkdir -p "$ICON_DIR/hicolor/256x256/apps"
    printf '%s' "$_ICON_PNG_B64" | base64 -d > "$ICON_HICOLOR_PNG" 2>/dev/null
}

# Full icon installation — always overwrites, so -install is always effective.
_install_icon() {
    echo "Writing built-in icon..."
    _write_icon_png

    # Register with the icon theme (name-based resolution for desktop entries)
    if command -v gtk-update-icon-cache >/dev/null 2>&1; then
        gtk-update-icon-cache -f -q -t "$ICON_DIR/hicolor" 2>/dev/null || true
    fi
    if command -v xdg-icon-resource >/dev/null 2>&1; then
        [[ -f "$ICON_HICOLOR_PNG" ]] &&             xdg-icon-resource install --novendor --size 256 "$ICON_HICOLOR_PNG" MegaMobile 2>/dev/null || true
    fi
}

# Lightweight startup check — write the PNG only if it's missing or corrupt
# (e.g. an empty/broken file left over from an old version of this script).
# Called on every normal launch; exits fast once the icon is in place.
_ensure_icon() {
    local _sz
    _sz=$(wc -c < "$ICON_HICOLOR_PNG" 2>/dev/null || echo 0)
    if [[ ! -f "$ICON_HICOLOR_PNG" ]] || (( _sz < 1024 )); then
        _write_icon_png
    fi
}

###############################
# 3. SYSTEM INSTALLER
###############################
if [[ "$1" == "-install" ]] || [[ ! -f "$INSTALL_FLAG" ]]; then
    echo "======================================"
    echo "  Mega Mobile Toolkit - Installation"
    echo "======================================"
    echo ""

    # Refresh package cache (skips immutable OSes automatically)
    refresh_package_cache

    # Install required packages using the universal inst() function.
    # Package names are mapped per distribution family.
    echo "Installing dependencies..."
    case "$PM" in
        apt)
            # 'adb' and 'android-tools-adb' are two different package names
            # for the same tool across Debian/Ubuntu versions, but on some
            # systems 'android-tools-adb' is a transitional/virtual package
            # that apt silently substitutes for 'adb' ("Note, selecting
            # 'adb' instead of 'android-tools-adb'") without ever actually
            # registering as installed under its own name — which made the
            # script re-attempt installing it on every single run. Simplest
            # robust fix: if the adb binary already works, don't touch
            # either package name at all.
            if command -v adb >/dev/null 2>&1; then
                inst aapt android-sdk-build-tools sshpass \
                     libnotify-bin wget curl ifuse libimobiledevice-utils yad zenity
            else
                inst adb android-tools-adb \
                     aapt android-sdk-build-tools sshpass \
                     libnotify-bin wget curl ifuse libimobiledevice-utils yad zenity
            fi
            ;;
        dnf|yum)
            inst android-tools android-udev-rules aapt sshpass \
                 libnotify wget curl ifuse libimobiledevice yad zenity
            ;;
        pacman|pamac)
            inst android-tools android-udev android-sdk-build-tools sshpass \
                 libnotify wget curl ifuse libimobiledevice yad zenity
            ;;
        zypper)
            inst android-tools android-udev-rules aapt sshpass \
                 libnotify-tools wget curl ifuse libimobiledevice6 yad zenity
            ;;
        *)
            # Generic fallback — attempt common names; inst() will skip unavailable ones
            inst android-tools sshpass libnotify wget curl ifuse libimobiledevice yad zenity
            ;;
    esac

    # Add legacy SSH support for iOS 8/9 (if /etc/ssh/ssh_config is writable via sudo)
    if [ -f /etc/ssh/ssh_config ] && ! grep -q 'PubkeyAcceptedAlgorithms +ssh-rsa' /etc/ssh/ssh_config 2>/dev/null; then
        echo "Adding legacy SSH key support to /etc/ssh/ssh_config..."
        sudo sh -c 'printf "\n# Legacy support for iOS 9 (added by Mega Mobile Toolkit)\nPubkeyAcceptedAlgorithms +ssh-rsa\nHostKeyAlgorithms +ssh-rsa\n" >> /etc/ssh/ssh_config'
    fi

    # Check critical dependencies after installation attempt
    if ! check_dependencies; then
        echo ""
        echo "Please install missing dependencies and run again with: $0 -install"
        exit 1
    fi
    
    echo "Initializing System Integration..."
    
    # Create directories
    mkdir -p "$ICON_DIR" "$HOME/.local/share/applications" "$HOME/.local/bin" "$HOME/.cache"
    touch "$DB_FILE"
    
    # ── Icon installation ──────────────────────────────────────────────────────
    # Always (re)write the icon during install — never skip on -install.
    _install_icon
    ICON_PATH=$(_pick_icon_path)
    
    # Deploy Master Binary
    echo "Installing to $INTERNAL_BIN..."
    cp "$SCRIPT_PATH" "$INTERNAL_BIN"
    chmod +x "$INTERNAL_BIN"
    
    # Create Desktop Entry
    echo "Creating desktop entry..."
    cat > "$HOME/.local/share/applications/mega-mobile-toolkit.desktop" <<EOL
[Desktop Entry]
Type=Application
Name=Mega Mobile Toolkit
Exec="$INTERNAL_BIN" %F
Icon=MegaMobile
StartupWMClass=$WM_CLASS
Terminal=false
Categories=Utility;System;
MimeType=application/vnd.android.package-archive;application/x-ios-app;
EOL
    # Some file managers (Nemo/Nautilus) treat a non-executable .desktop file
    # in ~/.local/share/applications as "untrusted" and won't honour its
    # Icon= line consistently — chmod +x it so it's trusted everywhere.
    chmod +x "$HOME/.local/share/applications/mega-mobile-toolkit.desktop"

    # Create Service Menus for KDE/Dolphin (Plasma 5 + Plasma 6)
    if command -v dolphin >/dev/null 2>&1 || \
       [ -d "$HOME/.local/share/kservices5" ] || \
       [ -d "$HOME/.local/share/kio" ]; then
        echo "Creating KDE/Dolphin service menu..."

        # Choose install path: prefer whichever location already exists.
        # If neither exists, create the Plasma 6 location.
        _kde_menu_dir=""
        if [ -d "$HOME/.local/share/kservices5/ServiceMenus" ]; then
            _kde_menu_dir="$HOME/.local/share/kservices5/ServiceMenus"
        elif [ -d "$HOME/.local/share/kio/servicemenus" ]; then
            _kde_menu_dir="$HOME/.local/share/kio/servicemenus"
        else
            _kde_menu_dir="$HOME/.local/share/kio/servicemenus"
            mkdir -p "$_kde_menu_dir"
        fi

        cat > "$_kde_menu_dir/mega-mobile-toolkit.desktop" <<EOL
[Desktop Entry]
Type=Service
ServiceTypes=KonqPopupMenu/Plugin
MimeType=application/vnd.android.package-archive;application/x-ios-app;
Actions=install;
[Desktop Action install]
Name=Install with Mega Mobile Toolkit
Exec="$INTERNAL_BIN" %F
Icon=MegaMobile
EOL
    fi
    
    # Create Service Menu for Nemo (Cinnamon/Linux Mint)
    if command -v nemo >/dev/null 2>&1 || [ -d "$HOME/.local/share/nemo" ]; then
        echo "Creating Nemo service menu..."
        mkdir -p "$HOME/.local/share/nemo/actions"
        cat > "$HOME/.local/share/nemo/actions/mega-mobile-toolkit.nemo_action" <<EOL
[Nemo Action]
Name=Install with Mega Mobile Toolkit
Comment=Install APK or IPA files
Exec="$INTERNAL_BIN" %F
Icon-Name=MegaMobile
Selection=any
Extensions=apk;ipa;
EOL
    fi

    # Update Desktop Database
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1
    fi
    
    touch "$INSTALL_FLAG"

    # If this install ran as root, everything we just wrote under $HOME (now
    # pointed at the real user's home) is still owned by root. Hand it back
    # to the real user so they can actually use/update it without sudo.
    if $RUNNING_AS_ROOT; then
        echo "Fixing file ownership for $REAL_USER..."
        chown -R "$REAL_USER":"$REAL_USER" \
            "$ICON_DIR" \
            "$HOME/.local/share/applications" \
            "$HOME/.local/bin" \
            "$HOME/.cache" \
            2>/dev/null
        [ -n "${_kde_menu_dir:-}" ] && chown -R "$REAL_USER":"$REAL_USER" "$_kde_menu_dir" 2>/dev/null
        [ -d "$HOME/.local/share/nemo/actions" ] && chown -R "$REAL_USER":"$REAL_USER" "$HOME/.local/share/nemo/actions" 2>/dev/null
    fi
    
    echo ""
    echo "✓ Installation Complete!"
    echo ""
    echo "You can now:"
    echo "  1. Launch from application menu: 'Mega Mobile Toolkit'"
    echo "  2. Right-click APK/IPA files and select 'Install with Mega Mobile Toolkit'"
    echo "  3. Run from terminal: $INTERNAL_BIN"
    echo ""
    
    # If we ran with -install flag, stop here
    if [[ "$1" == "-install" ]]; then
        if command -v notify-send >/dev/null 2>&1; then
            notify-send -i "$ICON_PATH" "Mega Mobile Toolkit" "Installation complete!"
        fi
        exit 0
    fi
fi

# Ensure icon files exist and ICON_PATH is set on every run.
# _ensure_icon() is fast (stat checks only) after the first install.
_ensure_icon
ICON_PATH=$(_pick_icon_path)

###############################
# 4. DATABASE FUNCTIONS
###############################
update_db() {
    local type="$1"
    local id="$2"
    local user="$3"
    
    # Remove any existing entry with this ID (prevents duplicates)
    if [ -f "$DB_FILE" ]; then
        grep -v "|${id}|" "$DB_FILE" > "$DB_FILE.tmp" 2>/dev/null || true
        mv "$DB_FILE.tmp" "$DB_FILE"
    fi
    
    # Add new entry
    echo "$type|$id|$user" >> "$DB_FILE"
    echo "$id" > "$LAST_USED_FILE"
}

get_device_info() {
    local id="$1"
    grep "|$id|" "$DB_FILE" | head -n1
}

###############################
# 5. STATUS CHECKERS
###############################
get_status() {
    local type="$1"
    local id="$2"
    
    if [[ "$type" == "Android" ]]; then
        local adb_state
        adb_state=$(adb devices 2>/dev/null | awk -v id="$id" '$1==id {print $2}')
        case "$adb_state" in
            device)
                echo "<b><span color='green'>ONLINE (USB)</span></b>"
                ;;
            offline)
                echo "<span color='red'>OFFLINE</span>"
                ;;
            unauthorized)
                echo "<span color='orange'>Unauthorized - Check Device</span>"
                ;;
            recovery)
                echo "<b><span color='blue'>Recovery Mode</span></b>"
                ;;
            sideload)
                echo "<b><span color='blue'>Sideload Mode</span></b>"
                ;;
            *)
                echo "<span color='red'>OFFLINE</span>"
                ;;
        esac
    else
        if ping -c 1 -W 1 "$id" >/dev/null 2>&1; then
            echo "<b><span color='green'>ONLINE ($id)</span></b>"
        else
            echo "<span color='red'>OFFLINE</span>"
        fi
    fi
}

###############################
# 6.2 NETWORK SCANNER (AUTO-JAILBREAK DETECT)
###############################
scan_network() {
    local prefix=$(get_default_prefix)
    local subnet="${prefix}0/24"

    # Scale parallelism with CPU count, capped at 32
    local _ncpu
    _ncpu=$(nproc 2>/dev/null || echo 4)
    (( _ncpu > 32 )) && _ncpu=32
    
    (
        echo "5"; echo "# Initializing network scanner..."
        sleep 0.3
        echo "10"; echo "# Scanning $subnet for jailbroken iPads..."
        
        # Fast scan: search IPs 1-254 on the current network
        local found_ips
        found_ips=$(seq 1 254 | xargs -P"$_ncpu" -I{} sh -c "ping -c1 -W1 ${prefix}{} >/dev/null && echo ${prefix}{}")
        
        local ip_count
        ip_count=$(echo "$found_ips" | wc -w)
        echo "25"; echo "# Found $ip_count responsive hosts, testing for SSH access..."
        
        local count=0
        local tested=0
        local total_to_test=$ip_count
        
        for ip in $found_ips; do
            tested=$((tested + 1))
            local pct=$((25 + (tested * 65 / total_to_test)))
            echo "$pct"
            echo "# Testing $ip for jailbreak access... [$tested/$total_to_test]"
            
            # Check if Port 22 is open and 'alpine' works as a password
            if sshpass -p "alpine" ssh $SSH_OPTS -o ConnectTimeout=1 "root@$ip" "echo success" 2>/dev/null | grep -q "success"; then
                echo "# ✓ Found jailbroken iPad at $ip!"
                # Device verified as jailbroken iPad
                [ ! -f "$SSH_KEY" ] && ssh-keygen -t rsa -b 2048 -f "$SSH_KEY" -N "" -q
                sshpass -p "alpine" ssh-copy-id -i "$SSH_KEY.pub" $SSH_OPTS "root@$ip" >/dev/null 2>&1
                update_db "iPad" "$ip" "root"
                count=$((count+1))
            fi
        done
        
        echo "95"; echo "# Finalizing scan results..."
        sleep 0.3
        echo "100"
        
        if [ $count -gt 0 ]; then
            echo "# ✓ Successfully found and added $count jailbroken iPad(s)!"
        else
            echo "# No jailbroken iPads found on this network"
        fi
    ) | case "$DIALOG_BACKEND" in
        yad)
            yad --progress \
                --title="Network Scanner - $subnet" \
                --text="Scanning for jailbroken iPads..." \
                --percentage=0 \
                --auto-close \
                --auto-kill \
                --width=650 \
                --height=180 \
                --center \
                --borders=15 \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --enable-log \
                --log-height=120
            ;;
        zenity)
            zenity --progress \
                --title="Network Scanner" \
                --text="Scanning network..." \
                --percentage=0 \
                --auto-close \
                --width=650 \
                --height=150
            ;;
        terminal)
            while read -r line; do
                if [[ "$line" =~ ^[0-9]+$ ]]; then
                    echo -ne "\rProgress: $line%  "
                else
                    echo -e "\n${line#\# }"
                fi
            done
            echo
            ;;
    esac
}


###############################
# 6. RESET TOOLKIT FUNCTION
###############################
reset_toolkit() {
    local msg="<b>WARNING:</b> This will delete all saved devices, SSH keys, and logs.\n\n"
    msg+="Are you sure you want to start fresh?"
    
    if ! ask_question "Factory Reset" "$msg" "Yes, Reset Everything" "No, Cancel"; then
        return
    fi
    
    # Clear Database files
    > "$DB_FILE"
    rm -f "$LAST_USED_FILE" 2>/dev/null
    
    # Clear SSH Keys related to this toolkit
    rm -f "$SSH_KEY" "$SSH_KEY.pub" 2>/dev/null
    
    # Clear logs
    rm -f "$HOME/Desktop/Failed_APK_"*.txt 2>/dev/null
    rm -f "$HOME/Desktop/Failed_IPA_"*.txt 2>/dev/null
    
    show_info "Reset Complete" "Toolkit has been reset to factory defaults.\n\nAll devices and configurations have been cleared."
}

###############################
# 7. SSH ERROR HANDLING
###############################
handle_ssh_error() {
    local sel_id="$1"
    local info=$(get_device_info "$sel_id")
    local type=$(echo "$info" | cut -d'|' -f1)
    local user=$(echo "$info" | cut -d'|' -f3)
    
    local msg="<b>SSH Connection Failed!</b>\n\n"
    msg+="Unable to connect to iPad at <b>$sel_id</b>\n\n"
    msg+="<b>Possible causes:</b>\n"
    msg+="  • Changed SSH keys\n"
    msg+="  • Network connectivity issues\n"
    msg+="  • iPad SSH service not running\n\n"
    msg+="Would you like to re-authenticate?"
    
    case "$DIALOG_BACKEND" in
        yad)
            yad --question \
                --image="dialog-warning" \
                --title="SSH Connection Failed" \
                --text="$msg" \
                --button="Remove Device:2" \
                --button="Cancel:1" \
                --button="Re-authenticate:0" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=500 \
                --height=250 \
                --center \
                --borders=15
            ;;
        zenity)
            zenity --question \
                --title="SSH Connection Failed" \
                --text="$(echo -e "$msg" | sed 's/<[^>]*>//g')" \
                --width=500 \
                --height=250
            ;;
        terminal)
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "  ⚠️  SSH Connection Failed"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo -e "$msg" | sed 's/<[^>]*>//g'
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "1) Re-authenticate"
            echo "2) Remove Device"
            echo "3) Cancel"
            read -p "Select option: " choice
            case "$choice" in
                1) return 0 ;;
                2) return 2 ;;
                *) return 1 ;;
            esac
            ;;
    esac
    
    local choice=$?
    
    if [ $choice -eq 0 ]; then
        # Re-authenticate
        local out=$(show_form "Re-authenticate iPad" "Enter credentials for <b>$sel_id</b>:" \
            "--field=SSH User:" "$user" \
            "--field=SSH Password:H" "alpine")
        
        [ $? -ne 0 ] && return 1
        
        local new_user=$(echo "$out" | cut -d'|' -f1)
        local ssh_pass=$(echo "$out" | cut -d'|' -f2)
        
        # Remove old keys
        ssh-keygen -R "$sel_id" 2>/dev/null
        rm -f "$SSH_KEY" "$SSH_KEY.pub" 2>/dev/null
        
        # Generate new SSH key
        ssh-keygen -t rsa -b 2048 -f "$SSH_KEY" -N "" -q
        
        # Copy new SSH key
        if command -v sshpass >/dev/null 2>&1; then
            if sshpass -p "$ssh_pass" ssh-copy-id -i "$SSH_KEY.pub" $SSH_OPTS "$new_user@$sel_id" >/dev/null 2>&1; then
                update_db "iPad" "$sel_id" "$new_user"
                show_info "Success" "Re-authentication successful!\n\nYou can now try the operation again."
                return 0
            else
                show_error "Authentication Failed" "Re-authentication failed!\n\nPlease check your credentials and try again."
                return 1
            fi
        else
            show_error "Missing Dependency" "sshpass is not installed.\n\nCannot re-authenticate automatically."
            return 1
        fi
    elif [ $choice -eq 2 ]; then
        # Remove device
        sed -i "\||$sel_id||d" "$DB_FILE" 2>/dev/null
        show_info "Device Removed" "Device has been removed from the database."
        return 1
    fi
    
    return 1
}

# Open a terminal window already logged into the selected device — ssh for
# iPad (works regardless of the libimobiledevice/OpenSSL3 pairing issue,
# since it's a completely separate SSH connection, not lockdownd/USB), or
# adb shell for Android. Replaces the screenshot button.
# Open a terminal window already logged into the selected device — ssh for
# iPad (works regardless of the libimobiledevice/OpenSSL3 pairing issue,
# since it's a completely separate SSH connection, not lockdownd/USB), or
# adb shell for Android. Replaces the screenshot button.
#
# Uses $OSTERM, detected once at startup (see SYSTEM DETECTION block) —
# previously detected but never actually used anywhere in the script.
open_terminal() {
    local sel_id="$1"
    local info=$(get_device_info "$sel_id")
    local type=$(echo "$info" | cut -d'|' -f1)
    local user=$(echo "$info" | cut -d'|' -f3)

    local -a login_cmd
    if [[ "$type" == "Android" ]]; then
        login_cmd=(adb -s "$sel_id" shell)
    else
        login_cmd=(ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id")
    fi

    if [[ -z "$OSTERM" ]]; then
        show_error "No Terminal Found" "Could not find a terminal emulator to open.\n\nYou can connect manually with:\n${login_cmd[*]}"
        return
    fi

    # Build a single string for `bash -c`, quoting each arg safely.
    local cmd_str
    cmd_str=$(printf '%q ' "${login_cmd[@]}")
    cmd_str+="; echo; echo '[session closed — press Enter to close this window]'; read"

    # Most terminal emulators accept `-e <cmd>`, but a few need their own
    # flag (gnome-terminal/mate-terminal/tilix use `--`).
    case "$OSTERM" in
        gnome-terminal|mate-terminal|tilix)
            "$OSTERM" -- bash -c "$cmd_str"
            ;;
        xfce4-terminal)
            xfce4-terminal -e "bash -c \"$cmd_str\""
            ;;
        *)
            "$OSTERM" -e bash -c "$cmd_str"
            ;;
    esac
}

###############################
# 8. REBOOT FUNCTION
###############################
ask_reboot() {
    local sel_id="$1"
    local info=$(get_device_info "$sel_id")
    local type=$(echo "$info" | cut -d'|' -f1)
    local user=$(echo "$info" | cut -d'|' -f3)
    
    local msg="Are you sure you want to reboot the <b>$type</b> device?\n\n"
    msg+="Device: <b>$sel_id</b>"
    
    if ! ask_question "Reboot Device" "$msg" "Yes, Reboot" "No, Cancel"; then
        return
    fi
    
    if [[ "$type" == "Android" ]]; then
        adb -s "$sel_id" reboot
    else
        if ! ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "reboot" 2>/dev/null; then
            if handle_ssh_error "$sel_id"; then
                # Retry after successful re-authentication
                ask_reboot "$sel_id"
            fi
        fi
    fi
}

###############################
# 9. BULK UNINSTALL FUNCTION
###############################
bulk_uninstall() {
    local sel_id="$1"
    
    if [ -z "$sel_id" ]; then
        show_error "No Device Selected" "Please select a device from the list before attempting to uninstall apps."
        return
    fi

    local info=$(get_device_info "$sel_id")
    local type=$(echo "$info" | cut -d'|' -f1)
    local user=$(echo "$info" | cut -d'|' -f3)
    
    local msg="<b>⚠️  DANGER ZONE  ⚠️</b>\n\n"
    msg+="This will <b>PERMANENTLY REMOVE</b> all user-installed apps from:\n\n"
    msg+="  <b>Device Type:</b> $type\n"
    msg+="  <b>Identifier:</b> $sel_id\n\n"
    msg+="<b>This action cannot be undone!</b>\n\n"
    msg+="Are you absolutely sure you want to proceed?"
    
    if ! ask_question "Bulk Uninstall - Confirmation Required" "$msg" "Yes, Nuke Everything" "No, Cancel"; then
        return
    fi
    
    if [[ "$type" == "Android" ]]; then
        (
            echo "10"; echo "# Fetching installed package list..."
            APPS=$(adb -s "$sel_id" shell "pm list packages -3" 2>/dev/null | cut -d':' -f2 | tr -d '\r')
            if [ -z "$APPS" ]; then 
                echo "100"
                echo "# No user-installed apps found"
                exit 0
            fi
            TOTAL_APPS=$(echo "$APPS" | wc -l)
            echo "15"; echo "# Found $TOTAL_APPS apps to remove..."
            CURR=0
            for pkg in $APPS; do
                CURR=$((++CURR))
                PCT=$((15 + (CURR * 85 / TOTAL_APPS)))
                echo "$PCT"
                echo "# [$CURR/$TOTAL_APPS] Removing: $pkg"
                adb -s "$sel_id" uninstall --user 0 "$pkg" >/dev/null 2>&1
                sleep 0.1  # Prevent overwhelming the device
            done
            echo "100"
            echo "# Completed! Removed $TOTAL_APPS apps"
        ) | case "$DIALOG_BACKEND" in
            yad)
                yad --progress \
                    --title="Android Bulk Uninstall - $sel_id" \
                    --text="Removing all user-installed applications..." \
                    --percentage=0 \
                    --auto-close \
                    --auto-kill \
                    --width=600 \
                    --height=150 \
                    --center \
                    --borders=15 \
                    --class="$WM_CLASS" \
                    --window-icon="$ICON_PATH" \
                    --enable-log \
                    --log-height=100
                ;;
            zenity)
                zenity --progress \
                    --title="Android Bulk Uninstall" \
                    --text="Removing apps..." \
                    --percentage=0 \
                    --auto-close \
                    --width=600 \
                    --height=150
                ;;
            terminal)
                while read -r line; do
                    if [[ "$line" =~ ^[0-9]+$ ]]; then
                        echo -ne "\rProgress: $line%  "
                    else
                        echo -e "\n${line#\# }"
                    fi
                done
                echo
                ;;
        esac
    elif [[ "$type" == "iPad" ]]; then
        if ! ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "echo test" >/dev/null 2>&1; then
            if ! handle_ssh_error "$sel_id"; then return; fi
            info=$(get_device_info "$sel_id"); user=$(echo "$info" | cut -d'|' -f3)
        fi
        (
            echo "10"; echo "# Connecting to iPad via SSH..."
            sleep 0.5
            ###echo "20"; echo "# Removing application bundles..."
            ###ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "rm -rf /var/mobile/Containers/Bundle/Application/*" 2>/dev/null
            ###echo "50"; echo "# Removing application data..."
            ###ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "rm -rf /var/mobile/Containers/Data/Application/*" 2>/dev/null

            #echo "20"; echo "# Enumerating installed user apps..."

            #APP_LIST=$(ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" \
            #  "ls /Applications 2>/dev/null | sed 's/.app$//'")

            #if [ -z "$APP_LIST" ]; then
            #  echo "No removable apps found"
            #else
            #  COUNT=$(echo "$APP_LIST" | wc -l)
            #  i=0

            #  for APP in $APP_LIST; do
            #    i=$((i+1))
            #    PROGRESS=$((20 + (i * 60 / COUNT)))

            #    echo "$PROGRESS"; echo "# Removing $APP..."

            #    ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" \
            #      "uicache --uninstall /Applications/$APP.app" \
            #      >/dev/null 2>&1
            #  done
            #fi
            #
            ##Run this 2nd method just in case:
            #ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" 'for APP in /Applications/*.app; do uicache --uninstall "$APP" >/dev/null 2>&1; done'
            
            #This is the safer option:
            ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" 'for APP in /Applications/*.app; do BID=$(/usr/libexec/PlistBuddy -c "Print :CFBundleIdentifier" "$APP/Info.plist" 2>/dev/null); case "$BID" in com.apple.*|com.saurik.*|com.cydia.*|org.coolstar.*|net.*|*jailbreak*|*ipa*|"") continue ;; esac; uicache --uninstall "$APP" >/dev/null 2>&1; done; uicache -a >/dev/null 2>&1'


            #echo "75"; echo "# Refreshing icon cache..."
            #ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "uicache" 2>/dev/null

            #Disabled Restarting springboard, not needed.
            #echo "90"; echo "# Restarting SpringBoard..."
            #ssh -i "$SSH_KEY" $SSH_OPTS "$user@$sel_id" "killall -9 SpringBoard" 2>/dev/null
            echo "100"; echo "# Completed! All user apps removed"
        ) | case "$DIALOG_BACKEND" in
            yad)
                yad --progress \
                    --title="iPad Bulk Uninstall - $sel_id" \
                    --text="Removing all user-installed applications..." \
                    --percentage=0 \
                    --auto-close \
                    --auto-kill \
                    --width=600 \
                    --height=150 \
                    --center \
                    --borders=15 \
                    --class="$WM_CLASS" \
                    --window-icon="$ICON_PATH" \
                    --enable-log \
                    --log-height=100
                ;;
            zenity)
                zenity --progress \
                    --title="iPad Bulk Uninstall" \
                    --text="Removing apps..." \
                    --percentage=0 \
                    --auto-close \
                    --width=600 \
                    --height=150
                ;;
            terminal)
                while read -r line; do
                    if [[ "$line" =~ ^[0-9]+$ ]]; then
                        echo -ne "\rProgress: $line%  "
                    else
                        echo -e "\n${line#\# }"
                    fi
                done
                echo
                ;;
        esac
    fi
}

###############################
# 10. INSTALLATION LOGIC
###############################
run_install_logic() {
    local target_id="$1"
    shift
    local raw_files=("$@")

    # Handle multi-select IPA/APK passed as a single |-separated string
    if [ "${#raw_files[@]}" -eq 1 ] && [[ "${raw_files[0]}" == *"|"* ]]; then
        IFS='|' read -r -a raw_files <<< "${raw_files[0]}"
    fi
    
    local info=$(get_device_info "$target_id")
    local type=$(echo "$info" | cut -d'|' -f1)
    local user=$(echo "$info" | cut -d'|' -f3)
    
    if [[ "$type" == "iPad" ]]; then
        if ! ssh -i "$SSH_KEY" $SSH_OPTS "$user@$target_id" "echo test" >/dev/null 2>&1; then
            if ! handle_ssh_error "$target_id"; then return; fi
            info=$(get_device_info "$target_id"); user=$(echo "$info" | cut -d'|' -f3)
        fi
    fi
    
    IFS=$'\n' sorted_files=($(sort -f <<<"${raw_files[*]}"))
    unset IFS
    
    local total=${#sorted_files[@]}
    local has_errors=0
    
    (
        echo "0"; echo "# Initializing installation process..."
        sleep 0.3
        
        for ((i=0; i<total; i++)); do
            local file="${sorted_files[$i]}"
            local name=$(basename "$file")
            local count=$((i + 1))
            local pct=$((i * 100 / total))
            
            echo "$pct"
            echo "# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "# Processing [$count/$total]: $name"
            echo "# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            
            if [[ "$type" == "Android" ]]; then
                # run_aapt transparently falls back to aapt2 if aapt is absent
                local pkg
                pkg=$(run_aapt dump badging "$file" 2>/dev/null | grep "package: name=" | cut -d"'" -f2)
                if [ -n "$pkg" ] && adb -s "$target_id" shell "pm list packages" 2>/dev/null | grep -q "package:$pkg$"; then
                    echo "# ⏭️  Already installed, skipping: $name"
                    continue
                fi
                echo "# 📦 Installing Android package..."
                local out
                out=$(adb -s "$target_id" install -r "$file" 2>&1)
                if [[ "$out" != *"Success"* ]]; then
                    echo "# ❌ Installation failed: $name"
                    printf "[%s] %s | %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$name" "$out" >> "$FAILED_APK"
                    has_errors=1
                else
                    echo "# ✓ Successfully installed: $name"
                fi
            else
                echo "# 📤 Copying to device: $name"
                local remote_ipa="/var/root/ipa_${MY_PID}.ipa"
                if ! scp -i "$SSH_KEY" $SSH_OPTS "$file" "$user@$target_id:$remote_ipa" >/dev/null 2>&1; then
                    echo "# ❌ Copy failed: $name"
                    printf "[%s] %s | Copy failed\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$name" >> "$FAILED_IPA"
                    has_errors=1
                    continue
                fi

                echo "# 📲 Installing on device: $name"

                # Extract bundle identifier for optional post-install confirmation
                local bundle_id
                bundle_id=$(get_bundle_id_from_ipa "$file")

                ssh -i "$SSH_KEY" $SSH_OPTS "$user@$target_id" \
                    "installipa -d -f -r $remote_ipa; rm -f $remote_ipa" 2>&1

                # Best-effort verification: if we can confirm the bundle is present, say so.
                # If we can't confirm (bundle ID missing, path not yet populated, etc.)
                # we still report success — installipa exit status is the source of truth.
                if [[ -n "$bundle_id" ]] && ssh -i "$SSH_KEY" $SSH_OPTS "$user@$target_id" \
                    "find /var/mobile/Containers/Bundle/Application -maxdepth 2 -name Info.plist -exec grep -lF '$bundle_id' {} + 2>/dev/null | grep -q ." 2>/dev/null; then
                    echo "# ✓ Successfully installed (verified): $name"
                else
                    echo "# ✓ Successfully installed: $name"
                fi
            fi
            sleep 0.1  # Brief pause to prevent overwhelming the device
        done
        
        echo "95"
        if [[ "$type" == "iPad" ]]; then
            echo "# 🔄 Refreshing iPad icon cache..."
            ssh -i "$SSH_KEY" $SSH_OPTS "$user@$target_id" "uicache" >/dev/null 2>&1
        fi
        
        echo "100"
        echo "# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "# ✓ Installation complete!"
        echo "# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        
        if [ $has_errors -eq 1 ]; then
            echo "# ⚠️  Some installations failed - check error log"
        else
            echo "# All files installed successfully!"
        fi
    ) | case "$DIALOG_BACKEND" in
        yad)
            yad --progress \
                --title="Installing to $type - $target_id" \
                --text="Processing installation queue..." \
                --percentage=0 \
                --auto-close \
                --auto-kill \
                --width=700 \
                --height=450 \
                --center \
                --borders=15 \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --enable-log \
                --log-height=300 \
                --log-expanded
            ;;
        zenity)
            zenity --progress \
                --title="Installing to $type" \
                --text="Processing installations..." \
                --percentage=0 \
                --auto-close \
                --width=700 \
                --height=150
            ;;
        terminal)
            while read -r line; do
                if [[ "$line" =~ ^[0-9]+$ ]]; then
                    echo -ne "\rProgress: $line%  "
                else
                    echo -e "\n${line#\# }"
                fi
            done
            echo
            ;;
    esac
    
    if [ -s "$FAILED_APK" ] || [ -s "$FAILED_IPA" ]; then
        local log_file="$FAILED_APK"
        [[ "$type" == "iPad" ]] && log_file="$FAILED_IPA"
        
        local msg="Some installations failed.\n\n"
        msg+="<b>Error log saved to:</b>\n$log_file\n\n"
        msg+="Would you like to view the error log now?"
        
        if ask_question "Installation Errors Detected" "$msg" "View Log" "Close"; then
            open_file "$log_file"
        fi
    fi
}

###############################
# 11. ADD DEVICE
###############################
add_device() {
    local choice=$(show_list "Add New Device - Select Connection Type" \
        --column="Device Type" \
        --column="Connection Method" \
        "Android" "USB (ADB)" \
        "iPad" "Wi-Fi (SSH)")
    
    [ -z "$choice" ] && return
    
    if [[ "$choice" == "Android"* ]]; then
        # Android device via ADB
        echo "Detecting Android devices via ADB..."
        local serial
        serial=$(adb devices 2>/dev/null | awk 'NR>1 && $2=="device" {print $1; exit}')

        if [ -z "$serial" ]; then
            # Check if a device is present but not ready (unauthorized/offline)
            local not_ready
            not_ready=$(adb devices 2>/dev/null | awk 'NR>1 && $2!="" {print $2; exit}')
            local msg="<b>No Authorized Android Device Detected</b>\n\n"
            case "$not_ready" in
                unauthorized)
                    msg+="A device is connected but <b>not yet authorized</b>.\n\n"
                    msg+="Please check the device screen and tap <b>\"Allow USB Debugging\"</b>, then try again."
                    ;;
                offline)
                    msg+="A device is connected but appears <b>offline</b>.\n\n"
                    msg+="Try unplugging and reconnecting the USB cable."
                    ;;
                *)
                    msg+="Please ensure:\n"
                    msg+="  • Device is connected via USB\n"
                    msg+="  • USB debugging is enabled\n"
                    msg+="  • Device is authorized for debugging\n\n"
                    msg+="Then try again."
                    ;;
            esac
            show_error "Android Device Not Found" "$msg"
            return
        fi
        
        update_db "Android" "$serial" "shell"
        show_info "Device Added" "Android device successfully added!\n\n<b>Serial:</b> $serial"
    else
        # iPad device via SSH
        local out=$(show_form "Pair Jailbroken iPad" \
            "Enter the network credentials for your jailbroken iPad:" \
            "--field=IP Address:" "192.168.0." \
            "--field=SSH Username:" "root" \
            "--field=SSH Password:H" "alpine")
        
        [ -z "$out" ] && return
        
        local ip=$(echo "$out" | cut -d'|' -f1)
        local user=$(echo "$out" | cut -d'|' -f2)
        local pass=$(echo "$out" | cut -d'|' -f3)
        
        # Clear any existing local keys for this IP to prevent "Too many authentication failures"
        ssh-keygen -R "$ip" 2>/dev/null

        # Validate IP format
        if ! [[ $ip =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            show_error "Invalid IP Address" "Please enter a valid IP address in the format:\n192.168.x.x"
            return
        fi
        
        # Generate SSH key if needed
        [ ! -f "$SSH_KEY" ] && ssh-keygen -t rsa -b 2048 -f "$SSH_KEY" -N "" -q
        
        # Attempt SSH connection
        if command -v sshpass >/dev/null 2>&1; then
            if sshpass -p "$pass" ssh-copy-id -i "$SSH_KEY.pub" $SSH_OPTS "$user@$ip" >/dev/null 2>&1; then
                update_db "iPad" "$ip" "$user"
                show_info "Device Added" "iPad successfully paired and added!\n\n<b>IP Address:</b> $ip\n<b>User:</b> $user"
            else
                show_error "SSH Pairing Failed" "Failed to establish SSH connection.\n\nPlease verify:\n  • IP address is correct\n  • Device is on the same network\n  • SSH is enabled on the device\n  • Password is correct"
            fi
        else
            show_error "Missing Dependency" "sshpass is not installed.\n\nCannot authenticate automatically.\n\nPlease install sshpass and try again."
        fi
    fi
}

###############################
# 12. MAIN GUI LOOP
###############################
while true; do
    list_data=()
    while IFS='|' read -r type id user; do
        [ -n "$type" ] && list_data+=("$type" "$id" "$(get_status "$type" "$id")")
    done < "$DB_FILE"
    
    case "$DIALOG_BACKEND" in
        yad)
            menu_out=$(yad --list \
                --title="🔧 Mega Mobile Toolkit [PID: $MY_PID]" \
                --class="$WM_CLASS" \
                --window-icon="$ICON_PATH" \
                --width=800 \
                --height=500 \
                --center \
                --borders=10 \
                --column="Device Type" \
                --column="Identifier" \
                --column="Status":markup \
                "${list_data[@]}" \
                --button="Exit:1" \
                --button="🔄 Reset Toolkit:70" \
                --button="🔍 Scan Network:60" \
                --button="➕ Add Device:50" \
                --button="💻 Terminal:30" \
                --button="🗑️ Uninstall All:10" \
                --button="🔄 Reboot:20" \
                --button="📦 Install Files:0" \
                --search-column=2 \
                --print-column=2)
            
            exit_code=$?
            ;;
            
        zenity)
            # Build zenity list format
            zenity_data=()
            while IFS='|' read -r type id user; do
                if [ -n "$type" ]; then
                    _status=$(get_status "$type" "$id" | sed 's/<[^>]*>//g')
                    zenity_data+=("$type" "$id" "$_status")
                fi
            done < "$DB_FILE"
            
            menu_out=$(zenity --list \
                --title="Mega Mobile Toolkit" \
                --width=800 \
                --height=500 \
                --column="Type" \
                --column="Identifier" \
                --column="Status" \
                "${zenity_data[@]}" \
                --print-column=2)
            
            exit_code=$?
            
            if [ $exit_code -eq 0 ] && [ -n "$menu_out" ]; then
                # Show action menu
                action=$(zenity --list \
                    --title="Select Action" \
                    --column="Action" \
                    "Install Files" \
                    "Reboot Device" \
                    "Uninstall All Apps" \
                    "Open Terminal" \
                    "Add New Device" \
                    "Scan Network" \
                    "Reset Toolkit" \
                    "Exit")
                
                case "$action" in
                    "Install Files")      exit_code=0  ;;
                    "Reboot Device")      exit_code=20 ;;
                    "Uninstall All Apps") exit_code=10 ;;
                    "Open Terminal")      exit_code=30 ;;
                    "Add New Device")     exit_code=50 ;;
                    "Scan Network")       exit_code=60 ;;
                    "Reset Toolkit")      exit_code=70 ;;
                    "Exit"|"")            exit_code=1  ;;
                esac
            fi
            ;;
            
        terminal)
            echo ""
            echo "╔══════════════════════════════════════════════════════════════╗"
            echo "║         MEGA MOBILE TOOLKIT - Main Menu [PID: $MY_PID]      ║"
            echo "╚══════════════════════════════════════════════════════════════╝"
            echo ""
            echo "Connected Devices:"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            
            _idx=1
            declare -A device_map
            while IFS='|' read -r type id user; do
                if [ -n "$type" ]; then
                    _status=$(get_status "$type" "$id" | sed 's/<[^>]*>//g')
                    printf "%2d) %-10s  %-20s  %s\n" "$_idx" "$type" "$id" "$_status"
                    device_map[$_idx]="$id"
                    _idx=$((_idx + 1))
                fi
            done < "$DB_FILE"
            
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "Actions:"
            echo "  i) Install Files       r) Reboot Device"
            echo "  u) Uninstall All Apps  s) Open Terminal"
            echo "  a) Add Device          n) Scan Network"
            echo "  x) Reset Toolkit       q) Exit"
            echo ""
            read -p "Select device number (or action letter): " selection
            
            if [[ "$selection" =~ ^[0-9]+$ ]] && [ -n "${device_map[$selection]}" ]; then
                menu_out="${device_map[$selection]}"
                read -p "Action (i/r/u/s): " action
                case "$action" in
                    i) exit_code=0  ;;
                    r) exit_code=20 ;;
                    u) exit_code=10 ;;
                    s) exit_code=30 ;;
                    *) exit_code=1  ;;
                esac
            else
                menu_out=""
                case "$selection" in
                    a) exit_code=50 ;;
                    n) exit_code=60 ;;
                    x) exit_code=70 ;;
                    q) exit_code=1  ;;
                    *) exit_code=1  ;;
                esac
            fi
            ;;
    esac
    
    [[ "$exit_code" -eq 1 || "$exit_code" -eq 252 ]] && break
    
    sel_id=$(echo "$menu_out" | cut -d'|' -f1)
    [ -n "$sel_id" ] && echo "$sel_id" > "$LAST_USED_FILE"
    
    case $exit_code in
        70) reset_toolkit ;;
        60) scan_network ;;
        50) add_device ;;
        30) 
            if [ -n "$sel_id" ]; then
                open_terminal "$sel_id"
            else
                show_error "No Device Selected" "Please select a device first."
            fi
            ;;
        20) 
            if [ -n "$sel_id" ]; then
                ask_reboot "$sel_id"
            else
                show_error "No Device Selected" "Please select a device first."
            fi
            ;;
        10) 
            if [ -n "$sel_id" ]; then
                bulk_uninstall "$sel_id"
            else
                show_error "No Device Selected" "Please select a device first."
            fi
            ;;
        0) 
            if [ -n "$sel_id" ]; then
                info=$(get_device_info "$sel_id")
                type=$(echo "$info" | cut -d'|' -f1)
                ext="*.apk"
                base=$(get_apk_base)
                
                if [[ "$type" == "iPad" ]]; then
                    ext="*.ipa"
                    base=$(get_ipa_base)
                fi
                
                files=$(show_file_picker "Select ${type} Files to Install" "$ext" "$base/" "true")
                
                if [ -n "$files" ]; then
                    IFS='|' read -ra f_arr <<< "$files"
                    # Persist the directory of the first picked file for next session
                    if [[ "$type" == "iPad" ]]; then
                        save_last_ipa_dir "${f_arr[0]}"
                    else
                        save_last_apk_dir "${f_arr[0]}"
                    fi
                    run_install_logic "$sel_id" "${f_arr[@]}"
                fi
            else
                show_error "No Device Selected" "Please select a device before installing files."
            fi
            ;;
    esac
done

exit 0

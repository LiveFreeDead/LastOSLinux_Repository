#!/bin/bash

sudo apt install --yes darktable
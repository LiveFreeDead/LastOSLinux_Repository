#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════════
#  Sanitize – Installer
#  Installs:  $HOME/LLApps/Sanitizer/sanitize
#  Config:    $HOME/.config/sanitizer/Removes.ini
#  Icon:      $HOME/.local/share/icons/hicolor/*/apps/sanitize.png
#  Context menu: auto-detects installed file managers, adds ONE "Sanitize
#                Filename" entry to each.  CLI flags are still fully supported.
# ══════════════════════════════════════════════════════════════════════════════

INSTALL_DIR="${HOME}/LLApps/Sanitizer"
CONFIG_DIR="${HOME}/.config/sanitizer"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ICON_SRC="${SCRIPT_DIR}/LLApp.png"
ICON_NAME="sanitize"

# ── Colour helpers ────────────────────────────────────────────────────────────
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
CYN='\033[0;36m'; BLD='\033[1m'; RST='\033[0m'
ok()   { printf "  ${GRN}✓${RST}  %s\n" "$*"; }
skip() { printf "  ${CYN}–${RST}  %s\n" "$*"; }
warn() { printf "  ${YLW}⚠${RST}  %s\n" "$*"; }
info() { printf "  ${CYN}→${RST}  %s\n" "$*"; }
err()  { printf "  ${RED}✗${RST}  %s\n" "$*"; }
hdr()  { printf "\n${BLD}%s${RST}\n$(printf '─%.0s' $(seq 1 ${#1}))\n" "$1"; }

# ── Detection helpers ─────────────────────────────────────────────────────────
# has_bin: true if binary is in PATH
has_bin() { command -v "$1" &>/dev/null; }

# has_pkg: true if a package/binary OR a known config/data directory exists.
# This catches cases where the binary name differs (e.g. io.elementary.files)
# or where a flatpak install doesn't put the bin on PATH directly.
has_pkg() {
    local bin="$1" dir="$2"
    has_bin "$bin" && return 0
    [[ -n "$dir" && -d "$dir" ]] && return 0
    return 1
}

# ─────────────────────────────────────────────────────────────────────────────
hdr "Sanitize – Installer"
# ─────────────────────────────────────────────────────────────────────────────

# ── Detect installed file managers ───────────────────────────────────────────
hdr "Detecting file managers"

HAS_NEMO=false
HAS_THUNAR=false
HAS_DOLPHIN=false
HAS_NAUTILUS=false
HAS_CAJA=false
HAS_PANTHEON=false

# Nemo (Cinnamon)
has_pkg "nemo" "${HOME}/.local/share/nemo" && {
    HAS_NEMO=true; ok "Nemo detected"; }

# Thunar (XFCE)
has_pkg "thunar" "${HOME}/.config/Thunar" && {
    HAS_THUNAR=true; ok "Thunar detected"; }

# Dolphin (KDE) – check both bin and either KDE5/6 service dir presence
if has_bin "dolphin" \
   || [[ -d "${HOME}/.local/share/kservices5" ]] \
   || [[ -d "${HOME}/.local/share/kio" ]]; then
    HAS_DOLPHIN=true; ok "Dolphin (KDE) detected"
fi

# Nautilus (GNOME / Ubuntu)
has_pkg "nautilus" "${HOME}/.local/share/nautilus" && {
    HAS_NAUTILUS=true; ok "Nautilus detected"; }

# Caja (MATE)
has_pkg "caja" "${HOME}/.config/caja" && {
    HAS_CAJA=true; ok "Caja detected"; }

# Pantheon Files (elementary OS) – binary is io.elementary.files or pantheon-files
if has_bin "io.elementary.files" \
   || has_bin "pantheon-files" \
   || [[ -d "${HOME}/.local/share/contractor" ]]; then
    HAS_PANTHEON=true; ok "Pantheon Files (elementary) detected"
fi

if ! $HAS_NEMO && ! $HAS_THUNAR && ! $HAS_DOLPHIN \
   && ! $HAS_NAUTILUS && ! $HAS_CAJA && ! $HAS_PANTHEON; then
    warn "No supported file managers detected – skipping context menu setup"
fi

# ── Core directories ──────────────────────────────────────────────────────────
hdr "Core files"

mkdir -p "$INSTALL_DIR" "$CONFIG_DIR" "${HOME}/.local/bin"

cp "${SCRIPT_DIR}/sanitize" "${INSTALL_DIR}/sanitize"
chmod +x "${INSTALL_DIR}/sanitize"
ok "Installed script       → ${INSTALL_DIR}/sanitize"

ln -sf "${INSTALL_DIR}/sanitize" "${HOME}/.local/bin/sanitize"
ok "Symlinked into PATH    → ${HOME}/.local/bin/sanitize"

if [[ -f "${CONFIG_DIR}/Removes.ini" ]]; then
    warn "Removes.ini already exists – not overwriting"
    info "Fresh copy saved at      ${INSTALL_DIR}/Removes.ini.default"
    cp "${SCRIPT_DIR}/Removes.ini" "${INSTALL_DIR}/Removes.ini.default"
else
    cp "${SCRIPT_DIR}/Removes.ini" "${CONFIG_DIR}/Removes.ini"
    ok "Installed Removes.ini  → ${CONFIG_DIR}/Removes.ini"
fi

# ── Icon ──────────────────────────────────────────────────────────────────────
hdr "Icon"

for SZ in 256 128 64 48 32 16; do
    mkdir -p "${HOME}/.local/share/icons/hicolor/${SZ}x${SZ}/apps"
done

if [[ ! -f "$ICON_SRC" ]]; then
    err "LLApp.png not found in ${SCRIPT_DIR} – icon will be missing"
else
    cp "$ICON_SRC" "${INSTALL_DIR}/sanitize.png"
    cp "$ICON_SRC" "${HOME}/.local/share/icons/hicolor/256x256/apps/${ICON_NAME}.png"
    cp "$ICON_SRC" "${HOME}/.local/share/icons/${ICON_NAME}.png"
    ok "Installed 256px icon   → hicolor theme"

    if has_bin convert; then
        for SZ in 128 64 48 32 16; do
            convert "$ICON_SRC" -resize "${SZ}x${SZ}" \
                "${HOME}/.local/share/icons/hicolor/${SZ}x${SZ}/apps/${ICON_NAME}.png" \
                2>/dev/null && ok "Generated ${SZ}px icon"
        done
    else
        warn "ImageMagick not found – only 256px icon installed"
        info "Install:  sudo apt install imagemagick  /  sudo dnf install ImageMagick"
    fi

    if has_bin gtk-update-icon-cache; then
        gtk-update-icon-cache -f -t "${HOME}/.local/share/icons/hicolor" 2>/dev/null
        ok "Refreshed GTK icon cache"
    fi
    has_bin update-icon-caches && \
        update-icon-caches "${HOME}/.local/share/icons/hicolor" 2>/dev/null
fi

# ══════════════════════════════════════════════════════════════════════════════
#  CLEANUP HELPER
#  Removes any extra action files written by a previous multi-action install
#  so the user ends up with exactly one entry per file manager.
# ══════════════════════════════════════════════════════════════════════════════
cleanup_old_actions() {
    # Nemo – remove old variant .nemo_action files
    local nemo_dir="${HOME}/.local/share/nemo/actions"
    for f in sanitize-crop sanitize-series sanitize-year; do
        [[ -f "${nemo_dir}/${f}.nemo_action" ]] && \
            rm -f "${nemo_dir}/${f}.nemo_action" && \
            info "Removed old Nemo action: ${f}.nemo_action"
    done

    # Dolphin KDE5 – only the single sanitize.desktop should remain
    # (previous versions only wrote one file so nothing extra to remove)

    # Dolphin KDE6 – same
    :

    # Thunar – remove old variant unique-ids from uca.xml
    local uca="${HOME}/.config/Thunar/uca.xml"
    if [[ -f "$uca" ]]; then
        for uid in sanitize-crop-001 sanitize-series-001 sanitize-year-001; do
            if grep -qF "$uid" "$uca" 2>/dev/null; then
                # Delete the <action>…</action> block containing this uid
                awk -v uid="$uid" '
                    /<action>/ { blk=$0; in_blk=1; next }
                    in_blk      { blk=blk"\n"$0
                                  if (/<\/action>/) {
                                      if (blk !~ uid) print blk
                                      in_blk=0; blk=""
                                  }
                                  next }
                    { print }
                ' "$uca" > "${uca}.new" && mv "${uca}.new" "$uca"
                info "Removed old Thunar action: ${uid}"
            fi
        done
    fi

    # Nautilus – remove old variant scripts
    local ns="${HOME}/.local/share/nautilus/scripts"
    for lbl in "Sanitize - Crop to Episode" "Sanitize - Keep Series + Ep" \
               "Sanitize - Bracket Years"   "Sanitize - Remove Separators"; do
        [[ -f "${ns}/${lbl}" ]] && rm -f "${ns}/${lbl}" && \
            info "Removed old Nautilus script: ${lbl}"
    done

    # Caja – remove old variant scripts
    local cs="${HOME}/.config/caja/scripts"
    for lbl in "Sanitize - Crop to Episode" "Sanitize - Keep Series + Ep" \
               "Sanitize - Bracket Years"   "Sanitize - Remove Separators"; do
        [[ -f "${cs}/${lbl}" ]] && rm -f "${cs}/${lbl}" && \
            info "Removed old Caja script: ${lbl}"
    done

    # Pantheon – remove old variant contracts
    local pd="${HOME}/.local/share/contractor"
    for f in sanitize-crop sanitize-year; do
        [[ -f "${pd}/${f}.contract" ]] && \
            rm -f "${pd}/${f}.contract" && \
            info "Removed old Pantheon contract: ${f}.contract"
    done
}

# ══════════════════════════════════════════════════════════════════════════════
#  FILE MANAGER INTEGRATIONS  (only for detected managers)
# ══════════════════════════════════════════════════════════════════════════════

hdr "Context menu integration"

# ── Nemo ──────────────────────────────────────────────────────────────────────
if $HAS_NEMO; then
    NEMO_DIR="${HOME}/.local/share/nemo/actions"
    mkdir -p "$NEMO_DIR"
    cat > "${NEMO_DIR}/sanitize.nemo_action" <<EOF
[Nemo Action]
Active=true
Name=Sanitize Filename
Comment=Clean up media filenames - remove codec tags, fix separators, capitalise
Exec=sanitize %F
Icon-Name=${ICON_NAME}
Selection=Any
Extensions=any;
Quote=double
EOF
    ok "Nemo:    action installed  → ${NEMO_DIR}/sanitize.nemo_action"
    info "        Restart Nemo to apply:  nemo -q && nemo &"
else
    skip "Nemo:    not detected – skipped"
fi

# ── Thunar ────────────────────────────────────────────────────────────────────
if $HAS_THUNAR; then
    THUNAR_DIR="${HOME}/.config/Thunar"
    THUNAR_UCA="${THUNAR_DIR}/uca.xml"
    mkdir -p "$THUNAR_DIR"

    make_thunar_action() {
        local uid="$1" name="$2" cmd="$3" desc="$4"
        printf '<action>\n'
        printf '  <icon>%s</icon>\n'                "$ICON_NAME"
        printf '  <n>%s</n>\n'                      "$name"
        printf '  <unique-id>%s</unique-id>\n'      "$uid"
        printf '  <command>%s</command>\n'           "$cmd"
        printf '  <description>%s</description>\n'  "$desc"
        printf '  <range>*</range>\n'
        printf '  <patterns>*</patterns>\n'
        printf '  <startup-notify/>\n'
        printf '  <directories/>\n'
        printf '  <audio-files/>\n'
        printf '  <image-files/>\n'
        printf '  <other-files/>\n'
        printf '  <text-files/>\n'
        printf '  <video-files/>\n'
        printf '</action>\n'
    }

    THUNAR_UID_MAIN="sanitize-clean-001"

    if [[ ! -f "$THUNAR_UCA" ]]; then
        {
            printf '<?xml version="1.0" encoding="UTF-8"?>\n<actions>\n'
            make_thunar_action "$THUNAR_UID_MAIN" "Sanitize Filename" \
                "sanitize %F" "Clean up media filenames"
            printf '</actions>\n'
        } > "$THUNAR_UCA"
        ok "Thunar:  created UCA file   → ${THUNAR_UCA}"
    elif grep -qF "$THUNAR_UID_MAIN" "$THUNAR_UCA" 2>/dev/null; then
        ok "Thunar:  entry already present (no change)"
    else
        THUNAR_XML=$(make_thunar_action "$THUNAR_UID_MAIN" "Sanitize Filename" \
            "sanitize %F" "Clean up media filenames")
        THUNAR_TMP=$(mktemp)
        printf '%s' "$THUNAR_XML" > "$THUNAR_TMP"
        awk -v blk="$THUNAR_TMP" '
            /<\/actions>/ { while ((getline ln < blk) > 0) print ln; close(blk) }
            { print }
        ' "$THUNAR_UCA" > "${THUNAR_UCA}.new" && mv "${THUNAR_UCA}.new" "$THUNAR_UCA"
        rm -f "$THUNAR_TMP"
        ok "Thunar:  action injected     → ${THUNAR_UCA}"
    fi
    info "        Restart Thunar to apply"
else
    skip "Thunar:  not detected – skipped"
fi

# ── Dolphin (KDE 5 & 6) ───────────────────────────────────────────────────────
if $HAS_DOLPHIN; then
    write_dolphin_menu() {
        local dest="$1"
        mkdir -p "$(dirname "$dest")"
        cat > "$dest" <<EOF
[Desktop Entry]
Type=Service
ServiceTypes=KonqPopupMenu/Plugin
MimeType=all/all;inode/directory;
Actions=SanitizeClean;
Icon=${ICON_NAME}

[Desktop Action SanitizeClean]
Name=Sanitize Filename
Icon=${ICON_NAME}
Exec=sanitize %F
EOF
    }

    KDE5_DIR="${HOME}/.local/share/kservices5/ServiceMenus"
    KDE6_DIR="${HOME}/.local/share/kio/servicemenus"

    # Install to whichever KDE generation(s) are present
    KDE_INSTALLED=false

    # KDE6 takes priority; detect by kbuildsycoca6 or the kio dir already existing
    if has_bin kbuildsycoca6 || [[ -d "${HOME}/.local/share/kio" ]]; then
        write_dolphin_menu "${KDE6_DIR}/sanitize.desktop"
        ok "Dolphin: KDE6 service menu  → ${KDE6_DIR}/sanitize.desktop"
        has_bin kbuildsycoca6 && { kbuildsycoca6 --noincremental 2>/dev/null &
            ok "        KDE6 service cache refreshed"; }
        KDE_INSTALLED=true
    fi

    # KDE5 – install if kservices5 dir or kbuildsycoca5 present
    if has_bin kbuildsycoca5 || [[ -d "${HOME}/.local/share/kservices5" ]]; then
        write_dolphin_menu "${KDE5_DIR}/sanitize.desktop"
        ok "Dolphin: KDE5 service menu  → ${KDE5_DIR}/sanitize.desktop"
        has_bin kbuildsycoca5 && { kbuildsycoca5 --noincremental 2>/dev/null &
            ok "        KDE5 service cache refreshed"; }
        KDE_INSTALLED=true
    fi

    # Fallback: dolphin binary found but no KDE generation clue – install both
    if ! $KDE_INSTALLED; then
        write_dolphin_menu "${KDE5_DIR}/sanitize.desktop"
        write_dolphin_menu "${KDE6_DIR}/sanitize.desktop"
        ok "Dolphin: installed for KDE5 & KDE6 (generation unknown)"
    fi
else
    skip "Dolphin: not detected – skipped"
fi

# ── Nautilus ──────────────────────────────────────────────────────────────────
# Nautilus cannot show custom entries at the root context menu without a compiled
# extension; Scripts submenu is the only native user-level mechanism.
if $HAS_NAUTILUS; then
    NS="${HOME}/.local/share/nautilus/scripts"
    mkdir -p "$NS"
    cat > "${NS}/Sanitize Filename" <<'SCRIPTEOF'
#!/usr/bin/env bash
IFS=$'\n'
for f in $NAUTILUS_SCRIPT_SELECTED_FILE_PATHS; do
    [[ -n "$f" ]] && sanitize "$f"
done
SCRIPTEOF
    chmod +x "${NS}/Sanitize Filename"
    ok "Nautilus: script installed  → ${NS}/Sanitize Filename"
    warn "         Appears under right-click → Scripts (GNOME has no root-menu API)"
else
    skip "Nautilus: not detected – skipped"
fi

# ── Caja ──────────────────────────────────────────────────────────────────────
if $HAS_CAJA; then
    CS="${HOME}/.config/caja/scripts"
    mkdir -p "$CS"
    cat > "${CS}/Sanitize Filename" <<'SCRIPTEOF'
#!/usr/bin/env bash
IFS=$'\n'
for f in $CAJA_SCRIPT_SELECTED_FILE_PATHS; do
    [[ -n "$f" ]] && sanitize "$f"
done
SCRIPTEOF
    chmod +x "${CS}/Sanitize Filename"
    ok "Caja:    script installed  → ${CS}/Sanitize Filename"
    warn "         Appears under right-click → Scripts (Caja has no root-menu API)"
else
    skip "Caja:    not detected – skipped"
fi

# ── Pantheon Files ────────────────────────────────────────────────────────────
if $HAS_PANTHEON; then
    PD="${HOME}/.local/share/contractor"
    mkdir -p "$PD"
    cat > "${PD}/sanitize.contract" <<EOF
[Contractor Entry]
Name=Sanitize Filename
Description=Clean up media filenames - remove codec tags, fix separators, capitalise
Icon=${ICON_NAME}
MimeType=all
Exec=sanitize %U
EOF
    ok "Pantheon: contract installed → ${PD}/sanitize.contract"
else
    skip "Pantheon Files: not detected – skipped"
fi

# ── Clean up any old multi-action installs from previous versions ─────────────
hdr "Cleanup (previous installs)"
cleanup_old_actions

# ── Desktop entry (app launchers / Wayland portals) ───────────────────────────
hdr "Desktop entry"
mkdir -p "${HOME}/.local/share/applications"
cat > "${HOME}/.local/share/applications/sanitize.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Sanitize
GenericName=Filename Cleaner
Comment=Clean up media filenames - remove codec tags, fix separators, capitalise
Exec=${INSTALL_DIR}/sanitize %F
Icon=${ICON_NAME}
Terminal=false
Categories=Utility;FileTools;
MimeType=all/all;inode/directory;
StartupNotify=false
EOF
ok "Installed .desktop entry"
has_bin update-desktop-database && \
    update-desktop-database "${HOME}/.local/share/applications" 2>/dev/null && \
    ok "Updated desktop database"

# ── PATH check ────────────────────────────────────────────────────────────────
hdr "PATH"
if [[ ":$PATH:" == *":${HOME}/.local/bin:"* ]]; then
    ok "~/.local/bin is in your PATH"
else
    warn "~/.local/bin is NOT in your PATH"
    info "Add to ~/.bashrc or ~/.profile:"
    printf '\n       export PATH="$HOME/.local/bin:$PATH"\n\n'
fi

# ── Summary ───────────────────────────────────────────────────────────────────
printf "\n${BLD}${GRN}══════════════════════════════════════════${RST}\n"
printf "${BLD}${GRN}  Installation complete!${RST}\n"
printf "${BLD}${GRN}══════════════════════════════════════════${RST}\n\n"

print_status() {
    local flag="$1" label="$2" note="$3"
    if $flag; then
        printf "  ${GRN}✓${RST}  %-30s %s\n" "$label" "$note"
    else
        printf "  ${CYN}–${RST}  %-30s %s\n" "$label" "(not installed – not detected)"
    fi
}

printf "  ${BLD}File manager context menus:${RST}\n\n"
print_status $HAS_NEMO     "Nemo (Cinnamon)"         "root menu"
print_status $HAS_THUNAR   "Thunar (XFCE)"           "root menu"
print_status $HAS_DOLPHIN  "Dolphin (KDE)"           "root menu"
print_status $HAS_PANTHEON "Pantheon Files (elementary)" "root menu"
print_status $HAS_NAUTILUS "Nautilus (GNOME)"        "Scripts submenu"
print_status $HAS_CAJA     "Caja (MATE)"             "Scripts submenu"

printf "\n  ${BLD}CLI flags (always available):${RST}\n"
printf "    sanitize --ctrl           Crop at episode number\n"
printf "    sanitize --ctrl --shift   Keep series name + ep number\n"
printf "    sanitize --scrolllock     Bracket year numbers\n"
printf "    sanitize --pause          Strip \" - \" separators\n"
printf "    sanitize --help           Full usage reference\n\n"

#!/bin/bash

#Add package names and unremark to install from apt
sudo add-apt-repository -y ppa:persepolis/ppa
sudo apt-get update
sudo apt-get install -y persepolis
#!/bin/bash

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done


#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    ;;

  zorin)
    ;;

  *)
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#FlatPak Install Package for User
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "


#----- Add Your Code Here ------
$OSTERM -e "flatpak install --user -y --noninteractive flathub org.qbittorrent.qBittorrent"

mkdir -p $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/

cp -rf ./nova3 $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/
cp ./breeze-dark.qbtheme $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/
cp ./LLApp.png $HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/

#Try to change theme
#!/bin/bash

CONF_FILE="$HOME/.var/app/org.qbittorrent.qBittorrent/config/qBittorrent/qBittorrent.conf"
THEME_PATH="$HOME/.var/app/org.qbittorrent.qBittorrent/data/qBittorrent/breeze-dark.qbtheme"

# Backup first
cp "$CONF_FILE" "$CONF_FILE.bak"

# Replace or insert the line
sed -i "s|^General\\\\CustomUIThemePath=.*|General\\\\CustomUIThemePath=$THEME_PATH|" "$CONF_FILE"

# Replace or insert the line
sed -i "s|^General\\\\UseCustomUITheme=.*|General\\\\UseCustomUITheme=true|" "$CONF_FILE"


THEME_PATH="General\UseCustomUITheme=false"
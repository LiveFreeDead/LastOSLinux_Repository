#!/bin/bash

sudo apt install -y ./isomaster_1.3.13-1+b2_amd64.deb
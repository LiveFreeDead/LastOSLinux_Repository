#!/bin/bash

x-terminal-emulator -e "flatpak install --user -y --noninteractive io.freetubeapp.FreeTube"
#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------


#Copy Plymouth stuff, including replacing the Ubuntu Logo.
sudo cp -rf plymouth/themes /usr/share/plymouth

#Copy Ubuntu Logo Blanked:
sudo cp -f plymouth/ubuntu-logo.png /usr/share/plymouth/


##Line below not needed as it installs properly now
##sudo cp -f default.plymouth /etc/alternatives/
#
#sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth /usr/share/plymouth/themes/lastos-logo/lastos-logo.plymouth 100
#
##Update inframs 
#yes 0 | sudo update-alternatives --config default.plymouth
#sudo update-initramfs -u -k all
#
##Update Grub
##Make the error level 2 in grub (defaults to 4 in Ubuntu/Mint, 3 is recommended (2 Critical)(3 Error)(4 Warnings) - Disabled as this is for the Plymouth theme only
###    sudo grep -lZ 'GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"' /etc/default/grub| sudo xargs -0 sed -i 's|GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"|GRUB_CMDLINE_LINUX_DEFAULT="quiet loglevel=2 splash"|g'
##Not sure I need to update grub even?
##sudo update-grub



# Automate setting the Plymouth theme to lastos-logo

THEME_NAME="lastos-logo"
THEME_SRC="$PWD/plymouth/themes/$THEME_NAME"
THEME_DEST="/usr/share/plymouth/themes/$THEME_NAME"

# 1. Copy the theme folder
if [ ! -d "$THEME_DEST" ]; then
    echo "Copying theme to Plymouth themes folder..."
    sudo cp -r "$THEME_SRC" "$THEME_DEST"
else
    echo "Theme folder already exists in $THEME_DEST"
fi

# 2. Register theme with update-alternatives
PLYMOUTH_FILE="$THEME_DEST/$THEME_NAME.plymouth"
if [ ! -f "$PLYMOUTH_FILE" ]; then
    echo "Error: $PLYMOUTH_FILE not found!"
    exit 1
fi

echo "Registering theme with update-alternatives..."
sudo update-alternatives --install /usr/share/plymouth/themes/default.plymouth default.plymouth "$PLYMOUTH_FILE" 100

# 3. Automatically select the theme
sudo update-alternatives --set default.plymouth "$PLYMOUTH_FILE"

# 4. Update initramfs to apply theme at boot
echo "Updating initramfs..."
sudo update-initramfs -u

echo "Plymouth theme '$THEME_NAME' is now set as default!"
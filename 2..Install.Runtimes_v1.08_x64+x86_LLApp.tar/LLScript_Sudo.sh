#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#=============================================================================
#  UNIVERSAL INSTALLER, UPDATER & CLEANER (SUDO)
#=============================================================================

#---------- Functions ----------

# Helper: Run command with sudo if not root
run_priv() {
    if [ "$EUID" -ne 0 ]; then
        if command -v sudo >/dev/null 2>&1; then
            sudo "$@"
        else
            echo "Error: This command requires root privileges but sudo is missing."
            exit 1
        fi
    else
        "$@"
    fi
}

term_run() {
    local cmd="$1"

    # 1. Protection/Sanitization Block
    # If OSTERM contains a space (like "gnome-terminal --wait"), strip it.
    local CLEAN_TERM="${OSTERM%% *}"
    local FORCE_WAIT="false"

    # Detect if --wait was anywhere in the original string
    if [[ "$OSTERM" == *" --wait"* ]]; then
        FORCE_WAIT="true"
    fi

    local wait_arg=""
    local bg_proc="&"

    if [[ "$FORCE_WAIT" == "true" ]]; then
        wait_arg="--wait"
        bg_proc="" # Remove backgrounding so the script actually waits
    fi

    # 2. Re-built Case Logic using the CLEAN terminal name
    case "$CLEAN_TERM" in
        gnome-terminal|alacritty|kitty|terminator|tilix)
            # Line 41 Fix: We call the clean binary, then the optional wait arg
            $CLEAN_TERM $wait_arg -- bash -c "$cmd" $bg_proc
            ;;
        konsole|xfce4-terminal|lxterminal|mate-terminal|xterm|x-terminal-emulator)
            $CLEAN_TERM -e bash -c "$cmd" &
            ;;
        *)
            $CLEAN_TERM -e "$cmd" &
            ;;
    esac
}

# INSTALL Function
inst() {
    if command -v pamac >/dev/null 2>&1; then
        run_priv pamac install --no-confirm "$@"
    elif command -v dnf >/dev/null 2>&1; then
        run_priv dnf install -y --setopt=strict=0 "$@"
    elif command -v apt >/dev/null 2>&1; then
        run_priv apt install -y --no-remove "$@"
    elif command -v pacman >/dev/null 2>&1; then
        run_priv pacman -S --noconfirm --needed "$@"
    elif command -v zypper >/dev/null 2>&1; then
        run_priv zypper install -n "$@"
    elif command -v apk >/dev/null 2>&1; then
        run_priv apk add "$@"
    elif command -v xbps-install >/dev/null 2>&1; then
        run_priv xbps-install -y "$@"
    elif command -v eopkg >/dev/null 2>&1; then
        run_priv eopkg install -y "$@"
    elif command -v swupd >/dev/null 2>&1; then
        run_priv swupd bundle-add -y "$@"
    elif command -v emerge >/dev/null 2>&1; then
        run_priv emerge --noreplace "$@"
    elif command -v slackpkg >/dev/null 2>&1; then
        run_priv slackpkg install "$@"
    elif command -v yum >/dev/null 2>&1; then
        run_priv yum install -y "$@"
    else
        echo "Error: No supported package manager found to install $*"
    fi
}

# UPDATE REPOSITORIES Function
upd() {
    echo "Updating repository lists..."
    if command -v apt >/dev/null 2>&1; then run_priv apt update
    elif command -v dnf >/dev/null 2>&1; then run_priv dnf check-update
    elif command -v pacman >/dev/null 2>&1; then run_priv pacman -Sy
    elif command -v zypper >/dev/null 2>&1; then run_priv zypper refresh
    elif command -v apk >/dev/null 2>&1; then run_priv apk update
    elif command -v xbps-install >/dev/null 2>&1; then run_priv xbps-install -S
    elif command -v eopkg >/dev/null 2>&1; then run_priv eopkg update-repo
    elif command -v swupd >/dev/null 2>&1; then run_priv swupd update
    else echo "Update not supported or manager not found."
    fi
}

# CLEAN SYSTEM Function
cln() {
    echo "Cleaning up unneeded packages and cache..."
    if command -v apt >/dev/null 2>&1; then 
        run_priv apt autoremove -y && run_priv apt autoclean
    elif command -v dnf >/dev/null 2>&1; then 
        run_priv dnf autoremove -y && run_priv dnf clean all
    elif command -v pacman >/dev/null 2>&1; then 
        ORPHANS=$(pacman -Qdtq)
        if [ -n "$ORPHANS" ]; then
            run_priv pacman -Rns $ORPHANS --noconfirm
        else
            echo "No orphans to clean."
        fi
        run_priv pacman -Scc --noconfirm
    elif command -v zypper >/dev/null 2>&1; then 
        run_priv zypper clean --all
    elif command -v apk >/dev/null 2>&1; then 
        run_priv apk cache clean
    elif command -v xbps-remove >/dev/null 2>&1; then 
        run_priv xbps-remove -Oo
    elif command -v eopkg >/dev/null 2>&1; then 
        run_priv eopkg delete-cache
    fi
}

#---------- Detection ----------

TERMS=(
    gnome-terminal
    konsole
    xfce4-terminal
    lxterminal
    mate-terminal
    alacritty
    kitty
    terminator
    tilix
    x-terminal-emulator
    urxvt
    rxvt
    st
    xterm
)

OSTERM=""
for t in "${TERMS[@]}"; do
    if command -v "$t" >/dev/null 2>&1; then
        OSTERM="$t"
        break
    fi
done

# If Xojo passes an env var, use it, otherwise use what we detected
OSTERM="${OSTERM:-gnome-terminal}"

CURRENT_DE=${XDG_CURRENT_DESKTOP:-$XDG_SESSION_DESKTOP}
if [ -z "$CURRENT_DE" ]; then
    if pgrep -x "gnome-session" > /dev/null; then CURRENT_DE="gnome"
    elif pgrep -x "mate-session" > /dev/null; then CURRENT_DE="mate"
    elif pgrep -x "xfce4-session" > /dev/null; then CURRENT_DE="xfce"
    elif pgrep -x "plasma-desktop" > /dev/null || pgrep -x "plasmashell" > /dev/null; then CURRENT_DE="kde"
    elif pgrep -x "cinnamon" > /dev/null; then CURRENT_DE="cinnamon"
    elif pgrep -x "lxqt-session" > /dev/null; then CURRENT_DE="lxqt"
    elif pgrep -x "budgie-desktop" > /dev/null; then CURRENT_DE="budgie"
    fi
fi

if [ -z "$CURRENT_DE" ] && [ -n "$SUDO_USER" ]; then
    CURRENT_DE=$(sudo -u "$SUDO_USER" printenv XDG_CURRENT_DESKTOP)
fi

echo "----------------------------------------"
echo "Terminal Detected:  $OSTERM"
echo " Desktop Detected:  $CURRENT_DE"

# 3. Detect Package Manager & Set Variable
PM=""
if command -v pamac >/dev/null 2>&1; then PM="pamac"
elif command -v dnf >/dev/null 2>&1; then PM="dnf"
    sudo dnf install -y mesa-libGLU mesa-libGLU.i686 SDL2-devel SDL2-devel.i686 fltk fltk.i686 fuse-libs fuse-libs.i686 SDL2_image SDL2_image.i686 SDL2_image-devel SDL2_image-devel.i686 SDL2_gfx SDL2_gfx.i686 SDL2_sound SDL2_sound.i686 SDL2_mixer SDL2_mixer.i686 SDL2_net SDL2_net.i686 SDL2_ttf SDL2_ttf.i686 libepoxy libepoxy.i686 libstdc++ libstdc++.i686 libGLEW libGLEW.i686 meson pipewire-alsa pipewire-alsa.i686
elif command -v apt >/dev/null 2>&1; then PM="apt"
    echo "Installing i386 support..."
    sudo dpkg --add-architecture i386
    sudo apt update
    sudo apt install -y --no-remove libasound2-plugins:i386 libsdl2-2.0-0:i386 libfltk1.3:i386 pipewire-alsa:i386 libopenal1:i386 libudev1:i386 lib32z1 libsdl1.2-compat libglu1-mesa:i386 meson libfreetype6-dev libfreetype6 libglew-dev libsdl2-image-dev libfuse2t64:i386 libepoxy-dev
elif command -v pacman >/dev/null 2>&1; then PM="pacman"
elif command -v zypper >/dev/null 2>&1; then PM="zypper"
elif command -v apk >/dev/null 2>&1; then PM="apk"
elif command -v xbps-install >/dev/null 2>&1; then PM="xbps"
elif command -v swupd >/dev/null 2>&1; then PM="swupd"
elif command -v eopkg >/dev/null 2>&1; then PM="eopkg"
elif command -v emerge >/dev/null 2>&1; then PM="emerge"
elif command -v yum >/dev/null 2>&1; then PM="yum"
elif command -v slackpkg >/dev/null 2>&1; then PM="slackpkg"
fi

if [ -n "$PM" ]; then echo "  Package Manager:  $PM"; fi

if [ -f /etc/os-release ]; then . /etc/os-release; else ID="unknown"; fi
echo "    OS ID Detected:  $ID"
echo "----------------------------------------"

#----- Execution Flow / Installs ------
inst xclip xdotool wget gpg yad 7zip gnome-terminal trash-cli gparted rar unrar uget makeself archivemount dos2unix
inst webp fuse-overlayfs udftools libguestfs-tools
inst ffmpeg ffmpegthumbs mint-meta-codecs liboss4-salsa2
inst libsdl2-mixer-2.0-0 libsdl2-image-2.0-0 libsdl2-gfx-1.0-0 libsdl2-2.0-0 libsdl2-net-2.0-0 libglfw3 libxft2
inst libsdl2-2.0-0:i386 libsdl2-mixer-2.0-0:i386 libxft2:i386 libsdl2-image-2.0-0:i386 libsdl2-gfx-1.0-0:i386 libsdl2-net-2.0-0:i386
inst libasound2:i386 libasound2-data libasound2-plugins:i386
inst libfltk1.3 libfltk1.3:i386 mesa-libGLU.i686
inst libapr1 libaprutil1 libglib2.0-0 libxcb-cursor0 libasound2
inst qemu-utils samba wsdd sassc nbd-client

exit 0
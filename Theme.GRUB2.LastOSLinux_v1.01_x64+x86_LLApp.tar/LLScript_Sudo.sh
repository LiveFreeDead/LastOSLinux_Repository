#!/bin/bash

bash install.sh
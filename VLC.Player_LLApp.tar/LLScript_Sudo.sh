#!/bin/bash

sudo apt install --yes --install-recommends vlc
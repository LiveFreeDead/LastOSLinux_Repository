#!/bin/bash

x-terminal-emulator -e "flatpak install --user -y --noninteractive com.brave.Browser"
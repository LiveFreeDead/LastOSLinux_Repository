#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------

#Get Best Terminal For LLStore (in order)
TERMS=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${TERMS[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#extract themes and icons etc
sudo tar -xvf ./Overlay.tar -C /

#Install Mouse Theme
inst dmz-cursor-theme

#-------------------------------

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $PAMAC_CMD ]]; then #pamac
    PM=pamac
    echo "Package Manager: pamac"
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
elif [[ ! -z $APT_CMD ]]; then #apt
    PM=apt
    echo "Package Manager: apt"
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
elif [[ ! -z $EOPKG_CMD ]]; then #eopkg
    PM=eopkg
    echo "Package Manager: eopkg"
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
else
    echo "Unknown Package Manager. Script section skipped"
fi


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara)
    ;;

  opensuse-tumbleweed) 
    ;;

  arch|endeavouros)
    ;;

  biglinux)
    ;;

  solus)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
      ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon)
    #Set Dark Theme
    gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.cinnamon.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.cinnamon.theme name "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.x.apps.portal color-scheme "prefer-light"

    sudo gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-Y-Blue"
    sudo gsettings set org.cinnamon.desktop.interface icon-theme "Mint-Y-Sand"
    sudo gsettings set org.cinnamon.theme name "Mint-Y-Blue"
    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    sudo gsettings set org.x.apps.portal color-scheme "prefer-light"


    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"
    sudo gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"


    #Set Wallpaper
    gsettings set org.cinnamon.desktop.background picture-uri 'file:///usr/share/backgrounds/lastos/LastOSLight.jpg'
    sudo gsettings set org.cinnamon.desktop.background picture-uri 'file:///usr/share/backgrounds/lastos/LastOSLight.jpg'

    #Set Login Background
    gsettings set x.dm.slick-greeter background '/usr/share/backgrounds/lastos/Login.jpg'
    sudo gsettings set x.dm.slick-greeter background '/usr/share/backgrounds/lastos/Login.jpg'


    #Set Default WINE Mouse Cursor to DMZ-White
    sudo update-alternatives --set x-cursor-theme /usr/share/icons/DMZ-White/cursor.theme
    ;;

    gnome|ubuntu)
    #Set Dark Theme
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.gnome.theme name "Mint-Y-Blue"
    gsettings set org.x.apps.portal color-scheme "prefer-light"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-light"
    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    sudo gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    sudo gsettings set org.gnome.theme name "Mint-Y-Blue"
    sudo gsettings set org.x.apps.portal color-scheme "prefer-light"
    sudo gsettings set org.gnome.desktop.interface color-scheme "prefer-light"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"
    sudo gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    sudo gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.gnome.desktop.background color-shading-type "solid"
    gsettings set org.gnome.desktop.background picture-options "zoom"
    gsettings set org.gnome.desktop.background picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    gsettings set org.gnome.desktop.background picture-uri-dark "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    sudo gsettings set org.gnome.desktop.background color-shading-type "solid"
    sudo gsettings set org.gnome.desktop.background picture-options "zoom"
    sudo gsettings set org.gnome.desktop.background picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    sudo gsettings set org.gnome.desktop.background picture-uri-dark "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"

    #Set Login Background
    gsettings set org.gnome.desktop.screensaver picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    sudo gsettings set org.gnome.desktop.screensaver picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    ;;
  
  KDE|kde)
    lookandfeeltool -a org.kde.breezedark.desktop
    /usr/libexec/plasma-changeicons breeze-dark
    plasma-apply-wallpaperimage "/usr/share/backgrounds/lastos/LastOSLight.jpg"
    sudo lookandfeeltool -a org.kde.breezedark.desktop
    sudo /usr/libexec/plasma-changeicons breeze-dark
    sudo plasma-apply-wallpaperimage "/usr/share/backgrounds/lastos/LastOSLight.jpg"

    ;;

  lxde)
    ;;

  mate)
    gsettings set org.mate.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.mate.Marco.general theme "Mint-Y-Blue"
    gsettings set org.mate.interface icon-theme "Mint-Y-Sand"
    gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    gsettings set org.mate.background picture-filename "/usr/share/backgrounds/lastos/LastOSLight.jpg"

    sudo gsettings set org.mate.interface gtk-theme "Mint-Y-Blue"
    sudo gsettings set org.mate.Marco.general theme "Mint-Y-Blue"
    sudo gsettings set org.mate.interface icon-theme "Mint-Y-Sand"
    sudo gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #sudo gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    sudo gsettings set org.mate.background picture-filename "/usr/share/backgrounds/lastos/LastOSLight.jpg"
    ;;
  
  unity)
    ;;

  xfce)
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-light"
    gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"

    sudo gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    sudo gsettings set org.gnome.desktop.interface color-scheme "prefer-light"
    sudo gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    sudo gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac


#Install Apps - using Inst function to work on many Distro's and if packages available on it's repositories.
#inst numlockx xclip

#Make KDE apps/games dark to match theme
#echo  export QT_QPA_PLATFORMTHEME="qt5ct"  to ~/.profile
inst qt5ct adwaita-qt


#FlatPak System Wide, user should be done in non Sudo script
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "
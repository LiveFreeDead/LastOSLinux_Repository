#!/bin/bash

#Get Best Terminal
terms=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${terms[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done


#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  arch|endeavouros)
    ;;

  biglinux)
    ;;

  solus)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in

  cinnamon)
    #Set Dark Theme
    gsettings set org.cinnamon.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.cinnamon.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.cinnamon.theme name "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.x.apps.portal color-scheme "prefer-light"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.cinnamon.desktop.background picture-uri 'file:///usr/share/backgrounds/lastos/LastOSLight.jpg'

    #Set Login Background
    gsettings set x.dm.slick-greeter background '/usr/share/backgrounds/lastos/Login.jpg'


    #Change Main Menu icon to LastOS
    cd $HOME/.config/cinnamon/spices/menu@cinnamon.org/
    grep -lZ '"value": "start-here-symbolic"' 0.json | xargs -0 sed -i 's|"value": "start-here-symbolic"|"value": "linuxmint-logo-ring-symbolic"|g'

    grep -lZ '"value": "linuxmint-logo-ring-symbolic"' 0.json | xargs -0 sed -i 's|"value": "linuxmint-logo-ring-symbolic"|"value": "/usr/share/icons/Start Button.png"|g'

    #Restart Desktop (Let Icon Auto-Arrange be disable for this Session)
    nemo-desktop --quit
    nemo --no-default-window &

    ;;

  gnome|ubuntu)
    #Set Dark Theme
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.gnome.theme name "Mint-Y-Blue"
    gsettings set org.x.apps.portal color-scheme "prefer-light"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-light"

    #Set White Mouse Cursor
    gsettings set org.cinnamon.desktop.interface cursor-theme "DMZ-White"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"
    gsettings set x.dm.slick-greeter cursor-theme-name "DMZ-White"

    #Set Wallpaper
    gsettings set org.gnome.desktop.background color-shading-type "solid"
    gsettings set org.gnome.desktop.background picture-options "zoom"
    gsettings set org.gnome.desktop.background picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    gsettings set org.gnome.desktop.background picture-uri-dark "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"

    #Set Login Background
    gsettings set org.gnome.desktop.screensaver picture-uri "file:///usr/share/backgrounds/lastos/LastOSLight.jpg"
    ;;
  
  KDE|kde)
    lookandfeeltool -a org.kde.breezedark.desktop
    /usr/libexec/plasma-changeicons breeze-dark
    plasma-apply-wallpaperimage "/usr/share/backgrounds/lastos/LastOSLight.jpg"
    ;;

  lxde)
    ;;

  mate)
    gsettings set org.mate.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.mate.Marco.general theme "Mint-Y-Blue"
    gsettings set org.mate.interface icon-theme "Mint-Y-Sand"
    gsettings set org.mate.peripherals-mouse cursor-theme "DMZ-White"
    #Below doesn't work due to needing a direct installed icon, not a file name.
    #gsettings set org.mate.panel.menubar icon-name "/usr/share/icons/Start Button MATE.png"
    gsettings set org.mate.background picture-filename "/usr/share/backgrounds/lastos/LastOSLight.jpg"
    ;;
  
  unity)
    ;;

  xfce)
    gsettings set org.gnome.desktop.interface gtk-theme "Mint-Y-Blue"
    gsettings set org.gnome.desktop.interface color-scheme "prefer-light"
    gsettings set org.gnome.desktop.interface icon-theme "Mint-Y-Sand"
    gsettings set org.gnome.desktop.interface cursor-theme "DMZ-White"

    mkdir $HOME/.config/xfce
    cp -rf ./xfce4/. $HOME/.config/xfce
    ;;

  cosmic|pop)
    ;;
    
  budgie-desktop)
    
    ;;
    
  LXQt)
  	pcmanfm-qt --set-wallpaper=/usr/share/backgrounds/lastos/LastOSLight.jpg --wallpaper-mode=fit
  
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac


#FlatPak
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --user -y --noninteractive flathub "

mkdir -p $HOME/.themes/LastOS-MATE
cp -rf ./LastOS-MATE $HOME/.themes/
#!/bin/bash

mkdir -p $HOME/.config/autostart
cp -f ./conky.desktop $HOME/.config/autostart

cp -rf ./conky $HOME/.config/
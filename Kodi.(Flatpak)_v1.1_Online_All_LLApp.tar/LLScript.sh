#!/bin/bash

x-terminal-emulator -e "flatpak install --user -y --noninteractive flathub tv.kodi.Kodi"
#!/bin/bash 

x-terminal-emulator -e "flatpak install --user -y --noninteractive https://sober.vinegarhq.org/sober.flatpakref"
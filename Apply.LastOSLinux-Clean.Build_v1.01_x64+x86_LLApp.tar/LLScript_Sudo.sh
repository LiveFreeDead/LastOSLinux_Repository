#!/bin/bash

#Script that cleans the OS
bash 03_Clean_OS.sh

#Remove old Kernels
bash remove-old-kernels.sh exec

#Do this last to attempt to fix the Apt Cache issue
sudo apt update -y
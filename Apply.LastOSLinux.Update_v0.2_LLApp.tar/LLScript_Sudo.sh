#!/bin/bash

# Copy Update Overlay
sudo cp -rf ./OS_Overlay/. / 2> /dev/null

#Fix /LastOS Ownership (775 might be enough, but I'll go 777 until I know the bugs is fixed)
sudo chmod -R 777 "/LastOS/Tools" 2> /dev/null

sudo chown -R $(logname):$(logname) "/LastOS/Tools"
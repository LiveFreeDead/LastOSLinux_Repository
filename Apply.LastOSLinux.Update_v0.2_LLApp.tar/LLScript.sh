#!/bin/bash


cp -rf ./OS_Overlay/etc/skel/. $HOME/ 2> /dev/null
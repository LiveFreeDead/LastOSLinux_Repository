#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
    #hotkeys to system monitor
    # system monitor keybinding for (ctrl + shift + escape) and (ctrl + alt + delete)
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/command "'gnome-system-monitor'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/name "'System Monitor'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom0/binding "['<Primary><Shift>Escape', '<Primary><Alt>Delete']"
    dconf write /org/cinnamon/desktop/keybindings/media-keys/logout "['<Primary><Alt>o']"

    #ctrl break to close all wine stuff, wineserver -k
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/command "'quitwine.sh'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/name "'Kill WINE'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom1/binding "['<Primary>Break']"

    #Alt break to Fix display
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/command "'xrandr -s 0'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/name "'Fix Screen Res'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom2/binding "['<Alt>Break']"

    #ctrl shift f4 to close all wine stuff, wineserver -k
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/command "'quitwine.sh'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/name "'Kill WINE 2'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom3/binding "['<Primary><Shift>F4']"

    #Alt + = For Brightness Up
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3', 'custom4']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/command "'xdotool key --clearmodifiers XF86MonBrightnessUp'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/name "'Brightness Up'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom4/binding "['<Alt>equal']"

    #Alt + - For Brightness Down
    dconf write /org/cinnamon/desktop/keybindings/custom-list "['custom0', 'custom1', 'custom2', 'custom3', 'custom4', 'custom5']"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/command "'xdotool key --clearmodifiers XF86MonBrightnessDown'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/name "'Brightness Down'"
    dconf write /org/cinnamon/desktop/keybindings/custom-keybindings/custom5/binding "['<Alt>minus']"
        ;;

    gnome|ubuntu|ubuntu-xorg)
    # Custom keybindings via gsettings (GNOME schema)
    # Note: Ctrl+Alt+Delete is system-reserved in GNOME (power menu) so it is omitted here
    gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings \
      "['/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom2/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom3/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom4/']"

    # Ctrl+Shift+Escape → System Monitor
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/ name "System Monitor"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/ command "gnome-system-monitor"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/ binding "<Primary><Shift>Escape"

    # Ctrl+Break → Kill WINE
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ name "Kill WINE"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ command "quitwine.sh"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/ binding "<Primary>Break"

    # Alt+Break → Fix Screen Res
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom2/ name "Fix Screen Res"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom2/ command "xrandr -s 0"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom2/ binding "<Alt>Break"

    # Ctrl+Shift+F4 → Kill WINE 2
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom3/ name "Kill WINE 2"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom3/ command "quitwine.sh"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom3/ binding "<Primary><Shift>F4"

    # Alt+= → Brightness Up
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom4/ name "Brightness Up"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom4/ command "xdotool key --clearmodifiers XF86MonBrightnessUp"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom4/ binding "<Alt>equal"

    # Alt+- → Brightness Down (set via media-keys schema directly)
    gsettings set org.gnome.settings-daemon.plugins.media-keys decrease-text-size "[]"  # free up Alt+minus if bound
    gsettings set org.gnome.settings-daemon.plugins.media-keys custom-keybindings \
      "['/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom0/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom1/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom2/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom3/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom4/', \
        '/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom5/']"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom5/ name "Brightness Down"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom5/ command "xdotool key --clearmodifiers XF86MonBrightnessDown"
    gsettings set org.gnome.settings-daemon.plugins.media-keys.custom-keybinding:/org/gnome/settings-daemon/plugins/media-keys/custom-keybindings/custom5/ binding "<Alt>minus"
        ;;

    kde|KDE|plasma)
    # TODO: KDE shortcuts require kwriteconfig5/6 + restarting kglobalaccel and are
    # version-dependent (Plasma 5 vs 6). Add manually via System Settings > Shortcuts for now.
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    # Ctrl+Shift+Escape + Ctrl+Alt+Delete → System Monitor
    dconf write /org/mate/desktop/keybindings/custom0/action "'mate-system-monitor'"
    dconf write /org/mate/desktop/keybindings/custom0/name "'System Monitor'"
    dconf write /org/mate/desktop/keybindings/custom0/binding "'<Primary><Shift>Escape'"

    dconf write /org/mate/desktop/keybindings/custom1/action "'mate-system-monitor'"
    dconf write /org/mate/desktop/keybindings/custom1/name "'System Monitor (CAD)'"
    dconf write /org/mate/desktop/keybindings/custom1/binding "'<Primary><Alt>Delete'"

    # Ctrl+Break → Kill WINE
    dconf write /org/mate/desktop/keybindings/custom2/action "'quitwine.sh'"
    dconf write /org/mate/desktop/keybindings/custom2/name "'Kill WINE'"
    dconf write /org/mate/desktop/keybindings/custom2/binding "'<Primary>Break'"

    # Alt+Break → Fix Screen Res
    dconf write /org/mate/desktop/keybindings/custom3/action "'xrandr -s 0'"
    dconf write /org/mate/desktop/keybindings/custom3/name "'Fix Screen Res'"
    dconf write /org/mate/desktop/keybindings/custom3/binding "'<Alt>Break'"

    # Ctrl+Shift+F4 → Kill WINE 2
    dconf write /org/mate/desktop/keybindings/custom4/action "'quitwine.sh'"
    dconf write /org/mate/desktop/keybindings/custom4/name "'Kill WINE 2'"
    dconf write /org/mate/desktop/keybindings/custom4/binding "'<Primary><Shift>F4'"

    # Alt+= → Brightness Up
    dconf write /org/mate/desktop/keybindings/custom5/action "'xdotool key --clearmodifiers XF86MonBrightnessUp'"
    dconf write /org/mate/desktop/keybindings/custom5/name "'Brightness Up'"
    dconf write /org/mate/desktop/keybindings/custom5/binding "'<Alt>equal'"

    # Alt+- → Brightness Down
    dconf write /org/mate/desktop/keybindings/custom6/action "'xdotool key --clearmodifiers XF86MonBrightnessDown'"
    dconf write /org/mate/desktop/keybindings/custom6/name "'Brightness Down'"
    dconf write /org/mate/desktop/keybindings/custom6/binding "'<Alt>minus'"

    # Ctrl+Alt+O → Logout
    gsettings set org.mate.desktop.keybindings logout '<Primary><Alt>o'
        ;;

    unity)
        ;;

    xfce)
    # Ctrl+Shift+Escape → System Monitor
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Primary><Shift>Escape" -n -t string -s "xfce4-taskmanager"

    # Ctrl+Alt+Delete → System Monitor
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Primary><Alt>Delete" -n -t string -s "xfce4-taskmanager"

    # Ctrl+Break → Kill WINE
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Primary>Break" -n -t string -s "quitwine.sh"

    # Alt+Break → Fix Screen Res
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Alt>Break" -n -t string -s "xrandr -s 0"

    # Ctrl+Shift+F4 → Kill WINE 2
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Primary><Shift>F4" -n -t string -s "quitwine.sh"

    # Alt+= → Brightness Up
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Alt>equal" -n -t string -s "xdotool key --clearmodifiers XF86MonBrightnessUp"

    # Alt+- → Brightness Down
    xfconf-query -c xfce4-keyboard-shortcuts -p "/commands/custom/<Alt>minus" -n -t string -s "xdotool key --clearmodifiers XF86MonBrightnessDown"
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

exit 0
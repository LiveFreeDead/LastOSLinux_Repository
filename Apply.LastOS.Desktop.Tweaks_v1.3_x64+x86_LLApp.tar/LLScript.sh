#!/bin/bash

#Do tasks for each Desktop Environment
case $XDG_SESSION_DESKTOP in

  cinnamon)
     #Set No effects (Feels faster)
    gsettings set org.cinnamon desktop-effects false

    #Set Clock to 12H not 24H
    gsettings set org.cinnamon.desktop.interface clock-use-24h false

    ##Desktop Icon Grid Size
    gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002

    #Desktop Icons
    gsettings set org.nemo.desktop computer-icon-visible true
    gsettings set org.nemo.desktop trash-icon-visible true

    #Disable USB and Mounts from Desktop
    gsettings set org.nemo.desktop volumes-visible false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Lock when Screensaver
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false

    #Enable Trackpad Gestures
    gsettings set org.cinnamon.gestures enabled true

    #Show icons in Menus
    dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"

    #Configure Xed to be better
    gsettings set org.x.editor.preferences.editor display-line-numbers true
    gsettings set org.x.editor.preferences.editor bracket-matching false
    #gsettings set org.x.editor.preferences.editor scheme 'classic' (Classic Theme has White Line Number bar, looks bad)
    gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"

    #Configure Nemo to have better Windowsy defaults
    gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    #gsettings set org.nemo.preferences inherit-folder-viewer true #Not Needed when default view is set
    gsettings set org.nemo.preferences show-full-path-titles true

    #Get thumbnails for images up to 4gb, should cover most movies etc too.
    gsettings set org.nemo.preferences thumbnail-limit 4294967295

    #Nemo Toolbar Icons
    gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    gsettings set org.nemo.preferences show-computer-icon-toolbar true

    #Sound FX
    gsettings set org.cinnamon.sounds login-enabled false
    gsettings set org.cinnamon.sounds logout-enabled false
    gsettings set org.cinnamon.sounds notification-enabled false
    #gsettings set org.cinnamon.desktop.sound volume-sound-enabled true
    #gsettings set org.cinnamon.desktop.sound volume-sound-file "/usr/share/sounds/freedesktop/stereo/audio-volume-change.oga"

    #Close Network on Nemo Sidebar (Opened by default)
    gsettings set org.nemo.window-state network-expanded false

    #Change default Time on lock screen to have date
    #Lock Screen Formatting
    gsettings set org.cinnamon.desktop.screensaver use-custom-format true
    gsettings set org.cinnamon.desktop.screensaver time-format "%l:%M %p"
    gsettings set org.cinnamon.desktop.screensaver date-format "            %A, %b %d"

    #Disable Screen Lock and Resume With Lock
    gsettings set org.cinnamon.settings-daemon.plugins.power lock-on-suspend false
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    gsettings set org.cinnamon.desktop.screensaver lock-delay 0

    #Screen Sleep after 15 Minutes
    gsettings set org.cinnamon.desktop.session idle-delay 900



    #Show hover tooltips on files/folders (Not everyone will want this, I should make a Settings choices app)
    gsettings set org.nemo.preferences tooltips-show-file-type true
    gsettings set org.nemo.preferences tooltips-show-path true
    gsettings set org.nemo.preferences tooltips-in-icon-view true
    gsettings set org.nemo.preferences tooltips-on-desktop true
    ;;

  gnome|ubuntu)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate)
    #Desktop Icons
    gsettings set org.mate.caja.desktop computer-icon-visible true
    gsettings set org.mate.caja.desktop trash-icon-visible true

    #Sleep timers
    #gsettings set org.mate.power-manager sleep-computer-ac 1800
    gsettings set org.mate.power-manager sleep-display-ac 1200

    #gsettings set org.mate.power-manager sleep-computer-battery 180
    gsettings set org.mate.power-manager sleep-display-battery 120

    #Screensaver
    gsettings set org.mate.session idle-delay 20
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  *)
    echo "This is an unknown desktop environment."
    ;;
esac
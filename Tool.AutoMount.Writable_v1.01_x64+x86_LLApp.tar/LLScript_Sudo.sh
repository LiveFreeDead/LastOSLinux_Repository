#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

# Set to true to reinstall packages even if already installed (useful for fixing broken installs)
FORCE_REINSTALL=false

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2


echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# ---- Real user identity (script runs as root via sudo) ----
REAL_USER="${SUDO_USER:-$USER}"
REAL_UID=$(id -u "$REAL_USER")
REAL_GID=$(id -g "$REAL_USER")
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
echo "[*] Real user: $REAL_USER  (uid=$REAL_UID  gid=$REAL_GID)"

# ---- Detect KDE version (check as the real user) ----
KDE_VER=0; KWRITECONFIG=""; KDED_RC=""
if sudo -u "$REAL_USER" command -v kwriteconfig6 >/dev/null 2>&1; then
    KDE_VER=6; KWRITECONFIG="kwriteconfig6"; KDED_RC="kded6rc"
    echo "[+] KDE 6 detected"
elif sudo -u "$REAL_USER" command -v kwriteconfig5 >/dev/null 2>&1; then
    KDE_VER=5; KWRITECONFIG="kwriteconfig5"; KDED_RC="kded5rc"
    echo "[+] KDE 5 detected"
else
    echo "[!] WARNING: kwriteconfig not found — KDE config will be skipped"
fi

# ---- Detect admin group ----
ADMIN_GROUP="wheel"
for grp in wheel sudo admin; do
    if id -nG "$REAL_USER" | grep -qw "$grp"; then
        ADMIN_GROUP="$grp"; break
    fi
done
echo "[+] Admin group: $ADMIN_GROUP"

# ---- Install required packages ----
inst ntfsprogs exfatprogs udiskie
UDISKIE_BIN=$(command -v udiskie || echo "")

# ---- Polkit rule ----
mkdir -p /etc/polkit-1/rules.d
cat <<EOF > /etc/polkit-1/rules.d/10-udisks2-automount.rules
// KDE USB Automount Fix — LLStore
polkit.addRule(function(action, subject) {
    if ((action.id == "org.freedesktop.udisks2.filesystem-mount" ||
         action.id == "org.freedesktop.udisks2.filesystem-mount-system") &&
        subject.isInGroup("$ADMIN_GROUP")) {
        return polkit.Result.YES;
    }
});
EOF
echo "[+] Polkit rule written"

# ---- udisks2 mount options ----
HAS_NTFS3=0
grep -qw ntfs3 /proc/filesystems 2>/dev/null && HAS_NTFS3=1
mkdir -p /etc/udisks2
{
    echo "[defaults]"
    if [[ $HAS_NTFS3 -eq 1 ]]; then
        echo "ntfs3_defaults=uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000,windows_names"
        echo "ntfs3_allow=uid,gid,umask,windows_names,exec,ro,rw,noatime"
    fi
    echo "ntfs-3g_defaults=uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000"
    echo "ntfs-3g_allow=uid,gid,umask,exec,ro,rw,noatime"
    echo "ntfs_defaults=uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000"
    echo "ntfs_allow=uid,gid,umask,exec,ro,rw,noatime"
    echo "exfat_defaults=uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000"
    echo "exfat_allow=uid,gid,umask,exec,ro,rw,noatime"
    echo "vfat_defaults=uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000"
    echo "vfat_allow=uid,gid,umask,exec,ro,rw,noatime,flush"
} > /etc/udisks2/mount_options.conf
echo "[+] mount_options.conf written"

# ---- Restart services ----
systemctl restart polkit  2>/dev/null || echo "[!] Could not restart polkit"
systemctl restart udisks2 2>/dev/null || echo "[!] Could not restart udisks2"

# ---- Clear NTFS dirty flags ----
if command -v ntfsfix >/dev/null 2>&1; then
    while IFS= read -r devname; do
        echo -n "    Cleaning /dev/$devname ... "
        ntfsfix -d "/dev/$devname" >/dev/null 2>&1 && echo "OK" || echo "Skipped"
    done < <(lsblk -f -n -r -o NAME,FSTYPE | awk '$2 ~ /^(ntfs|ntfs3|fuseblk)$/ {print $1}')
fi

# ---- Mount currently attached unmounted drives ----
declare -A ACTIVE_DEVS
while IFS= read -r active; do
    active="${active%%[*}"; active="${active##*/}"
    [[ -n "$active" ]] && ACTIVE_DEVS["$active"]=1
done < <(findmnt -n -o SOURCE 2>/dev/null)

while IFS= read -r line; do
    DEV_NAME=$(echo "$line" | awk '{print $1}')
    FSTYPE=$(   echo "$line" | awk '{print $2}')
    MOUNTPT=$(  echo "$line" | awk '{print $3}')
    [[ -n "$MOUNTPT" || "$FSTYPE" == "swap" || -z "$FSTYPE" ]] && continue
    [[ -n "${ACTIVE_DEVS[$DEV_NAME]}" ]] && continue
    case "$FSTYPE" in
        ntfs3)        MNT_OPTS="uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000,windows_names" ;;
        ntfs|fuseblk) MNT_OPTS="uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000"; FSTYPE="ntfs-3g" ;;
        exfat|vfat)   MNT_OPTS="uid=$REAL_UID,gid=$REAL_GID,rw,exec,umask=000" ;;
        *)            MNT_OPTS="rw" ;;
    esac
    LABEL=$(lsblk -no LABEL "/dev/$DEV_NAME" 2>/dev/null | head -1)
    [[ -z "$LABEL" ]] && LABEL="$DEV_NAME"
    MP="/run/media/$REAL_USER/$LABEL"
    mkdir -p "$MP"
    if mount -t "$FSTYPE" -o "$MNT_OPTS" "/dev/$DEV_NAME" "$MP" 2>/dev/null; then
        chown "$REAL_UID:$REAL_GID" "$MP"
        echo "    [+] /dev/$DEV_NAME ($FSTYPE) → $MP"
    else
        rmdir "$MP" 2>/dev/null
    fi
done < <(lsblk -n -r -o NAME,FSTYPE,MOUNTPOINT | grep -v '^loop')

# ---- Write handoff file for LLScript.sh ----
HANDOFF="/tmp/llstore_automount_handoff"
cat <<EOF > "$HANDOFF"
KDE_VER=$KDE_VER
KWRITECONFIG="$KWRITECONFIG"
KDED_RC="$KDED_RC"
UDISKIE_BIN="$UDISKIE_BIN"
EOF
chmod 644 "$HANDOFF"
echo "[*] Handoff data written for user-phase script"

exit 0
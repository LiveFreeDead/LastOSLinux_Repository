#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

# (Add any variables your script needs here before the core loads)

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
        ;;

    gnome|ubuntu|ubuntu-xorg)
        ;;

    kde|KDE|plasma)
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
        ;;

    unity)
        ;;

    xfce)
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

# ---- Read handoff data from sudo phase ----
HANDOFF="/tmp/llstore_automount_handoff"
if [ -f "$HANDOFF" ]; then
    # shellcheck source=/dev/null
    source "$HANDOFF"
    rm -f "$HANDOFF"
else
    echo "[!] Handoff file not found — KDE config and autostart skipped"
fi

# ---- KDE automount configuration ----
if [ -n "$KWRITECONFIG" ] && command -v "$KWRITECONFIG" >/dev/null 2>&1; then
    "$KWRITECONFIG" --file "$KDED_RC" \
        --group "Module-device_automounter" --key "autoload" "true"
    "$KWRITECONFIG" --file kded_device_automounterrc \
        --group "General" --key "AutomountOnLogin"        "true"
    "$KWRITECONFIG" --file kded_device_automounterrc \
        --group "General" --key "AutomountOnPlugin"       "true"
    "$KWRITECONFIG" --file kded_device_automounterrc \
        --group "General" --key "AutomountUnknownDevices" "true"
    "$KWRITECONFIG" --file kded_device_automounterrc \
        --group "General" --key "Enabled"                 "true"
    echo "[+] KDE automount settings applied"
fi

# ---- udiskie XDG autostart + systemd user service ----
if [ -n "$UDISKIE_BIN" ]; then
    mkdir -p "$HOME/.config/autostart"
    cat <<EOF > "$HOME/.config/autostart/udiskie.desktop"
[Desktop Entry]
Type=Application
Name=udiskie
Comment=Automount removable drives
Exec=$UDISKIE_BIN --no-tray --no-notify --automount
Icon=drive-removable-media
Categories=System;
X-KDE-autostart-phase=2
StartupNotify=false
EOF
    echo "[+] XDG autostart entry written"

    mkdir -p "$HOME/.config/systemd/user"
    cat <<EOF > "$HOME/.config/systemd/user/udiskie.service"
[Unit]
Description=udiskie automount daemon
After=graphical-session.target

[Service]
ExecStart=$UDISKIE_BIN --no-tray --no-notify --automount
Restart=on-failure
RestartSec=5

[Install]
WantedBy=graphical-session.target
EOF
    systemctl --user daemon-reload
    systemctl --user enable udiskie 2>/dev/null
    systemctl --user restart udiskie 2>/dev/null \
        && echo "[+] udiskie service enabled and started" \
        || echo "[!] udiskie could not start now (XDG autostart will catch it on next login)"
fi

exit 0
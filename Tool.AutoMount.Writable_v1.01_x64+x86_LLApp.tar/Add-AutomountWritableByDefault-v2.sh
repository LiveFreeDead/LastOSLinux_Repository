#!/bin/bash

# ==============================================================================
#  KDE USB Automount Fix  (Universal Edition)
#  Tested on: KDE 5 & 6, Arch, CachyOS, Manjaro, Kubuntu, KDE Neon,
#             openSUSE, Fedora KDE, Linux Mint (EDGE/KDE spin)
#
#  What it does:
#    - Detects KDE version and uses the correct config tools/paths
#    - Detects which admin group your distro uses (wheel / sudo / admin)
#    - Installs missing tools (ntfsprogs, exfatprogs, udiskie) via your package manager
#    - Writes Polkit + udisks2 rules for passwordless writable mounts
#      covering: NTFS, exFAT, FAT32/vFAT, and any other removable filesystem
#    - Installs udiskie via XDG autostart (primary) + systemd user service (fallback)
#    - Configures the KDE automounter as an additional fallback
#    - Mounts all currently attached unmounted drives immediately
#    - Clears NTFS dirty flags on any currently connected NTFS drives
# ==============================================================================

# ------------------------------------------------------------------------------
# 1. Relauncher — open an interactive terminal if run from a file manager
# ------------------------------------------------------------------------------
if [[ ! -t 0 ]]; then
    for term in kitty konsole alacritty foot wezterm tilix xterm; do
        if command -v "$term" >/dev/null 2>&1; then
            case "$term" in
                gnome-terminal|tilix) exec "$term" -- "$0" "$@" ;;
                *)                    exec "$term" -e "$0" "$@" ;;
            esac
        fi
    done
    echo "WARNING: No graphical terminal found. Continuing in current shell."
fi

# Capture real user identity BEFORE any sudo calls alter the environment
USER_ID=$(id -u)
GROUP_ID=$(id -g)
USER_NAME=$(id -un)

# ------------------------------------------------------------------------------
# Helper functions
# ------------------------------------------------------------------------------
info()    { echo "[*] $*"; }
success() { echo "[+] $*"; }
warn()    { echo "[!] WARNING: $*"; }
die()     { echo "[X] ERROR: $*"; exit 1; }

# ------------------------------------------------------------------------------
# 2. Banner
# ------------------------------------------------------------------------------
echo ""
echo "=============================================="
echo "  KDE USB Automount Fix  (Universal)          "
echo "=============================================="
echo "  User  : $USER_NAME  (uid=$USER_ID  gid=$GROUP_ID)"
echo ""

# ------------------------------------------------------------------------------
# 3. Detect KDE version
# ------------------------------------------------------------------------------
info "Detecting KDE version..."
if command -v kwriteconfig6 >/dev/null 2>&1; then
    KDE_VER=6
    KWRITECONFIG="kwriteconfig6"
    KDED_RC="kded6rc"
    KDED_BUS="org.kde.kded6"
    KDED_OBJ="/kded6"
    if   command -v qdbus6 >/dev/null 2>&1; then QDBUS="qdbus6"
    elif command -v qdbus  >/dev/null 2>&1; then QDBUS="qdbus"
    else                                          QDBUS=""
    fi
elif command -v kwriteconfig5 >/dev/null 2>&1; then
    KDE_VER=5
    KWRITECONFIG="kwriteconfig5"
    KDED_RC="kded5rc"
    KDED_BUS="org.kde.kded5"
    KDED_OBJ="/kded5"
    QDBUS=$(command -v qdbus 2>/dev/null || echo "")
else
    die "Neither kwriteconfig5 nor kwriteconfig6 found. Is KDE Plasma installed?"
fi
success "KDE $KDE_VER detected  (using $KWRITECONFIG, config: $KDED_RC)"

# ------------------------------------------------------------------------------
# 4. Detect admin group
# ------------------------------------------------------------------------------
info "Detecting admin group..."
ADMIN_GROUP=""
for grp in wheel sudo admin; do
    if id -nG "$USER_NAME" | grep -qw "$grp"; then
        ADMIN_GROUP="$grp"
        break
    fi
done
if [[ -z "$ADMIN_GROUP" ]]; then
    warn "User is not in wheel, sudo, or admin groups."
    warn "Polkit rule will be written for 'wheel' but may not apply to this user."
    ADMIN_GROUP="wheel"
else
    success "Admin group: $ADMIN_GROUP"
fi

# ------------------------------------------------------------------------------
# 5. Elevate privileges
# ------------------------------------------------------------------------------
if [ "$EUID" -ne 0 ]; then
    info "Requesting elevated privileges for system changes..."
    sudo -v || die "Could not obtain sudo. Aborting."
fi

# ------------------------------------------------------------------------------
# 6. Detect package manager
# ------------------------------------------------------------------------------
PM=""
if   command -v pacman       >/dev/null 2>&1; then PM="pacman"
elif command -v apt-get      >/dev/null 2>&1; then PM="apt"
elif command -v dnf          >/dev/null 2>&1; then PM="dnf"
elif command -v zypper       >/dev/null 2>&1; then PM="zypper"
elif command -v xbps-install >/dev/null 2>&1; then PM="xbps"
fi

# ------------------------------------------------------------------------------
# Helper: auto-install a package if a command is missing
#   Usage: ensure_tool <command> <pacman_pkg> <apt_pkg> <dnf_pkg> <zypper_pkg> <xbps_pkg>
# ------------------------------------------------------------------------------
ensure_tool() {
    local CMD="$1" PKG_PACMAN="$2" PKG_APT="$3" PKG_DNF="$4" PKG_ZYPPER="$5" PKG_XBPS="$6"
    if command -v "$CMD" >/dev/null 2>&1; then
        success "$CMD found."
        return 0
    fi
    warn "$CMD not found."
    if [[ -z "$PM" ]]; then
        warn "Could not detect package manager. Install the package providing '$CMD' manually."
        return 1
    fi
    local PKG
    case "$PM" in
        pacman) PKG="$PKG_PACMAN" ;;
        apt)    PKG="$PKG_APT"    ;;
        dnf)    PKG="$PKG_DNF"    ;;
        zypper) PKG="$PKG_ZYPPER" ;;
        xbps)   PKG="$PKG_XBPS"  ;;
    esac
    info "Installing '$PKG' using $PM..."
    case "$PM" in
        pacman) sudo pacman -S --noconfirm "$PKG" ;;
        apt)    sudo apt-get install -y "$PKG"    ;;
        dnf)    sudo dnf install -y "$PKG"        ;;
        zypper) sudo zypper install -y "$PKG"     ;;
        xbps)   sudo xbps-install -y "$PKG"       ;;
    esac
    command -v "$CMD" >/dev/null 2>&1 && return 0
    return 1
}

# ------------------------------------------------------------------------------
# 7. Check / install required filesystem tools
#
#  exFAT command names by distro:
#    Arch/CachyOS, Debian, Ubuntu (exfatprogs >= 1.1): fsck.exfat
#    Old exfat-utils (obsolete): exfatfsck  — not checked, no longer relevant
# ------------------------------------------------------------------------------
info "Checking filesystem tools..."

ensure_tool ntfsfix    ntfsprogs  ntfsprogs  ntfsprogs  ntfsprogs  ntfsprogs
HAVE_NTFSFIX=$(command -v ntfsfix    >/dev/null 2>&1 && echo 1 || echo 0)

ensure_tool fsck.exfat exfatprogs exfatprogs exfatprogs exfatprogs exfatprogs
HAVE_EXFAT=$(command -v fsck.exfat  >/dev/null 2>&1 && echo 1 || echo 0)

ensure_tool udiskie    udiskie    udiskie    udiskie    udiskie    udiskie
HAVE_UDISKIE=$(command -v udiskie   >/dev/null 2>&1 && echo 1 || echo 0)

# ------------------------------------------------------------------------------
# 8. Detect in-kernel ntfs3 driver
# ------------------------------------------------------------------------------
info "Detecting NTFS driver availability..."
HAS_NTFS3=0
if grep -qw ntfs3 /proc/filesystems 2>/dev/null || \
   modprobe --dry-run ntfs3 >/dev/null 2>&1; then
    HAS_NTFS3=1
    success "In-kernel ntfs3 driver available."
else
    success "ntfs3 not available — ntfs-3g (FUSE) will be used."
fi

# ------------------------------------------------------------------------------
# 9. Polkit rule — passwordless mount for ALL removable filesystems
# ------------------------------------------------------------------------------
info "Writing Polkit rule for group '$ADMIN_GROUP'..."
sudo mkdir -p /etc/polkit-1/rules.d
cat <<EOF | sudo tee /etc/polkit-1/rules.d/10-udisks2-automount.rules > /dev/null
// KDE USB Automount Fix
// Allows members of '$ADMIN_GROUP' to mount ANY removable filesystem
// without a password prompt.
polkit.addRule(function(action, subject) {
    if ((action.id == "org.freedesktop.udisks2.filesystem-mount" ||
         action.id == "org.freedesktop.udisks2.filesystem-mount-system") &&
        subject.isInGroup("$ADMIN_GROUP")) {
        return polkit.Result.YES;
    }
});
EOF
success "Polkit rule written."

# ------------------------------------------------------------------------------
# 10. udisks2 mount options
#
#  Each filesystem needs TWO entries:
#
#  _defaults  — options udisks2 applies automatically on every mount.
#               Sets uid/gid ownership and rw access.
#
#  _allow     — options udisks2 will PERMIT being passed at all.
#               Without this, udisks2 rejects uid/gid even from _defaults
#               with "Mount option 'uid=X' is not allowed".
#               This is the key fix for the OptionNotPermitted error.
#
#  Filesystems covered:
#    ntfs3     — in-kernel driver (kernel 5.15+); supports windows_names
#    ntfs-3g   — FUSE driver; no windows_names
#    ntfs      — legacy fallback key for older udisks2
#    exfat     — in-kernel driver (kernel 5.7+)
#    vfat      — FAT32/FAT16
# ------------------------------------------------------------------------------
info "Writing udisks2 mount options (/etc/udisks2/mount_options.conf)..."
sudo mkdir -p /etc/udisks2

if [[ $HAS_NTFS3 -eq 1 ]]; then
    NTFS3_DEFAULTS="ntfs3_defaults=uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000,windows_names"
    NTFS3_ALLOW="ntfs3_allow=uid,gid,umask,windows_names,exec,ro,rw,noatime"
else
    NTFS3_DEFAULTS="# ntfs3 not available on this kernel — lines omitted"
    NTFS3_ALLOW=""
fi

cat <<EOF | sudo tee /etc/udisks2/mount_options.conf > /dev/null
[defaults]
$NTFS3_DEFAULTS
$NTFS3_ALLOW
ntfs-3g_defaults=uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000
ntfs-3g_allow=uid,gid,umask,exec,ro,rw,noatime
ntfs_defaults=uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000
ntfs_allow=uid,gid,umask,exec,ro,rw,noatime
exfat_defaults=uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000
exfat_allow=uid,gid,umask,exec,ro,rw,noatime
vfat_defaults=uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000
vfat_allow=uid,gid,umask,exec,ro,rw,noatime,flush
EOF
success "mount_options.conf written  (NTFS, exFAT, FAT32 covered)."

# ------------------------------------------------------------------------------
# 11. Restart system services
# ------------------------------------------------------------------------------
info "Restarting polkit and udisks2..."
sudo systemctl restart polkit  2>/dev/null || warn "Could not restart polkit"
sudo systemctl restart udisks2 2>/dev/null || warn "Could not restart udisks2"

# ------------------------------------------------------------------------------
# 12. udiskie — XDG autostart (primary) + systemd user service (fallback)
#
#  XDG autostart is the reliable method on KDE — the session manager reads
#  ~/.config/autostart/ directly and launches entries at startup phase 2,
#  without depending on systemd user target ordering.
#
#  The systemd service is kept as a fallback for non-KDE sessions.
# ------------------------------------------------------------------------------
if [[ $HAVE_UDISKIE -eq 1 ]]; then
    UDISKIE_BIN=$(command -v udiskie)

    # -- a) XDG autostart (primary — KDE always runs this) --
    info "Installing udiskie XDG autostart entry..."
    mkdir -p "$HOME/.config/autostart"
    cat <<EOF > "$HOME/.config/autostart/udiskie.desktop"
[Desktop Entry]
Type=Application
Name=udiskie
Comment=Automount removable drives
Exec=$UDISKIE_BIN --no-tray --no-notify --automount
Icon=drive-removable-media
Categories=System;
X-KDE-autostart-phase=2
StartupNotify=false
EOF
    success "XDG autostart written → ~/.config/autostart/udiskie.desktop"

    # -- b) systemd user service (fallback) --
    info "Installing udiskie systemd user service..."
    mkdir -p "$HOME/.config/systemd/user"
    cat <<EOF > "$HOME/.config/systemd/user/udiskie.service"
[Unit]
Description=udiskie automount daemon
Documentation=man:udiskie(8)
After=graphical-session.target

[Service]
ExecStart=$UDISKIE_BIN --no-tray --no-notify --automount
Restart=on-failure
RestartSec=5

[Install]
WantedBy=graphical-session.target
EOF
    systemctl --user daemon-reload
    systemctl --user enable udiskie 2>/dev/null
    systemctl --user restart udiskie 2>/dev/null \
        && success "udiskie service enabled and started." \
        || warn "udiskie could not start right now (XDG autostart will catch it on next login)."
else
    warn "udiskie not installed — falling back to KDE automounter only."
fi

# ------------------------------------------------------------------------------
# 13. KDE automount configuration (additional fallback)
# ------------------------------------------------------------------------------
info "Configuring KDE $KDE_VER automounter ($KDED_RC) as fallback..."
"$KWRITECONFIG" --file "$KDED_RC" \
    --group "Module-device_automounter" --key "autoload" "true"
"$KWRITECONFIG" --file kded_device_automounterrc \
    --group "General" --key "AutomountOnLogin"        "true"
"$KWRITECONFIG" --file kded_device_automounterrc \
    --group "General" --key "AutomountOnPlugin"       "true"
"$KWRITECONFIG" --file kded_device_automounterrc \
    --group "General" --key "AutomountUnknownDevices" "true"
"$KWRITECONFIG" --file kded_device_automounterrc \
    --group "General" --key "Enabled"                 "true"
success "KDE automount settings applied."

if [[ -n "$QDBUS" ]]; then
    "$QDBUS" "$KDED_BUS" "$KDED_OBJ" unloadModule device_automounter > /dev/null 2>&1
    sleep 1
    "$QDBUS" "$KDED_BUS" "$KDED_OBJ" loadModule  device_automounter > /dev/null 2>&1
    success "KDE automounter module reloaded."
fi

# ------------------------------------------------------------------------------
# 14. Clear NTFS dirty flags on currently connected drives
# ------------------------------------------------------------------------------
if [[ $HAVE_NTFSFIX -eq 1 ]]; then
    info "Scanning for NTFS volumes to clear dirty flags..."
    mapfile -t NTFS_DRIVES < <(lsblk -f -n -r -o NAME,FSTYPE \
        | awk '$2 ~ /^(ntfs|ntfs3|fuseblk)$/ {print $1}')
    if [[ ${#NTFS_DRIVES[@]} -eq 0 ]]; then
        info "No NTFS volumes currently attached."
    else
        for DEV_NAME in "${NTFS_DRIVES[@]}"; do
            DEV_PATH="/dev/$DEV_NAME"
            echo -n "    Cleaning $DEV_PATH ... "
            sudo ntfsfix -d "$DEV_PATH" > /dev/null 2>&1 && echo "OK" || echo "Skipped"
        done
    fi
else
    warn "ntfsfix not available — skipping NTFS dirty flag clearing."
fi

# ------------------------------------------------------------------------------
# 15. Mount all currently attached unmounted drives right now
#
#  Uses 'sudo mount' with explicit options rather than udisksctl, because
#  udisksctl validates options against its allowlist at call time even when
#  the same options are present in mount_options.conf — causing the
#  "OptionNotPermitted" error seen with ntfs3 drives.
#  Ownership is set correctly via the uid/gid options passed directly.
#  Skips: already-mounted, swap, loop devices, and partitions that are
#  actively in use by the system (mounted as /, /boot, /efi, /home etc).
#  Does NOT skip an entire disk just because / lives on it — this allows
#  NTFS/data partitions on the same NVMe as Linux to be mounted correctly.
# ------------------------------------------------------------------------------
info "Mounting all currently attached unmounted drives..."

MOUNTED_COUNT=0
SKIPPED_COUNT=0
MOUNT_PIDS=()

# Build a set of block device names that are currently mounted anywhere.
# These are the only partitions we must not touch — not the whole parent disk.
declare -A ACTIVE_DEVS
while IFS= read -r active; do
    # findmnt SOURCE can include brackets e.g. /dev/sda1[/subvol] — strip suffix
    active="${active%%[*}"
    active="${active##*/}"
    [[ -n "$active" ]] && ACTIVE_DEVS["$active"]=1
done < <(findmnt -n -o SOURCE 2>/dev/null)

while IFS= read -r line; do
    DEV_NAME=$(  echo "$line" | awk '{print $1}')
    FSTYPE=$(    echo "$line" | awk '{print $2}')
    MOUNTPOINT=$(echo "$line" | awk '{print $3}')
    DEV_PATH="/dev/$DEV_NAME"

    [[ -n "$MOUNTPOINT" ]]    && { (( SKIPPED_COUNT++ )); continue; }
    [[ "$FSTYPE" == "swap" ]] && continue
    [[ -z "$FSTYPE" ]]        && continue

    # Skip only partitions that are actively mounted — not the whole parent disk
    [[ -n "${ACTIVE_DEVS[$DEV_NAME]}" ]] && { (( SKIPPED_COUNT++ )); continue; }

    # Build mount options appropriate for this filesystem type
    case "$FSTYPE" in
        ntfs3)
            MNT_OPTS="uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000,windows_names"
            ;;
        ntfs|fuseblk)
            MNT_OPTS="uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000"
            FSTYPE="ntfs-3g"
            ;;
        exfat|vfat)
            MNT_OPTS="uid=$USER_ID,gid=$GROUP_ID,rw,exec,umask=000"
            ;;
        *)
            # ext4, btrfs, xfs, f2fs etc — mount without ownership options
            MNT_OPTS="rw"
            ;;
    esac

    # Create a mount point under /run/media/$USER_NAME/
    LABEL=$(lsblk -no LABEL "$DEV_PATH" 2>/dev/null | head -1)
    [[ -z "$LABEL" ]] && LABEL="$DEV_NAME"
    MOUNT_POINT="/run/media/$USER_NAME/$LABEL"
    sudo mkdir -p "$MOUNT_POINT"

    # Launch mount in background — all drives mount in parallel
    (
        if sudo mount -t "$FSTYPE" -o "$MNT_OPTS" "$DEV_PATH" "$MOUNT_POINT" 2>/dev/null; then
            sudo chown "$USER_ID:$GROUP_ID" "$MOUNT_POINT"
            echo "    [+] $DEV_PATH ($FSTYPE) → $MOUNT_POINT"
        else
            sudo rmdir "$MOUNT_POINT" 2>/dev/null
            echo "    [-] $DEV_PATH ($FSTYPE) skipped"
        fi
    ) &
    MOUNT_PIDS+=($!)
done < <(lsblk -n -r -o NAME,FSTYPE,MOUNTPOINT | grep -v '^loop')

# Wait for all parallel mounts to complete
if [[ ${#MOUNT_PIDS[@]} -gt 0 ]]; then
    info "Waiting for ${#MOUNT_PIDS[@]} mount job(s) to complete..."
    for pid in "${MOUNT_PIDS[@]}"; do
        wait "$pid" && (( MOUNTED_COUNT++ )) || (( SKIPPED_COUNT++ ))
    done
fi

if [[ $MOUNTED_COUNT -gt 0 ]]; then
    success "$MOUNTED_COUNT drive(s) mounted successfully."
elif [[ $SKIPPED_COUNT -gt 0 ]]; then
    info "All detected drives were already mounted."
else
    info "No unmounted drives found right now."
fi

# ------------------------------------------------------------------------------
# Done
# ------------------------------------------------------------------------------
echo ""
echo "=============================================="
echo "  COMPLETE"
echo "=============================================="
echo ""
echo "  ALL removable drives will now:"
echo "    - Mount automatically on login     (via udiskie XDG autostart)"
echo "    - Mount automatically when plugged in  (via udiskie)"
echo "    - Be writable without a password prompt"
echo "    - Be owned by: $USER_NAME (uid=$USER_ID)"
echo ""
echo "  Filesystems covered:"
echo "    NTFS, exFAT, FAT32/vFAT, ext4, btrfs, xfs, f2fs, ..."
echo ""
if [[ $HAS_NTFS3 -eq 0 ]]; then
    echo "  NOTE: In-kernel ntfs3 driver not found."
    echo "  If NTFS drives remain read-only, ensure ntfs-3g is installed:"
    case "$PM" in
        pacman) echo "    sudo pacman -S ntfs-3g" ;;
        apt)    echo "    sudo apt install ntfs-3g" ;;
        dnf)    echo "    sudo dnf install ntfs-3g" ;;
        zypper) echo "    sudo zypper install ntfs-3g" ;;
        *)      echo "    (use your distro's package manager)" ;;
    esac
    echo ""
fi
if [[ $HAVE_EXFAT -eq 0 ]]; then
    echo "  NOTE: exfatprogs not installed — exFAT drives may not mount."
    case "$PM" in
        pacman) echo "    sudo pacman -S exfatprogs" ;;
        apt)    echo "    sudo apt install exfatprogs" ;;
        dnf)    echo "    sudo dnf install exfatprogs" ;;
        zypper) echo "    sudo zypper install exfatprogs" ;;
        *)      echo "    (use your distro's package manager)" ;;
    esac
    echo ""
fi
echo "=============================================="

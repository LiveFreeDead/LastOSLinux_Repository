#!/bin/bash

dconf watch /
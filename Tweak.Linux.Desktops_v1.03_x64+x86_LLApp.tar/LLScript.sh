#!/bin/bash

#LLStore Script v1.02

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

# Source shared core: functions (flatinst), terminal/OS detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Core.sh" ]; then source "%ToolPath%/LLScript_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use $HOME/.local/share/ paths instead of /usr/share/, and note that
        # rpm-ostree installs require a reboot before packages are available.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$XDG_SESSION_DESKTOP" in
    *[Cc]innamon*)
    #Set No effects (Feels faster)
    gsettings set org.cinnamon desktop-effects false

    #Set Clock to 12H not 24H
    gsettings set org.cinnamon.desktop.interface clock-use-24h false

    ##Desktop Icon Grid Size
    gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002

    #Desktop Icons
    gsettings set org.nemo.desktop computer-icon-visible true
    gsettings set org.nemo.desktop trash-icon-visible true

    #Disable USB and Mounts from Desktop
    gsettings set org.nemo.desktop volumes-visible false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Lock when Screensaver
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false

    #Enable Trackpad Gestures
    gsettings set org.cinnamon.gestures enabled true

    #Show icons in Menus
    dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"

    #Configure Xed to be better
    gsettings set org.x.editor.preferences.editor display-line-numbers true
    gsettings set org.x.editor.preferences.editor bracket-matching false
    #gsettings set org.x.editor.preferences.editor scheme 'classic' (Classic Theme has White Line Number bar, looks bad)
    gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"

    #Double-Click Titlebar to Maximise
    gsettings set org.cinnamon.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.nemo.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.nemo.preferences confirm-trash true

    #Configure Nemo to have better Windowsy defaults
    gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Nemo.
    # These folders will also use list view. Set manually via View > View as Icons if needed.
    #gsettings set org.nemo.preferences inherit-folder-viewer true #Not Needed when default view is set
    gsettings set org.nemo.preferences show-full-path-titles true

    #Get thumbnails for images up to 4gb, should cover most movies etc too.
    gsettings set org.nemo.preferences thumbnail-limit 4294967295

    #Nemo Toolbar Icons
    gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    gsettings set org.nemo.preferences show-computer-icon-toolbar true

    #Sound FX
    gsettings set org.cinnamon.sounds login-enabled false
    gsettings set org.cinnamon.sounds logout-enabled false
    gsettings set org.cinnamon.sounds notification-enabled false
    #gsettings set org.cinnamon.desktop.sound volume-sound-enabled true
    #gsettings set org.cinnamon.desktop.sound volume-sound-file "/usr/share/sounds/freedesktop/stereo/audio-volume-change.oga"

    #Close Network on Nemo Sidebar (Opened by default)
    gsettings set org.nemo.window-state network-expanded false

    #Change default Time on lock screen to have date
    #Lock Screen Formatting
    gsettings set org.cinnamon.desktop.screensaver use-custom-format true
    gsettings set org.cinnamon.desktop.screensaver time-format "%l:%M %p"
    gsettings set org.cinnamon.desktop.screensaver date-format "            %A, %b %d"

    #Disable Screen Lock and Resume With Lock
    gsettings set org.cinnamon.settings-daemon.plugins.power lock-on-suspend false
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    gsettings set org.cinnamon.desktop.screensaver lock-delay 0

    #Screen Sleep after 15 Minutes
    gsettings set org.cinnamon.desktop.session idle-delay 900

    #Show hover tooltips on files/folders (Not everyone will want this, I should make a Settings choices app)
    gsettings set org.nemo.preferences tooltips-show-file-type true
    gsettings set org.nemo.preferences tooltips-show-path true
    gsettings set org.nemo.preferences tooltips-in-icon-view true
    gsettings set org.nemo.preferences tooltips-on-desktop true
        ;;

    gnome|ubuntu|ubuntu-xorg)
    # Fix terminal colours
    profile=$(gsettings get org.gnome.Terminal.ProfilesList default) # was missing - profile was never set
    profile=${profile:1:-1} # remove leading and trailing single quotes
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ use-theme-colors 'false'
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ foreground-color 'rgb(208,207,204)'
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ background-color 'rgb(23,20,33)'

    #Disable Animations (Feels faster)
    gsettings set org.gnome.desktop.interface enable-animations false

    #Set Clock to 12H not 24H
    gsettings set org.gnome.desktop.interface clock-format '12h'

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Screen Lock
    gsettings set org.gnome.desktop.screensaver lock-enabled false
    gsettings set org.gnome.settings-daemon.plugins.power lock-on-suspend false

    #Screen Sleep after 15 Minutes
    gsettings set org.gnome.desktop.session idle-delay 900

    #Disable Event Sounds
    gsettings set org.gnome.desktop.sound event-sounds false

    #Nautilus - show thumbnails for all file sizes (covers most movies/images)
    gsettings set org.gnome.nautilus.preferences show-image-thumbnails 'always'
    gsettings set org.gnome.desktop.thumbnail-cache maximum-age -1
    gsettings set org.gnome.desktop.thumbnail-cache maximum-size -1

    #Double-Click Titlebar to Maximise
    gsettings set org.gnome.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.gnome.nautilus.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.gnome.nautilus.preferences confirm-trash true

    #Nautilus - Windowsy defaults
    gsettings set org.gnome.nautilus.preferences default-folder-viewer 'grid-view'
    gsettings set org.gnome.nautilus.preferences show-create-link true
    #gsettings set org.gnome.nautilus.list-view use-tree-view true  # list-view only, not used in grid-view
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Nautilus.
        ;;

    kde|KDE|plasma)
    sed -i -e 's/panelLengthMode=0/panelLengthMode=1/g' $HOME/.config/plasmashellrc

    #Sort Icons Top to Bottom
    sed -i -e 's/\[Containments\]\[1\]\[General\]/\[Containments\]\[1\]\[General\]\narrangement=1/g' $HOME/.config/plasma-org.kde.plasma.desktop-appletsrc
    #Remove Duplicated entry if any
    sed -i -e 's/arrangement=1\narrangement=1/arrangement=1/g' $HOME/.config/plasma-org.kde.plasma.desktop-appletsrc

    #Add Home and Trash
cat > $HOME/Desktop/000home.desktop << EOF
[Desktop Entry]
Encoding=UTF-8
Name=Home
GenericName=Personal Files
URL[$e]=$HOME
Icon=user-home
Type=Link
EOF

cat > $HOME/Desktop/000trash.desktop << EOF
[Desktop Entry]
Name=Trash
Comment=Contains removed files
Icon=user-trash-full
EmptyIcon=user-trash
Type=Link
URL=trash:/
OnlyShowIn=KDE;
EOF

    #Don't remember tabs opened before
    sed -i -e 's/\[General\]/\[General\]\nRememberOpenedTabs=false/g' $HOME/.config/dolphinrc
    #Remove Duplicated entry if any
    sed -i -e 's/RememberOpenedTabs=false\nRememberOpenedTabs=false/RememberOpenedTabs=false/g' $HOME/.config/dolphinrc

    cp -rf ./kxmlgui5 $HOME/.local/share/

    #Fix Gnome Terminal options so they work with Wayland, else they are spacy
    profile=$(gsettings get org.gnome.Terminal.ProfilesList default)
    profile=${profile:1:-1} # remove leading and trailing single quotes
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ use-theme-colors 'false'
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ foreground-color 'rgb(208,207,204)'
    gsettings set org.gnome.Terminal.Legacy.Profile:/org/gnome/terminal/legacy/profiles:/:$profile/ background-color 'rgb(23,20,33)'

    #Double-Click Titlebar to Maximise
    kwriteconfig5 --file kwinrc --group Windows --key TitlebarDoubleClickCommand "Maximize"

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    kwriteconfig5 --file kwinrc --group MouseBindings --key CommandAllKey "Meta"

    #Restart KWin to apply window manager changes
    qdbus org.kde.KWin /KWin reconfigure 2>/dev/null || true

    #Double-Click to Open Files and Desktop Icons (not single-click)
    kwriteconfig5 --file kdeglobals --group KDE --key SingleClick false

    #Default List/Details View in Dolphin
    kwriteconfig5 --file dolphinrc --group General --key ViewMode 2
    # Note: Icon view for Pictures/Computer folders set per-folder below.
    mkdir -p "$HOME/.local/share/dolphin/view_properties/$(python3 -c "import urllib.parse,os; print(urllib.parse.quote(os.path.expanduser('~/Pictures').lstrip('/'), safe=''))" 2>/dev/null)"
    PICS_PROPS="$HOME/.local/share/dolphin/view_properties/$(python3 -c "import urllib.parse,os; print(urllib.parse.quote(os.path.expanduser('~/Pictures').lstrip('/'), safe=''))" 2>/dev/null)/.directory"
    if [ -n "$PICS_PROPS" ] && [ -d "$(dirname "$PICS_PROPS")" ]; then
        kwriteconfig5 --file "$PICS_PROPS" --group Dolphin --key ViewMode 0
    fi

    #Date Modified Column visible in Dolphin Details View
    kwriteconfig5 --file dolphinrc --group DetailsMode --key VisibleRoles "text,size,modificationtime,type"

    #NumLock on at login (KDE session)
    kwriteconfig5 --file kcminputrc --group Keyboard --key NumLock 0
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    #Desktop Icons
    gsettings set org.mate.caja.desktop computer-icon-visible true
    gsettings set org.mate.caja.desktop trash-icon-visible true
    gsettings set org.mate.caja.desktop volumes-visible false

    #Disable Animations (Feels faster)
    gsettings set org.mate.Marco.general reduced-resources true

    #Set Clock to 12H not 24H
    gsettings set org.mate.panel.clock-format '12-hour'

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Screen Lock
    gsettings set org.mate.screensaver lock-enabled false
    gsettings set org.mate.screensaver lock-delay 0

    #Double-Click Titlebar to Maximise
    gsettings set org.mate.Marco.general action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.mate.caja.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.mate.caja.preferences confirm-trash true

    #Caja (file manager) Windowsy defaults
    gsettings set org.mate.caja.preferences default-folder-viewer 'compact-view'
    gsettings set org.mate.caja.preferences thumbnail-limit 4294967295
    gsettings set org.mate.caja.preferences show-full-path-in-title-bars true
    gsettings set org.mate.caja.preferences quick-renames-with-pause-in-between true
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Caja.

    #Pluma text editor
    gsettings set org.mate.pluma display-line-numbers true
    gsettings set org.mate.pluma bracket-matching false

    #Disable Event Sounds
    gsettings set org.gnome.desktop.sound event-sounds false

    #Sleep timers
    #gsettings set org.mate.power-manager sleep-computer-ac 1800
    gsettings set org.mate.power-manager sleep-display-ac 1200
    #gsettings set org.mate.power-manager sleep-computer-battery 180
    gsettings set org.mate.power-manager sleep-display-battery 120

    #Screensaver
    gsettings set org.mate.session idle-delay 20
        ;;

    unity)
        ;;

    xfce)
    #Disable Compositing (Feels faster)
    xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false

    #Desktop Icons - show Home and Trash, hide removable drives
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-filesystem -n -t bool -s true
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-trash -n -t bool -s true
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-removable -n -t bool -s false

    #Double-Click Titlebar to Maximise
    xfconf-query -c xfwm4 -p /general/double_click_action -n -t string -s "maximize"

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    xfconf-query -c xfwm4 -p /general/easy_click -n -t string -s "Super"

    #Disable Screen Lock on Suspend
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/lock-screen-suspend-hibernate -n -t bool -s false

    #Screen Sleep after 15 Minutes (AC) and 5 Minutes (Battery)
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-ac -n -t uint -s 15
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-battery -n -t uint -s 5

    #Double-Click to Open Files and Desktop Icons (not single-click)
    xfconf-query -c thunar -p /misc-single-click -n -t bool -s false

    #Date Modified Column visible in Thunar Details View
    xfconf-query -c thunar -p /last-details-view-visible-columns -n -t string -s "THUNAR_COLUMN_NAME,THUNAR_COLUMN_SIZE,THUNAR_COLUMN_DATE_MODIFIED,THUNAR_COLUMN_TYPE"

    # Note: Thunar has no global default view mode setting — view type is stored per-folder.
    # Set manually via View > View as Detailed List then View > Configure this Folder.

    #Thunar - show thumbnails for all file sizes
    xfconf-query -c thunar -p /misc-thumbnail-mode -n -t string -s "THUNAR_THUMBNAIL_MODE_ALWAYS"

    #Mousepad text editor - show line numbers
    gsettings set org.xfce.mousepad.preferences.view show-line-numbers true 2>/dev/null || true
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($XDG_SESSION_DESKTOP). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# To install user Flatpaks (no sudo required):
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

exit 0
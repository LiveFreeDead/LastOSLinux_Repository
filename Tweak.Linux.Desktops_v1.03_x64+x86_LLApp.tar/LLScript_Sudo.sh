#!/bin/bash

#LLStore Sudo Script v1.03

#---------- User Set Variables ----------

################################################################################
#                                                                              #
#  Sections until next block are functions that the user does not need to edit #
#                                                                              #
################################################################################

#---------- Sudo Keepalive ----------

# Prompt for sudo credentials up front to avoid mid-script interruptions
sudo -v

# Keep sudo credentials alive in background while script runs.
# The background process is registered with a trap so it's always cleaned up on exit.
( while true; do sudo -n true; sleep 55; done ) &
SUDO_KEEPALIVE_PID=$!
trap 'kill "$SUDO_KEEPALIVE_PID" 2>/dev/null' EXIT INT TERM

# Source shared core: inst, flatinst, terminal/PM/DE detection, system details.
# Tries the installed path first so manual script runs always get a core.
# Falls back to %ToolPath%/ (USB/portable path, replaced at install time by LLStore).
if [ -f "%ToolPath%/LLScript_Sudo_Core.sh" ]; then source "%ToolPath%/LLScript_Sudo_Core.sh"; elif [ -f "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh" ]; then source "/opt/LastOS/LLStore/Tools/LLScript_Sudo_Core.sh"; fi #LLCore

################################################################################
#                                                                              #
#    Sections below are where you edit with your code that will run in order   #
#                                                                              #
################################################################################

#---------- Package Manager Tasks ----------
echo
echo -e "\033[4m        Package Manager Tasks         \033[0m"
case "$PM" in
    pamac)
        # Arch/Manjaro package names differ from rpm/deb - add pamac-specific packages here
        ;;

    dnf)
        ;;

    apt)
        ;;

    pacman)
        # Arch package names differ from rpm/deb - add pacman-specific packages here
        ;;

    zypper)
        ;;

    yum)
        ;;

    emerge)
        ;;

    eopkg)
        ;;

    apk)
        ;;

    *)
        ;;
esac

#---------- OS Specific Tasks ----------
echo
echo -e "\033[4m          OS Specific Tasks           \033[0m"
# Add per-distro repo setup, PPAs, etc. here before inst() calls below.
case "$ID" in
    manjaro)
        ;;

    linuxmint|ubuntu)
        ;;

    debian|pop)
        ;;

    fedora|nobara)
        ;;

    opensuse-tumbleweed|opensuse-leap)
        ;;

    almalinux)
        ;;

    arch|endeavouros)
        ;;

    argent)
        ;;

    biglinux)
        ;;

    cachyos)
        ;;

    deepin)
        ;;

    garuda)
        ;;

    regataos)
        ;;

    solus)
        ;;

    zorin)
        ;;

    bazzite|silverblue|kinoite|sericea|aurora|bluefin)
        # Immutable/atomic OS — $IMMUTABLE_OS is true, /usr is read-only.
        # Use rpm-ostree via inst() for packages; they require a reboot to activate.
        # Avoid writing to /usr/share/ — use $HOME/.local/share/ instead.
        ;;

    *)
        echo "Unknown Distribution ($ID). Script section skipped"
        ;;
esac

#---------- DE Specific Tasks ----------
echo
echo -e "\033[4m          DE Specific Tasks           \033[0m"
case "$DE" in
    *[Cc]innamon*)
    #Set No effects (Feels faster)
    gsettings set org.cinnamon desktop-effects false
    sudo gsettings set org.cinnamon desktop-effects false

    #Set Clock to 12H not 24H
    gsettings set org.cinnamon.desktop.interface clock-use-24h false
    sudo gsettings set org.cinnamon.desktop.interface clock-use-24h false

    ##Desktop Icon Grid Size
    gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop horizontal-grid-adjust 0.40000000000000002
    sudo gsettings set org.nemo.desktop vertical-grid-adjust 0.40000000000000002

    #Desktop Icons
    gsettings set org.nemo.desktop computer-icon-visible true
    gsettings set org.nemo.desktop trash-icon-visible true
    sudo gsettings set org.nemo.desktop computer-icon-visible true
    sudo gsettings set org.nemo.desktop trash-icon-visible true

    #Disable USB and Mounts from Desktop
    gsettings set org.nemo.desktop volumes-visible false
    sudo gsettings set org.nemo.desktop volumes-visible false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo dconf write /org/gnome/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo dconf write /org/cinnamon/desktop/wm/preferences/mouse-button-modifier "'<Super>'"
    sudo gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo gsettings set org.cinnamon.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Lock when Screensaver
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    sudo gsettings set org.cinnamon.desktop.screensaver lock-enabled false

    #Enable Trackpad Gestures
    gsettings set org.cinnamon.gestures enabled true
    sudo gsettings set org.cinnamon.gestures enabled true

    #Show icons in Menus
    dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"
    sudo dconf write /org/cinnamon/settings-daemon/plugins/xsettings/menus-have-icons "true"

    #Configure Xed to be better
    gsettings set org.x.editor.preferences.editor display-line-numbers true
    gsettings set org.x.editor.preferences.editor bracket-matching false
    sudo gsettings set org.x.editor.preferences.editor display-line-numbers true
    sudo gsettings set org.x.editor.preferences.editor bracket-matching false
    #gsettings set org.x.editor.preferences.editor scheme 'classic' (Classic Theme has White Line Number bar, looks bad)
    gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"
    sudo gsettings set org.x.editor.plugins active-plugins "['filebrowser', 'modelines', 'open-uri-context-menu', 'docinfo', 'textsize', 'sort', 'joinlines', 'spell', 'time']"

    #Double-Click Titlebar to Maximise
    gsettings set org.cinnamon.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'
    sudo gsettings set org.cinnamon.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.nemo.preferences click-policy 'double'
    sudo gsettings set org.nemo.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.nemo.preferences confirm-trash true
    sudo gsettings set org.nemo.preferences confirm-trash true

    #Configure Nemo to have better Windowsy defaults
    gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    sudo gsettings set org.nemo.preferences quick-renames-with-pause-in-between true
    sudo gsettings set org.nemo.preferences default-folder-viewer 'compact-view'
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Nemo.
    # These folders will also use list view. Set manually via View > View as Icons if needed.
    #gsettings set org.nemo.preferences inherit-folder-viewer true #Not Needed when default view is set
    gsettings set org.nemo.preferences show-full-path-titles true
    sudo gsettings set org.nemo.preferences show-full-path-titles true

    #Get thumbnails for images up to 4gb, should cover most movies etc too.
    gsettings set org.nemo.preferences thumbnail-limit 4294967295
    sudo gsettings set org.nemo.preferences thumbnail-limit 4294967295

    #Nemo Toolbar Icons
    gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    gsettings set org.nemo.preferences show-computer-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-new-folder-icon-toolbar true
    sudo gsettings set org.nemo.preferences show-open-in-terminal-toolbar true
    sudo gsettings set org.nemo.preferences show-computer-icon-toolbar true

    #Show Hidden Files By Default in Sudo windows
    sudo gsettings set org.nemo.preferences show-hidden-files true

    #Sound FX
    gsettings set org.cinnamon.sounds login-enabled false
    gsettings set org.cinnamon.sounds logout-enabled false
    gsettings set org.cinnamon.sounds notification-enabled false
    #gsettings set org.cinnamon.desktop.sound volume-sound-enabled true
    #gsettings set org.cinnamon.desktop.sound volume-sound-file "/usr/share/sounds/freedesktop/stereo/audio-volume-change.oga"

    #Close Network on Nemo Sidebar (Opened by default)
    gsettings set org.nemo.window-state network-expanded false
    sudo gsettings set org.nemo.window-state network-expanded false

    #Change default Time on lock screen to have date
    #Lock Screen Formatting
    gsettings set org.cinnamon.desktop.screensaver use-custom-format true
    gsettings set org.cinnamon.desktop.screensaver time-format "%l:%M %p"
    gsettings set org.cinnamon.desktop.screensaver date-format "            %A, %b %d"

    #Disable Screen Lock and Resume With Lock
    gsettings set org.cinnamon.settings-daemon.plugins.power lock-on-suspend false
    gsettings set org.cinnamon.desktop.screensaver lock-enabled false
    gsettings set org.cinnamon.desktop.screensaver lock-delay 0

    #Screen Sleep after 15 Minutes
    gsettings set org.cinnamon.desktop.session idle-delay 900

    #Show hover tooltips on files/folders (Not everyone will want this, I should make a Settings choices app)
    gsettings set org.nemo.preferences tooltips-show-file-type true
    gsettings set org.nemo.preferences tooltips-show-path true
    gsettings set org.nemo.preferences tooltips-in-icon-view true
    gsettings set org.nemo.preferences tooltips-on-desktop true
    sudo gsettings set org.nemo.preferences tooltips-show-file-type true
    sudo gsettings set org.nemo.preferences tooltips-show-path true
    sudo gsettings set org.nemo.preferences tooltips-in-icon-view true
    sudo gsettings set org.nemo.preferences tooltips-on-desktop true
        ;;

    gnome|ubuntu|ubuntu-xorg)
    #Disable Animations (Feels faster)
    gsettings set org.gnome.desktop.interface enable-animations false
    sudo gsettings set org.gnome.desktop.interface enable-animations false

    #Set Clock to 12H not 24H
    gsettings set org.gnome.desktop.interface clock-format '12h'
    sudo gsettings set org.gnome.desktop.interface clock-format '12h'

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Screen Lock
    gsettings set org.gnome.desktop.screensaver lock-enabled false
    gsettings set org.gnome.settings-daemon.plugins.power lock-on-suspend false
    sudo gsettings set org.gnome.desktop.screensaver lock-enabled false
    sudo gsettings set org.gnome.settings-daemon.plugins.power lock-on-suspend false

    #Screen Sleep after 15 Minutes
    gsettings set org.gnome.desktop.session idle-delay 900
    sudo gsettings set org.gnome.desktop.session idle-delay 900

    #Disable Event Sounds
    gsettings set org.gnome.desktop.sound event-sounds false
    sudo gsettings set org.gnome.desktop.sound event-sounds false

    #Nautilus - show thumbnails for all file sizes (covers most movies/images)
    gsettings set org.gnome.nautilus.preferences show-image-thumbnails 'always'
    gsettings set org.gnome.desktop.thumbnail-cache maximum-age -1
    gsettings set org.gnome.desktop.thumbnail-cache maximum-size -1
    sudo gsettings set org.gnome.nautilus.preferences show-image-thumbnails 'always'
    sudo gsettings set org.gnome.desktop.thumbnail-cache maximum-age -1
    sudo gsettings set org.gnome.desktop.thumbnail-cache maximum-size -1

    #Double-Click Titlebar to Maximise
    gsettings set org.gnome.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'
    sudo gsettings set org.gnome.desktop.wm.preferences action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.gnome.nautilus.preferences click-policy 'double'
    sudo gsettings set org.gnome.nautilus.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.gnome.nautilus.preferences confirm-trash true
    sudo gsettings set org.gnome.nautilus.preferences confirm-trash true

    #Nautilus - Windowsy defaults
    gsettings set org.gnome.nautilus.preferences default-folder-viewer 'grid-view'
    gsettings set org.gnome.nautilus.preferences show-create-link true
    #gsettings set org.gnome.nautilus.list-view use-tree-view true  # list-view only, not used in grid-view
    sudo gsettings set org.gnome.nautilus.preferences default-folder-viewer 'grid-view'
    sudo gsettings set org.gnome.nautilus.preferences show-create-link true
    #gsettings set org.gnome.nautilus.list-view use-tree-view true  # list-view only, not used in grid-view
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Nautilus.
    # These folders will also use list view. Set manually via View > Grid View if needed.
        ;;

    kde|KDE|plasma)
    #Disable Screen Lock
    kwriteconfig5 --file kscreenlockerrc --group Daemon --key Autolock false
    qdbus org.kde.screensaver /ScreenSaver org.kde.screensaver.configure 2>/dev/null || true

    #Reduce Animation Speed (set to instant/fastest)
    kwriteconfig5 --file kwinrc --group Compositing --key AnimationSpeed 0

    #Double-Click Titlebar to Maximise
    kwriteconfig5 --file kwinrc --group Windows --key TitlebarDoubleClickCommand "Maximize"

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    kwriteconfig5 --file kwinrc --group MouseBindings --key CommandAllKey "Meta"

    #Restart KWin to apply window manager changes
    qdbus org.kde.KWin /KWin reconfigure 2>/dev/null || true

    #Double-Click to Open Files and Desktop Icons (not single-click)
    kwriteconfig5 --file kdeglobals --group KDE --key SingleClick false

    #Default List/Details View in Dolphin
    kwriteconfig5 --file dolphinrc --group General --key ViewMode 2
    # Note: Icon view for Pictures/Computer folders is set per-folder below.
    # Dolphin uses ~/.local/share/dolphin/view_properties/ for per-folder overrides.
    # Only the XDG Pictures directory can be pre-configured reliably this way.
    mkdir -p "$HOME/.local/share/dolphin/view_properties/$(python3 -c "import urllib.parse,os; print(urllib.parse.quote(os.path.expanduser('~/Pictures').lstrip('/'), safe=''))" 2>/dev/null)"
    PICS_PROPS="$HOME/.local/share/dolphin/view_properties/$(python3 -c "import urllib.parse,os; print(urllib.parse.quote(os.path.expanduser('~/Pictures').lstrip('/'), safe=''))" 2>/dev/null)/.directory"
    if [ -n "$PICS_PROPS" ] && [ -d "$(dirname "$PICS_PROPS")" ]; then
        kwriteconfig5 --file "$PICS_PROPS" --group Dolphin --key ViewMode 0
    fi

    #Date Modified Column visible in Dolphin Details View
    kwriteconfig5 --file dolphinrc --group DetailsMode --key VisibleRoles "text,size,modificationtime,type"

    #NumLock on at login (KDE session)
    kwriteconfig5 --file kcminputrc --group Keyboard --key NumLock 0
        ;;

    lxde)
        ;;

    mate|lightdm-xsession)
    #Desktop Icons
    gsettings set org.mate.caja.desktop computer-icon-visible true
    gsettings set org.mate.caja.desktop trash-icon-visible true
    gsettings set org.mate.caja.desktop volumes-visible false
    sudo gsettings set org.mate.caja.desktop computer-icon-visible true
    sudo gsettings set org.mate.caja.desktop trash-icon-visible true
    sudo gsettings set org.mate.caja.desktop volumes-visible false

    #Disable Animations (Feels faster)
    gsettings set org.mate.Marco.general reduced-resources true
    sudo gsettings set org.mate.Marco.general reduced-resources true

    #Set Clock to 12H not 24H
    gsettings set org.mate.panel.clock-format '12-hour'
    sudo gsettings set org.mate.panel.clock-format '12-hour'

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'
    sudo gsettings set org.gnome.desktop.wm.preferences mouse-button-modifier '<Super>'

    #Disable Screen Lock
    gsettings set org.mate.screensaver lock-enabled false
    gsettings set org.mate.screensaver lock-delay 0
    sudo gsettings set org.mate.screensaver lock-enabled false
    sudo gsettings set org.mate.screensaver lock-delay 0

    #Double-Click Titlebar to Maximise
    gsettings set org.mate.Marco.general action-double-click-titlebar 'toggle-maximize'
    sudo gsettings set org.mate.Marco.general action-double-click-titlebar 'toggle-maximize'

    #Double-Click to Open Files and Desktop Icons (not single-click)
    gsettings set org.mate.caja.preferences click-policy 'double'
    sudo gsettings set org.mate.caja.preferences click-policy 'double'

    #Confirm Before Emptying Trash
    gsettings set org.mate.caja.preferences confirm-trash true
    sudo gsettings set org.mate.caja.preferences confirm-trash true

    #Caja (file manager) Windowsy defaults
    gsettings set org.mate.caja.preferences default-folder-viewer 'compact-view'
    gsettings set org.mate.caja.preferences thumbnail-limit 4294967295
    gsettings set org.mate.caja.preferences show-full-path-in-title-bars true
    gsettings set org.mate.caja.preferences quick-renames-with-pause-in-between true
    sudo gsettings set org.mate.caja.preferences default-folder-viewer 'compact-view'
    sudo gsettings set org.mate.caja.preferences thumbnail-limit 4294967295
    sudo gsettings set org.mate.caja.preferences show-full-path-in-title-bars true
    sudo gsettings set org.mate.caja.preferences quick-renames-with-pause-in-between true
    # Note: Per-folder-type icon view (Pictures, Computer) is not scriptable in Caja.

    #Pluma text editor
    gsettings set org.mate.pluma display-line-numbers true
    gsettings set org.mate.pluma bracket-matching false
    sudo gsettings set org.mate.pluma display-line-numbers true
    sudo gsettings set org.mate.pluma bracket-matching false

    #Disable Event Sounds
    gsettings set org.gnome.desktop.sound event-sounds false
    sudo gsettings set org.gnome.desktop.sound event-sounds false

    #Sleep timers
    #gsettings set org.mate.power-manager sleep-computer-ac 1800
    gsettings set org.mate.power-manager sleep-display-ac 1200
    #gsettings set org.mate.power-manager sleep-computer-battery 180
    gsettings set org.mate.power-manager sleep-display-battery 120

    #Screensaver
    gsettings set org.mate.session idle-delay 20
        ;;

    unity)
        ;;

    xfce)
    #Disable Compositing (Feels faster)
    xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false
    sudo xfconf-query -c xfwm4 -p /general/use_compositing -n -t bool -s false

    #Desktop Icons - show Home and Trash, hide removable drives
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-filesystem -n -t bool -s true
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-trash -n -t bool -s true
    xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-removable -n -t bool -s false
    sudo xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-filesystem -n -t bool -s true
    sudo xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-trash -n -t bool -s true
    sudo xfconf-query -c xfce4-desktop -p /desktop-icons/file-icons/show-removable -n -t bool -s false

    #Make Mouse window move Modifier Super Key instead of ALT so Photoshop works with alt key to set Source
    xfconf-query -c xfwm4 -p /general/easy_click -n -t string -s "Super"
    sudo xfconf-query -c xfwm4 -p /general/easy_click -n -t string -s "Super"

    #Disable Screen Lock on Suspend
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/lock-screen-suspend-hibernate -n -t bool -s false
    sudo xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/lock-screen-suspend-hibernate -n -t bool -s false

    #Screen Sleep after 15 Minutes (AC) and 5 Minutes (Battery)
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-ac -n -t uint -s 15
    xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-battery -n -t uint -s 5
    sudo xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-ac -n -t uint -s 15
    sudo xfconf-query -c xfce4-power-manager -p /xfce4-power-manager/inactivity-on-battery -n -t uint -s 5

    #Double-Click Titlebar to Maximise
    xfconf-query -c xfwm4 -p /general/double_click_action -n -t string -s "maximize"
    sudo xfconf-query -c xfwm4 -p /general/double_click_action -n -t string -s "maximize"

    #Double-Click to Open Files and Desktop Icons (not single-click)
    xfconf-query -c thunar -p /misc-single-click -n -t bool -s false
    sudo xfconf-query -c thunar -p /misc-single-click -n -t bool -s false

    #Date Modified Column visible in Thunar Details View
    xfconf-query -c thunar -p /last-details-view-visible-columns -n -t string -s "THUNAR_COLUMN_NAME,THUNAR_COLUMN_SIZE,THUNAR_COLUMN_DATE_MODIFIED,THUNAR_COLUMN_TYPE"
    sudo xfconf-query -c thunar -p /last-details-view-visible-columns -n -t string -s "THUNAR_COLUMN_NAME,THUNAR_COLUMN_SIZE,THUNAR_COLUMN_DATE_MODIFIED,THUNAR_COLUMN_TYPE"

    # Note: Thunar has no global default view mode setting — view type is stored per-folder.
    # Set manually via View > View as Detailed List then View > Configure this Folder.

    #Thunar - show thumbnails for all file sizes
    xfconf-query -c thunar -p /misc-thumbnail-mode -n -t string -s "THUNAR_THUMBNAIL_MODE_ALWAYS"
    sudo xfconf-query -c thunar -p /misc-thumbnail-mode -n -t string -s "THUNAR_THUMBNAIL_MODE_ALWAYS"

    #Mousepad text editor - show line numbers
    gsettings set org.xfce.mousepad.preferences.view show-line-numbers true 2>/dev/null || true
    sudo gsettings set org.xfce.mousepad.preferences.view show-line-numbers true 2>/dev/null || true
        ;;

    [Cc][Oo][Ss][Mm][Ii][Cc]*|pop)
        ;;

    budgie-desktop)
        ;;

    LXQt)
        ;;

    anduinos|anduinos-xorg)
        ;;

    deepin)
        ;;

    default) #SUSE
        ;;

    zorin)
        ;;

    *)
        echo "Unknown Desktop Environment ($DE). Script section skipped"
        ;;
esac

#---------- Installation Section ----------
echo
echo -e "\033[4m         Installation Section         \033[0m"

# Native packages (uses detected package manager):
# inst appname1 appname2

# System-wide Flatpaks:
# flatinst org.name.app1 org.name.app2

echo
echo -e "\033[4m             Custom Code              \033[0m"
#----- Add Your Code Here ------

#Num Lock on at Login
inst numlockx

# LightDM (Linux Mint, Ubuntu MATE, XFCE, etc.)
if [ -f /etc/lightdm/lightdm.conf ]; then
    if grep -q "greeter-setup-script" /etc/lightdm/lightdm.conf; then
        sudo sed -i 's|greeter-setup-script=.*|greeter-setup-script=/usr/bin/numlockx on|' /etc/lightdm/lightdm.conf
    else
        sudo sed -i '/\[Seat:\*\]/a greeter-setup-script=/usr/bin/numlockx on' /etc/lightdm/lightdm.conf
    fi
fi

# SDDM (KDE Plasma)
if systemctl is-active --quiet sddm 2>/dev/null || [ -d /etc/sddm.conf.d ]; then
    sudo mkdir -p /etc/sddm.conf.d
    echo -e "[General]\nNumlock=on" | sudo tee /etc/sddm.conf.d/numlockx.conf > /dev/null
fi

# GDM (GNOME)
for GDM_INIT in /etc/gdm3/Init/Default /etc/gdm/Init/Default; do
    if [ -f "$GDM_INIT" ] && ! grep -q "numlockx" "$GDM_INIT"; then
        sudo sed -i '/^exit 0/i numlockx on' "$GDM_INIT"
    fi
done

exit 0
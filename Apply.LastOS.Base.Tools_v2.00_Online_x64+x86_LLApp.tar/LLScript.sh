#!/bin/bash

numlockx on
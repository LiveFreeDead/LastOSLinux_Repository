#!/bin/bash

rm -rf $HOME/.config/google-chrome/SingletonLock
rm -rf /home/$SUDO_USER/.config/google-chrome/SingletonLock
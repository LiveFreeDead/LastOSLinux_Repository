#!/bin/bash

#---------- Functions ----------
inst () {
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

if [[ ! -z $PAMAC_CMD ]]; then
    sudo $PAMAC_CMD install --no-confirm $*
elif [[ ! -z $DNF_CMD ]]; then
    sudo $DNF_CMD -y install $*
elif [[ ! -z $APT_CMD ]]; then
    sudo $APT_CMD -y install $*
elif [[ ! -z $EMERGE_CMD ]]; then
    sudo $EMERGE_CMD $PACKAGES
elif [[ ! -z $EOPKG_CMD ]]; then
    sudo $EOPKG_CMD -y install $*
elif [[ ! -z $APK_CMD ]]; then
    sudo $APK_CMD add install $*
elif [[ ! -z $PACMAN_CMD ]]; then
    # Syu gets dependancies etc
    yes | sudo $PACMAN_CMD -Syu $*
elif [[ ! -z $ZYPPER_CMD ]]; then
    sudo $ZYPPER_CMD --non-interactive install $*
elif [[ ! -z $YUM_CMD ]]; then
    sudo $YUM_CMD -y install $*
else
    echo "error can't install package $*"
fi
}
#-------------------------------

#Get Best Terminal For LLStore (in order)
TERMS=(gnome-terminal konsole x-terminal-emulator xterm xfce4-terminal)
for t in ${TERMS[*]}
do
    if [ $(command -v $t) ]
    then
        OSTERM=$t
        break
    fi
done

#Get Package Manager
APT_CMD=$(type -P apt 2>/dev/null)
DNF_CMD=$(type -P dnf 2>/dev/null)
EMERGE_CMD=$(type -P emerge 2>/dev/null)
EOPKG_CMD=$(type -P eopkg 2>/dev/null)
APK_CMD=$(type -P apk 2>/dev/null)
PACMAN_CMD=$(type -P pacman 2>/dev/null)
PAMAC_CMD=$(type -P pamac 2>/dev/null)
ZYPPER_CMD=$(type -P zypper 2>/dev/null)
YUM_CMD=$(type -P yum 2>/dev/null)

#Get Desktop Environment to do tasks
echo "Terminal Used: $OSTERM"
echo "Desktop Environment: $XDG_SESSION_DESKTOP"

#-------------------------------

#Use below sections to put update/upgrade repository or add PPA or repo's
PM=""
if [[ ! -z $PAMAC_CMD ]]; then #pamac
    PM=pamac
    echo "Package Manager: pamac"
    inst google-chrome
elif [[ ! -z $DNF_CMD ]]; then #dnf
    PM=dnf
    echo "Package Manager: dnf"
    sudo dnf -y install wget
    if ! [ -f "google-chrome-stable_current_x86_64.rpm" ] ; then
        wget https://dl.google.com/linux/direct/google-chrome-stable_current_x86_64.rpm
    fi
    sudo dnf -y install google-chrome-stable_current_x86_64.rpm
elif [[ ! -z $APT_CMD ]]; then #apt
    PM=apt
    echo "Package Manager: apt"
    sudo apt install -y wget

    #Google Chrome (This self updates and is better than the flatpak stuff from the repository)
    if [ -f "/tmp/google-chrome-stable_current_amd64.deb" ] ; then
        cp /tmp/google-chrome-stable_current_amd64.deb ./
    else
        if ! [ -f "google-chrome-stable_current_amd64.deb" ] ; then
	        wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
        fi
    fi
    sudo apt install -y ./google-chrome-stable_current_amd64.deb
elif [[ ! -z $EMERGE_CMD ]]; then #emerge
    PM=emerge
    echo "Package Manager: emerge"
    inst google-chrome
elif [[ ! -z $EOPKG_CMD ]]; then #eopkg
    PM=eopkg
    echo "Package Manager: eopkg"
    sudo eopkg bi -y --ignore-safety https://raw.githubusercontent.com/getsolus/3rd-party/master/network/web/browser/google-chrome-stable/pspec.xml
    sudo eopkg -y install google-chrome-*.eopkg;sudo rm google-chrome-*.eopkg
elif [[ ! -z $APK_CMD ]]; then #apk
    PM=apk
    echo "Package Manager: apk"
    inst google-chrome
elif [[ ! -z $PACMAN_CMD ]]; then #pacman
    PM=pacman
    echo "Package Manager: pacman"
    inst google-chrome
elif [[ ! -z $ZYPPER_CMD ]]; then #zypper
    PM=zypper
    echo "Package Manager: zypper"
    inst google-chrome
elif [[ ! -z $YUM_CMD ]]; then #yum
    PM=yum
    echo "Package Manager: yum"
    inst google-chrome
else
    echo "Unknown Package Manager. Script section skipped"
    inst google-chrome
fi


#Do Tasks For Detected OS
. /etc/os-release

echo "OS ID: $ID"

case $ID in
  linuxmint|ubuntu) 
    ;;

  debian|pop)
    ;;

  fedora|nobara) 
    ;;

  opensuse-tumbleweed) 
    ;;

  almalinux)
    ;;

  arch|endeavouros)
    ;;

  argent)
    ;;

  biglinux)
    ;;

  cachyos)
    ;;

  deepin)
    ;;

  garuda)
    ;;

  regataos)
    ;;

  solus)
    ;;

  zorin)
    ;;

  *) 
    echo "Unknown Distribution. Script section skipped"
    ;;
esac


#Do Tasks For Active Desktop Environment
case $XDG_SESSION_DESKTOP in
  cinnamon|cinnamon-wayland|cinnamon2d)
    ;;

  gnome|ubuntu|ubuntu-xorg)
    ;;
  
  kde|KDE)
    ;;

  lxde)
    ;;

  mate|lightdm-xsession)
    ;;
  
  unity)
    ;;

  xfce)
    ;;

  cosmic|COSMIC|pop)
    ;;

  budgie-desktop)
    ;;

  LXQt)
    ;;

  anduinos|anduinos-xorg)
    ;;

  deepin)
    ;;

  default)
    #SUSE
    ;;

  zorin)
    ;;

  *)
    #All Others
    echo "Unknown Desktop Environment. Script section skipped"
    ;;
esac


#Install Apps - using Inst function to work on many Distro's if the package(s) are available on its repositories.
#inst appname1 appname2 etc


#FlatPak Install Package System Wide (User mode should be done in non Sudo LLScript)
#Add "org.name.thing" to end of line in quote below and unremark to install a Flatpak
#$OSTERM -e "flatpak install --system -y --noninteractive flathub "


#----- Add Your Code Here ------